"""Building management service"""
from __future__ import annotations

from typing import Optional, Dict, List, Tuple
from datetime import datetime, timedelta
from database import get_db
from services.player_service import PlayerService


class BuildingService:
    @staticmethod
    async def get_catalog() -> List[Dict]:
        db = await get_db()
        return await db.fetchall("SELECT * FROM buildings_catalog ORDER BY required_level, id")

    @staticmethod
    async def get_player_buildings(user_id: int) -> List[Dict]:
        db = await get_db()
        return await db.fetchall(
            """SELECT pb.*, bc.name_fa, bc.name_en, bc.building_type, bc.production_type,
                      bc.base_production, bc.production_per_level, bc.capacity_bonus,
                      bc.defense_bonus, bc.hp_per_level, bc.base_cost, bc.cost_multiplier,
                      bc.base_upgrade_time, bc.max_level, bc.required_level
               FROM player_buildings pb
               JOIN buildings_catalog bc ON pb.building_id = bc.id
               WHERE pb.user_id = ?
               ORDER BY bc.building_type, pb.level DESC""",
            (user_id,)
        )

    @staticmethod
    async def get_all_for_user(user_id: int) -> List[Dict]:
        """Catalog + owned status"""
        db = await get_db()
        catalog = await BuildingService.get_catalog()
        owned = {b["building_id"]: b for b in await BuildingService.get_player_buildings(user_id)}
        result = []
        for c in catalog:
            item = dict(c)
            if c["id"] in owned:
                item.update({
                    "level": owned[c["id"]]["level"],
                    "hp": owned[c["id"]]["hp"],
                    "max_hp": owned[c["id"]]["max_hp"],
                    "is_upgrading": owned[c["id"]]["is_upgrading"],
                    "upgrade_finish_time": owned[c["id"]]["upgrade_finish_time"],
                    "last_collected": owned[c["id"]]["last_collected"],
                    "owned": True,
                })
            else:
                item.update({"level": 0, "owned": False, "hp": 0, "max_hp": 0})
            result.append(item)
        return result

    @staticmethod
    def calc_upgrade_cost(base_cost: int, cost_mult: float, level: int) -> int:
        return int(base_cost * (cost_mult ** level))

    @staticmethod
    def calc_upgrade_time(base_time: int, level: int) -> int:
        return int(base_time * (1.15 ** level))

    @staticmethod
    def calc_production(base: int, per_level: float, level: int) -> int:
        if base <= 0:
            return 0
        return int(base * (per_level ** (level - 1)))

    @staticmethod
    async def buy_building(user_id: int, building_id: int) -> Tuple[bool, str]:
        db = await get_db()
        player = await PlayerService.get(user_id)
        building = await db.fetchone("SELECT * FROM buildings_catalog WHERE id = ?", (building_id,))
        if not player or not building:
            return False, "یافت نشد."
        if player["level"] < building["required_level"]:
            return False, f"سطح مورد نیاز: {building['required_level']}"
        existing = await db.fetchone(
            "SELECT id FROM player_buildings WHERE user_id = ? AND building_id = ?",
            (user_id, building_id)
        )
        if existing:
            return False, "این ساختمان را از قبل دارید."
        cost = building["base_cost"]
        if player["coins"] < cost:
            return False, f"سکه کافی نیست (نیاز: {cost})"
        if player["steel"] < cost // 5:
            return False, "فولاد کافی نیست."

        hp = building["hp_per_level"]
        await PlayerService.update_resources(user_id, coins=-cost, steel=-(cost // 5))
        await db.execute(
            """INSERT INTO player_buildings (user_id, building_id, level, hp, max_hp)
               VALUES (?, ?, 1, ?, ?)""",
            (user_id, building_id, hp, hp)
        )
        await db.execute(
            "UPDATE players SET buildings_count = buildings_count + 1 WHERE user_id = ?",
            (user_id,)
        )
        return True, f"✅ {building['name_fa']} ساخته شد!"

    @staticmethod
    async def upgrade_building(user_id: int, building_id: int) -> Tuple[bool, str]:
        db = await get_db()
        player = await PlayerService.get(user_id)
        pb = await db.fetchone(
            """SELECT pb.*, bc.* FROM player_buildings pb
               JOIN buildings_catalog bc ON pb.building_id = bc.id
               WHERE pb.user_id = ? AND pb.building_id = ?""",
            (user_id, building_id)
        )
        if not player or not pb:
            return False, "ساختمان یافت نشد."
        if pb["is_upgrading"]:
            return False, "در حال ارتقا است."
        if pb["level"] >= pb["max_level"]:
            return False, "به حداکثر سطح رسیده."
        cost = BuildingService.calc_upgrade_cost(pb["base_cost"], pb["cost_multiplier"], pb["level"])
        if player["coins"] < cost:
            return False, f"سکه کافی نیست (نیاز: {cost})"
        time_sec = BuildingService.calc_upgrade_time(pb["base_upgrade_time"], pb["level"])
        finish = datetime.utcnow() + timedelta(seconds=time_sec)

        await PlayerService.update_resources(user_id, coins=-cost)
        await db.execute(
            """UPDATE player_buildings SET is_upgrading = 1, upgrade_finish_time = ? WHERE user_id = ? AND building_id = ?""",
            (finish.isoformat(), user_id, building_id)
        )
        return True, f"⬆️ ارتقا آغاز شد! زمان: {time_sec} ثانیه"

    @staticmethod
    async def finish_upgrades(user_id: int) -> List[str]:
        db = await get_db()
        now = datetime.utcnow().isoformat()
        pending = await db.fetchall(
            """SELECT pb.*, bc.name_fa, bc.hp_per_level FROM player_buildings pb
               JOIN buildings_catalog bc ON pb.building_id = bc.id
               WHERE pb.user_id = ? AND pb.is_upgrading = 1 AND pb.upgrade_finish_time <= ?""",
            (user_id, now)
        )
        messages = []
        for p in pending:
            new_level = p["level"] + 1
            new_hp = p["hp_per_level"] * new_level
            await db.execute(
                """UPDATE player_buildings SET level = ?, hp = ?, max_hp = ?, is_upgrading = 0, upgrade_finish_time = NULL
                   WHERE id = ?""",
                (new_level, new_hp, new_hp, p["id"])
            )
            messages.append(f"✅ {p['name_fa']} به سطح {new_level} ارتقا یافت!")
        return messages

    @staticmethod
    async def collect_resources(user_id: int, building_id: int | None = None) -> Tuple[bool, str, Dict]:
        db = await get_db()
        await BuildingService.finish_upgrades(user_id)
        if building_id:
            buildings = await db.fetchall(
                """SELECT pb.*, bc.production_type, bc.base_production, bc.production_per_level, bc.name_fa
                   FROM player_buildings pb JOIN buildings_catalog bc ON pb.building_id = bc.id
                   WHERE pb.user_id = ? AND pb.building_id = ? AND bc.production_type IS NOT NULL""",
                (user_id, building_id)
            )
        else:
            buildings = await db.fetchall(
                """SELECT pb.*, bc.production_type, bc.base_production, bc.production_per_level, bc.name_fa
                   FROM player_buildings pb JOIN buildings_catalog bc ON pb.building_id = bc.id
                   WHERE pb.user_id = ? AND bc.production_type IS NOT NULL AND pb.is_upgrading = 0""",
                (user_id,)
            )

        total = {"coins": 0, "fuel": 0, "uranium": 0, "steel": 0, "titanium": 0, "crystal": 0, "xp": 0, "energy": 0}
        now = datetime.utcnow()
        for b in buildings:
            last = b["last_collected"]
            if isinstance(last, str):
                last = datetime.fromisoformat(last.replace("Z", ""))
            hours = max(0, (now - last).total_seconds() / 3600)
            if hours < (2/60):
                continue
            hours = min(hours, 12)  # Cap 12h
            prod = BuildingService.calc_production(b["base_production"], b["production_per_level"], b["level"])
            amount = int(prod * hours)
            if amount > 0 and b["production_type"] in total:
                total[b["production_type"]] += amount
            await db.execute(
                "UPDATE player_buildings SET last_collected = CURRENT_TIMESTAMP WHERE id = ?",
                (b["id"],)
            )

        if any(v > 0 for v in total.values()):
            kwargs = {k: v for k, v in total.items() if v > 0}
            await PlayerService.update_resources(user_id, **kwargs)
            parts = [f"{k}: +{v}" for k, v in kwargs.items()]
            return True, "💰 منابع جمع‌آوری شد:\n" + "\n".join(parts), total
        return False, "چیزی برای جمع‌آوری نیست (حداقل ۶ دقیقه صبر کنید).", {}

    @staticmethod
    async def repair_building(user_id: int, building_id: int) -> Tuple[bool, str]:
        db = await get_db()
        pb = await db.fetchone(
            "SELECT * FROM player_buildings WHERE user_id = ? AND building_id = ?",
            (user_id, building_id)
        )
        if not pb:
            return False, "ساختمان یافت نشد."
        if pb["hp"] >= pb["max_hp"]:
            return False, "نیازی به تعمیر نیست."
        missing = pb["max_hp"] - pb["hp"]
        cost = missing * 2
        player = await PlayerService.get(user_id)
        if player["coins"] < cost:
            return False, f"سکه کافی نیست (نیاز: {cost})"
        await PlayerService.update_resources(user_id, coins=-cost)
        await db.execute(
            "UPDATE player_buildings SET hp = max_hp WHERE id = ?",
            (pb["id"],)
        )
        return True, f"🔧 تعمیر شد! (-{cost} سکه)"
