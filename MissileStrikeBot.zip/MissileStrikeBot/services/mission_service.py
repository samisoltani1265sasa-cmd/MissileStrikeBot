"""Missions & Events service"""
from __future__ import annotations

from typing import Dict, List, Tuple
from database import get_db
from services.player_service import PlayerService


class MissionService:
    @staticmethod
    async def ensure_player_missions(user_id: int) -> None:
        db = await get_db()
        catalog = await db.fetchall("SELECT id FROM missions_catalog WHERE is_active = 1")
        for m in catalog:
            existing = await db.fetchone(
                "SELECT id FROM player_missions WHERE user_id = ? AND mission_id = ?",
                (user_id, m["id"])
            )
            if not existing:
                await db.execute(
                    "INSERT INTO player_missions (user_id, mission_id) VALUES (?, ?)",
                    (user_id, m["id"])
                )

    @staticmethod
    async def get_player_missions(user_id: int) -> List[Dict]:
        await MissionService.ensure_player_missions(user_id)
        db = await get_db()
        return await db.fetchall(
            """SELECT pm.*, mc.name_fa, mc.name_en, mc.description_fa, mc.mission_type,
                      mc.requirement_type, mc.requirement_value, mc.reward_coins, mc.reward_xp,
                      mc.reward_fuel, mc.reward_uranium
               FROM player_missions pm
               JOIN missions_catalog mc ON pm.mission_id = mc.id
               WHERE pm.user_id = ? AND mc.is_active = 1
               ORDER BY mc.mission_type, pm.is_completed, pm.is_claimed""",
            (user_id,)
        )

    @staticmethod
    async def update_progress(user_id: int, req_type: str, amount: int = 1) -> None:
        db = await get_db()
        missions = await db.fetchall(
            """SELECT pm.id, pm.progress, mc.requirement_value, mc.requirement_type
               FROM player_missions pm
               JOIN missions_catalog mc ON pm.mission_id = mc.id
               WHERE pm.user_id = ? AND pm.is_completed = 0 AND mc.requirement_type = ?""",
            (user_id, req_type)
        )
        for m in missions:
            new_progress = m["progress"] + amount
            completed = 1 if new_progress >= m["requirement_value"] else 0
            await db.execute(
                "UPDATE player_missions SET progress = ?, is_completed = ?, completed_at = CASE WHEN ? = 1 THEN CURRENT_TIMESTAMP ELSE NULL END WHERE id = ?",
                (min(new_progress, m["requirement_value"]), completed, completed, m["id"])
            )

    @staticmethod
    async def claim(user_id: int, mission_id: int) -> Tuple[bool, str]:
        db = await get_db()
        m = await db.fetchone(
            """SELECT pm.*, mc.reward_coins, mc.reward_xp, mc.reward_fuel, mc.reward_uranium, mc.name_fa
               FROM player_missions pm
               JOIN missions_catalog mc ON pm.mission_id = mc.id
               WHERE pm.user_id = ? AND pm.mission_id = ?""",
            (user_id, mission_id)
        )
        if not m:
            return False, "مأموریت یافت نشد."
        if not m["is_completed"]:
            return False, "هنوز تکمیل نشده."
        if m["is_claimed"]:
            return False, "پاداش قبلاً دریافت شده."
        await PlayerService.update_resources(
            user_id,
            coins=m["reward_coins"] or 0,
            xp=m["reward_xp"] or 0,
            fuel=m["reward_fuel"] or 0,
            uranium=m["reward_uranium"] or 0,
        )
        await db.execute(
            "UPDATE player_missions SET is_claimed = 1 WHERE id = ?",
            (m["id"],)
        )
        return True, f"🎁 پاداش مأموریت «{m['name_fa']}» دریافت شد!"
