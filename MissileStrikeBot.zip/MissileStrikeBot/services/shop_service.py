"""فروشگاه رسمی موشک"""
from __future__ import annotations
from typing import List, Dict, Tuple, Optional
from database import get_db
from services.player_service import PlayerService


class ShopService:
    @staticmethod
    async def list_missiles(rarity_filter: str | None = None, class_filter: str | None = None) -> List[Dict]:
        db = await get_db()
        sql = "SELECT * FROM missiles_catalog WHERE 1=1"
        params: list = []
        if rarity_filter == "common_uncommon":
            sql += " AND rarity IN ('common', 'uncommon')"
        elif rarity_filter == "rare_epic":
            sql += " AND rarity IN ('rare', 'epic')"
        elif rarity_filter == "legendary":
            sql += " AND rarity = 'legendary'"
        elif rarity_filter == "defense":
            sql += " AND is_defensive = 1"
        if class_filter:
            sql += " AND missile_class = ?"
            params.append(class_filter)
        if rarity_filter == "hypersonic":
            sql = "SELECT * FROM missiles_catalog WHERE missile_class = 'hypersonic'"
            params = []
        sql += " ORDER BY buy_cost ASC, required_level ASC"
        rows = await db.fetchall(sql, tuple(params))
        for r in rows:
            r["_filter"] = rarity_filter or "all"
        return rows

    @staticmethod
    async def buy_missile(user_id: int, missile_id: int, qty: int = 1) -> Tuple[bool, str]:
        db = await get_db()
        missile = await db.fetchone("SELECT * FROM missiles_catalog WHERE id = ?", (missile_id,))
        if not missile:
            return False, "موشک یافت نشد."
        player = await PlayerService.get(user_id)
        if not player:
            return False, "بازیکن یافت نشد."
        if player["level"] < missile["required_level"]:
            return False, f"سطح مورد نیاز: {missile['required_level']}"
        total = missile["buy_cost"] * qty
        if player["coins"] < total:
            return False, f"سکه کافی نیست! نیاز: {total} | موجودی: {player['coins']}"
        await PlayerService.update_resources(user_id, coins=-total)
        existing = await db.fetchone(
            "SELECT id, quantity FROM player_missiles WHERE user_id = ? AND missile_id = ?",
            (user_id, missile_id)
        )
        if existing:
            await db.execute(
                "UPDATE player_missiles SET quantity = quantity + ? WHERE user_id = ? AND missile_id = ?",
                (qty, user_id, missile_id)
            )
        else:
            await db.execute(
                "INSERT INTO player_missiles (user_id, missile_id, quantity) VALUES (?, ?, ?)",
                (user_id, missile_id, qty)
            )
        await db.execute(
            "UPDATE players SET missiles_owned = missiles_owned + ? WHERE user_id = ?",
            (qty, user_id)
        )
        return True, (
            f"✅ خرید موفق!\n"
            f"موشک: {missile['name_fa']} ({missile['name_en']}) ×{qty}\n"
            f"هزینه: {total} سکه"
        )

    @staticmethod
    async def get_missile(missile_id: int) -> Optional[Dict]:
        db = await get_db()
        return await db.fetchone("SELECT * FROM missiles_catalog WHERE id = ?", (missile_id,))
