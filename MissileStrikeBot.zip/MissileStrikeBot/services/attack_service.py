"""Combat / Attack service - live missile strike system"""
from __future__ import annotations

import random
import json
from typing import Optional, Dict, List, Tuple
from datetime import datetime, timedelta
from database import get_db
from config import settings
from services.player_service import PlayerService


class AttackService:
    @staticmethod
    async def get_player_missiles(user_id: int, offensive_only: bool = True) -> List[Dict]:
        db = await get_db()
        query = """
            SELECT pm.quantity, pm.is_ready, mc.*
            FROM player_missiles pm
            JOIN missiles_catalog mc ON pm.missile_id = mc.id
            WHERE pm.user_id = ? AND pm.quantity > 0
        """
        if offensive_only:
            query += " AND mc.is_defensive = 0"
        query += " ORDER BY mc.power DESC"
        return await db.fetchall(query, (user_id,))

    @staticmethod
    async def get_missile(missile_id: int) -> Optional[Dict]:
        db = await get_db()
        return await db.fetchone("SELECT * FROM missiles_catalog WHERE id = ?", (missile_id,))

    @staticmethod
    async def can_attack(attacker_id: int) -> Tuple[bool, str]:
        player = await PlayerService.regen_energy(attacker_id)
        if not player:
            return False, "بازیکن یافت نشد."
        if player.get("is_banned"):
            return False, "حساب شما مسدود است."
        if player["energy"] < 1:
            return False, "⚡ انرژی کافی ندارید! صبر کنید تا شارژ شود."
        if player.get("last_attack_time"):
            last = player["last_attack_time"]
            if isinstance(last, str):
                last = datetime.fromisoformat(last.replace("Z", ""))
            elapsed = (datetime.utcnow() - last).total_seconds()
            if elapsed < settings.ATTACK_COOLDOWN_SECONDS:
                remaining = int(settings.ATTACK_COOLDOWN_SECONDS - elapsed)
                return False, f"⏳ کول‌داون حمله: {remaining} ثانیه باقی مانده."
        # Hourly limit
        db = await get_db()
        hour_ago = (datetime.utcnow() - timedelta(hours=1)).isoformat()
        row = await db.fetchone(
            "SELECT COUNT(*) as c FROM attacks WHERE attacker_id = ? AND launch_time > ?",
            (attacker_id, hour_ago)
        )
        if row and row["c"] >= settings.MAX_ATTACKS_PER_HOUR:
            return False, f"🚫 محدودیت ساعتی: حداکثر {settings.MAX_ATTACKS_PER_HOUR} حمله در ساعت."
        return True, "OK"

    @staticmethod
    async def launch_attack(attacker_id: int, defender_id: int, missile_id: int) -> Tuple[bool, str, Optional[Dict]]:
        can, msg = await AttackService.can_attack(attacker_id)
        if not can:
            return False, msg, None

        if attacker_id == defender_id:
            return False, "نمی‌توانید به خودتان حمله کنید!", None

        db = await get_db()
        attacker = await PlayerService.get(attacker_id)
        defender = await PlayerService.get(defender_id)
        missile = await AttackService.get_missile(missile_id)

        if not attacker or not defender or not missile:
            return False, "اطلاعات نامعتبر.", None
        if defender.get("is_banned"):
            return False, "هدف مسدود است.", None
        if missile["is_defensive"]:
            return False, "این موشک دفاعی است و برای حمله استفاده نمی‌شود.", None
        if attacker["level"] < missile["required_level"]:
            return False, f"سطح مورد نیاز: {missile['required_level']}", None
        if attacker["fuel"] < missile["fuel_consumption"]:
            return False, f"⛽ سوخت کافی نیست (نیاز: {missile['fuel_consumption']})", None

        # Check ownership
        owned = await db.fetchone(
            "SELECT quantity FROM player_missiles WHERE user_id = ? AND missile_id = ?",
            (attacker_id, missile_id)
        )
        if not owned or owned["quantity"] < 1:
            return False, "این موشک را ندارید!", None

        # Calculate chances with defense modifiers
        defense_bonus = await AttackService._get_defense_bonus(defender_id)
        intercept_chance = min(0.95, missile["intercept_chance"] + defense_bonus * 0.01)
        hit_chance = max(0.1, missile["hit_chance"] - defense_bonus * 0.005)

        travel = missile["travel_time"]
        arrival = datetime.utcnow() + timedelta(seconds=travel)

        # Deduct resources
        await db.execute(
            "UPDATE player_missiles SET quantity = quantity - 1 WHERE user_id = ? AND missile_id = ?",
            (attacker_id, missile_id)
        )
        await PlayerService.update_resources(
            attacker_id,
            fuel=-missile["fuel_consumption"],
            energy=-1
        )
        await db.execute(
            "UPDATE players SET last_attack_time = CURRENT_TIMESTAMP, attacks_count = attacks_count + 1 WHERE user_id = ?",
            (attacker_id,)
        )

        cursor = await db.execute(
            """INSERT INTO attacks
               (attacker_id, defender_id, missile_id, missile_name, power, status,
                intercept_chance, hit_chance, travel_time, arrival_time)
               VALUES (?, ?, ?, ?, ?, 'in_flight', ?, ?, ?, ?)""",
            (
                attacker_id, defender_id, missile_id,
                f"{missile['name_fa']} ({missile['name_en']})",
                missile["power"], intercept_chance, hit_chance, travel,
                arrival.isoformat()
            )
        )
        attack_id = cursor.lastrowid

        attack_data = {
            "id": attack_id,
            "attacker_id": attacker_id,
            "defender_id": defender_id,
            "missile": missile,
            "missile_name": f"{missile['name_fa']} ({missile['name_en']})",
            "travel_time": travel,
            "arrival_time": arrival,
            "intercept_chance": intercept_chance,
            "hit_chance": hit_chance,
            "power": missile["power"],
        }
        return True, "حمله آغاز شد!", attack_data

    @staticmethod
    async def _get_defense_bonus(user_id: int) -> float:
        db = await get_db()
        row = await db.fetchone(
            """SELECT COALESCE(SUM(bc.defense_bonus * pb.level), 0) as bonus
               FROM player_buildings pb
               JOIN buildings_catalog bc ON pb.building_id = bc.id
               WHERE pb.user_id = ? AND bc.building_type = 'defense'""",
            (user_id,)
        )
        return float(row["bonus"]) if row else 0.0

    @staticmethod
    async def resolve_attack(attack_id: int) -> Dict:
        """Resolve an in-flight attack (call after travel_time)"""
        db = await get_db()
        attack = await db.fetchone("SELECT * FROM attacks WHERE id = ?", (attack_id,))
        if not attack or attack["status"] != "in_flight":
            return {"error": "حمله نامعتبر یا قبلاً حل شده"}

        interceptor_roll = random.random()
        if interceptor_roll < attack["intercept_chance"]:
            # Intercepted
            await db.execute(
                "UPDATE attacks SET status = 'intercepted', resolved_at = CURRENT_TIMESTAMP, damage = 0, report = ? WHERE id = ?",
                ("موشک توسط سامانه پدافند رهگیری شد! 🛡️", attack_id)
            )
            await db.execute(
                "UPDATE players SET successful_defenses = successful_defenses + 1, military_credit = military_credit + 5 WHERE user_id = ?",
                (attack["defender_id"],)
            )
            return {
                "status": "intercepted",
                "message": "🛡️ موشک رهگیری شد!",
                "damage": 0,
                "loot": {},
            }

        hit_roll = random.random()
        if hit_roll > attack["hit_chance"]:
            await db.execute(
                "UPDATE attacks SET status = 'missed', resolved_at = CURRENT_TIMESTAMP, damage = 0, report = ? WHERE id = ?",
                ("موشک به هدف اصابت نکرد و منحرف شد.", attack_id)
            )
            return {
                "status": "missed",
                "message": "❌ موشک منحرف شد و اصابت نکرد!",
                "damage": 0,
                "loot": {},
            }

        # HIT - calculate damage
        base_power = attack["power"]
        variance = random.uniform(0.85, 1.15)
        damage = int(base_power * variance)

        # Apply to buildings
        buildings = await db.fetchall(
            """SELECT pb.*, bc.name_fa, bc.name_en, bc.hp_per_level
               FROM player_buildings pb
               JOIN buildings_catalog bc ON pb.building_id = bc.id
               WHERE pb.user_id = ? AND pb.hp > 0
               ORDER BY RANDOM()""",
            (attack["defender_id"],)
        )

        damaged_building = None
        remaining_damage = damage
        for b in buildings:
            if remaining_damage <= 0:
                break
            take = min(b["hp"], remaining_damage)
            new_hp = b["hp"] - take
            await db.execute(
                "UPDATE player_buildings SET hp = ? WHERE id = ?",
                (new_hp, b["id"])
            )
            remaining_damage -= take
            if take > 0 and not damaged_building:
                damaged_building = f"{b['name_fa']} ({b['name_en']})"
                if new_hp <= 0:
                    damaged_building += " [تخریب‌شده]"

        # Loot resources (10-25% of damage as coins equivalent)
        loot_percent = random.uniform(0.08, 0.22)
        defender = await PlayerService.get(attack["defender_id"])
        loot = {}
        if defender:
            coins_loot = min(defender["coins"], int(damage * loot_percent * 0.5))
            fuel_loot = min(defender["fuel"], int(damage * loot_percent * 0.1))
            steel_loot = min(defender["steel"], int(damage * loot_percent * 0.05))
            if coins_loot > 0:
                loot["coins"] = coins_loot
                await PlayerService.update_resources(attack["defender_id"], coins=-coins_loot)
                await PlayerService.update_resources(attack["attacker_id"], coins=coins_loot)
            if fuel_loot > 0:
                loot["fuel"] = fuel_loot
                await PlayerService.update_resources(attack["defender_id"], fuel=-fuel_loot)
                await PlayerService.update_resources(attack["attacker_id"], fuel=fuel_loot)
            if steel_loot > 0:
                loot["steel"] = steel_loot
                await PlayerService.update_resources(attack["defender_id"], steel=-steel_loot)
                await PlayerService.update_resources(attack["attacker_id"], steel=steel_loot)

        # Rank points
        rank_gain = max(1, damage // 50)
        await PlayerService.update_resources(attack["attacker_id"], rank_points=rank_gain, xp=damage // 10, military_credit=damage // 100)
        await PlayerService.update_resources(attack["defender_id"], rank_points=-max(0, rank_gain // 3))

        report = f"خسارت: {damage} | ساختمان: {damaged_building or 'هیچ'} | غنیمت: {loot}"
        await db.execute(
            """UPDATE attacks SET status = 'hit', damage = ?, resources_looted = ?, building_damaged = ?,
               resolved_at = CURRENT_TIMESTAMP, report = ? WHERE id = ?""",
            (damage, json.dumps(loot), damaged_building, report, attack_id)
        )

        return {
            "status": "hit",
            "message": "💥 برخورد موفق!",
            "damage": damage,
            "building": damaged_building,
            "loot": loot,
            "rank_gain": rank_gain,
        }

    @staticmethod
    async def get_pending_attacks() -> List[Dict]:
        db = await get_db()
        now = datetime.utcnow().isoformat()
        return await db.fetchall(
            "SELECT * FROM attacks WHERE status = 'in_flight' AND arrival_time <= ?",
            (now,)
        )

    @staticmethod
    async def get_attack_history(user_id: int, limit: int = 15) -> List[Dict]:
        db = await get_db()
        return await db.fetchall(
            """SELECT a.*, 
                      atk.first_name as attacker_name, def.first_name as defender_name
               FROM attacks a
               JOIN players atk ON a.attacker_id = atk.user_id
               JOIN players def ON a.defender_id = def.user_id
               WHERE a.attacker_id = ? OR a.defender_id = ?
               ORDER BY a.launch_time DESC LIMIT ?""",
            (user_id, user_id, limit)
        )
