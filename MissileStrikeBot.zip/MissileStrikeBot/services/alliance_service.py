"""Alliance system service"""
from __future__ import annotations

from typing import Optional, Dict, List, Tuple
from database import get_db
from services.player_service import PlayerService


class AllianceService:
    @staticmethod
    async def create(user_id: int, name: str, tag: str) -> Tuple[bool, str]:
        db = await get_db()
        player = await PlayerService.get(user_id)
        if not player:
            return False, "بازیکن یافت نشد."
        if player.get("alliance_id"):
            return False, "شما در حال حاضر عضو یک اتحاد هستید."
        if len(name) < 3 or len(name) > 30:
            return False, "نام اتحاد باید ۳ تا ۳۰ کاراکتر باشد."
        if len(tag) < 2 or len(tag) > 5:
            return False, "تگ باید ۲ تا ۵ کاراکتر باشد."
        if player["coins"] < 1000:
            return False, "برای ایجاد اتحاد ۱۰۰۰ سکه نیاز است."

        existing = await db.fetchone("SELECT id FROM alliances WHERE name = ? OR tag = ?", (name, tag.upper()))
        if existing:
            return False, "نام یا تگ قبلاً استفاده شده."

        await PlayerService.update_resources(user_id, coins=-1000)
        cursor = await db.execute(
            "INSERT INTO alliances (name, tag, leader_id) VALUES (?, ?, ?)",
            (name, tag.upper(), user_id)
        )
        alliance_id = cursor.lastrowid
        await db.execute(
            "INSERT INTO alliance_members (alliance_id, user_id, role) VALUES (?, ?, 'leader')",
            (alliance_id, user_id)
        )
        await db.execute("UPDATE players SET alliance_id = ? WHERE user_id = ?", (alliance_id, user_id))
        return True, f"✅ اتحاد [{tag.upper()}] {name} ایجاد شد!"

    @staticmethod
    async def join(user_id: int, alliance_id: int) -> Tuple[bool, str]:
        db = await get_db()
        player = await PlayerService.get(user_id)
        if player.get("alliance_id"):
            return False, "شما عضو اتحاد دیگری هستید."
        alliance = await db.fetchone("SELECT * FROM alliances WHERE id = ?", (alliance_id,))
        if not alliance:
            return False, "اتحاد یافت نشد."
        count = await db.fetchone(
            "SELECT COUNT(*) as c FROM alliance_members WHERE alliance_id = ?", (alliance_id,)
        )
        if count and count["c"] >= alliance["max_members"]:
            return False, "اتحاد پر است."
        await db.execute(
            "INSERT INTO alliance_members (alliance_id, user_id, role) VALUES (?, ?, 'member')",
            (alliance_id, user_id)
        )
        await db.execute("UPDATE players SET alliance_id = ? WHERE user_id = ?", (alliance_id, user_id))
        return True, f"✅ به اتحاد [{alliance['tag']}] پیوستید!"

    @staticmethod
    async def leave(user_id: int) -> Tuple[bool, str]:
        db = await get_db()
        player = await PlayerService.get(user_id)
        if not player or not player.get("alliance_id"):
            return False, "عضو هیچ اتحادی نیستید."
        member = await db.fetchone(
            "SELECT role FROM alliance_members WHERE user_id = ? AND alliance_id = ?",
            (user_id, player["alliance_id"])
        )
        if member and member["role"] == "leader":
            count = await db.fetchone(
                "SELECT COUNT(*) as c FROM alliance_members WHERE alliance_id = ?",
                (player["alliance_id"],)
            )
            if count and count["c"] > 1:
                return False, "رهبر نمی‌تواند ترک کند تا زمانی که اعضا هستند. ابتدا رهبری را منتقل کنید."
            # Disband
            await db.execute("DELETE FROM alliance_members WHERE alliance_id = ?", (player["alliance_id"],))
            await db.execute("DELETE FROM alliances WHERE id = ?", (player["alliance_id"],))
        else:
            await db.execute(
                "DELETE FROM alliance_members WHERE user_id = ? AND alliance_id = ?",
                (user_id, player["alliance_id"])
            )
        await db.execute("UPDATE players SET alliance_id = NULL WHERE user_id = ?", (user_id,))
        return True, "از اتحاد خارج شدید."

    @staticmethod
    async def get(alliance_id: int) -> Optional[Dict]:
        db = await get_db()
        return await db.fetchone("SELECT * FROM alliances WHERE id = ?", (alliance_id,))

    @staticmethod
    async def get_members(alliance_id: int) -> List[Dict]:
        db = await get_db()
        return await db.fetchall(
            """SELECT am.*, p.first_name, p.username, p.level, p.rank_points
               FROM alliance_members am
               JOIN players p ON am.user_id = p.user_id
               WHERE am.alliance_id = ?
               ORDER BY CASE am.role WHEN 'leader' THEN 0 WHEN 'officer' THEN 1 ELSE 2 END, am.contribution DESC""",
            (alliance_id,)
        )

    @staticmethod
    async def list_alliances(limit: int = 30) -> List[Dict]:
        db = await get_db()
        return await db.fetchall(
            """SELECT a.*, (SELECT COUNT(*) FROM alliance_members WHERE alliance_id = a.id) as member_count
               FROM alliances a ORDER BY a.territory_points DESC, a.level DESC LIMIT ?""",
            (limit,)
        )

    @staticmethod
    async def donate(user_id: int, resource: str, amount: int) -> Tuple[bool, str]:
        allowed = {"coins", "fuel", "uranium", "steel", "titanium", "crystal"}
        if resource not in allowed or amount <= 0:
            return False, "منبع نامعتبر."
        player = await PlayerService.get(user_id)
        if not player or not player.get("alliance_id"):
            return False, "عضو اتحاد نیستید."
        if player.get(resource, 0) < amount:
            return False, "موجودی کافی نیست."
        db = await get_db()
        await PlayerService.update_resources(user_id, **{resource: -amount})
        await db.execute(
            f"UPDATE alliances SET {resource} = {resource} + ? WHERE id = ?",
            (amount, player["alliance_id"])
        )
        await db.execute(
            "UPDATE alliance_members SET contribution = contribution + ? WHERE user_id = ? AND alliance_id = ?",
            (amount, user_id, player["alliance_id"])
        )
        return True, f"✅ {amount} {resource} به اتحاد اهدا شد."

    @staticmethod
    async def get_territories() -> List[Dict]:
        db = await get_db()
        return await db.fetchall(
            """SELECT t.*, a.name as alliance_name, a.tag as alliance_tag
               FROM territories t
               LEFT JOIN alliances a ON t.owner_alliance_id = a.id
               ORDER BY t.region, t.name_en"""
        )
