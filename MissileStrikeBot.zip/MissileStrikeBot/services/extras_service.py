"""۱۰ قابلیت اضافی — جدا از منطق اصلی تا چیزی خراب نشود"""
from __future__ import annotations
from typing import Optional, Dict, List, Tuple
from datetime import datetime, timedelta
import random
from database import get_db
from services.player_service import PlayerService


class ExtrasService:
    # ---------- ستون‌های اضافه (ایمن) ----------
    @staticmethod
    async def ensure_columns():
        db = await get_db()
        cols = [
            ("last_attacker_id", "INTEGER"),
            ("last_attacked_at", "TIMESTAMP"),
            ("daily_claim_at", "TIMESTAMP"),
            ("shield_until", "TIMESTAMP"),
            ("title", "TEXT DEFAULT ''"),
            ("spy_count", "INTEGER DEFAULT 0"),
            ("gifts_sent", "INTEGER DEFAULT 0"),
        ]
        for name, typ in cols:
            try:
                await db.execute(f"ALTER TABLE players ADD COLUMN {name} {typ}")
            except Exception:
                pass  # از قبل وجود دارد

    # ---------- ۱. ذخیره آخرین مهاجم (برای انتقام و خبر) ----------
    @staticmethod
    async def set_last_attacker(defender_id: int, attacker_id: int):
        db = await get_db()
        await db.execute(
            "UPDATE players SET last_attacker_id = ?, last_attacked_at = CURRENT_TIMESTAMP WHERE user_id = ?",
            (attacker_id, defender_id)
        )

    # ---------- ۲. انتقام ----------
    @staticmethod
    async def get_revenge_target(user_id: int) -> Optional[int]:
        p = await PlayerService.get(user_id)
        if not p or not p.get("last_attacker_id"):
            return None
        # فقط تا ۲ ساعت
        last = p.get("last_attacked_at")
        if last:
            if isinstance(last, str):
                try:
                    last = datetime.fromisoformat(last.replace("Z", ""))
                except Exception:
                    last = None
            if last and (datetime.utcnow() - last).total_seconds() > 7200:
                return None
        return p["last_attacker_id"]

    # ---------- ۳. پاداش روزانه ----------
    @staticmethod
    async def claim_daily(user_id: int) -> Tuple[bool, str]:
        db = await get_db()
        p = await PlayerService.get(user_id)
        if not p:
            return False, "بازیکن یافت نشد."
        now = datetime.utcnow()
        last = p.get("daily_claim_at")
        if last:
            if isinstance(last, str):
                try:
                    last = datetime.fromisoformat(last.replace("Z", ""))
                except Exception:
                    last = None
            if last and (now - last).total_seconds() < 86400:
                left = int(86400 - (now - last).total_seconds())
                h, m = left // 3600, (left % 3600) // 60
                return False, f"⏳ پاداش بعدی تا {h}س {m}د دیگر."
        coins = 300 + p["level"] * 50
        fuel = 20 + p["level"] * 2
        xp = 30 + p["level"] * 5
        await PlayerService.update_resources(user_id, coins=coins, fuel=fuel, xp=xp)
        await db.execute("UPDATE players SET daily_claim_at = CURRENT_TIMESTAMP WHERE user_id = ?", (user_id,))
        return True, f"🎁 پاداش روزانه!\n💰 +{coins} سکه\n⛽ +{fuel} سوخت\n⭐ +{xp} XP"

    # ---------- ۴. القاب ----------
    @staticmethod
    async def calc_title(user_id: int) -> str:
        p = await PlayerService.get(user_id)
        if not p:
            return ""
        title = "تازه‌کار"
        if p["successful_defenses"] >= 50:
            title = "دیوار آهنین"
        elif p["successful_defenses"] >= 20:
            title = "مدافع"
        if p["attacks_count"] >= 100:
            title = "ژنرال موشکی"
        elif p["attacks_count"] >= 50:
            title = "شکارچی"
        elif p["attacks_count"] >= 20:
            title = "رزمنده"
        if p["coins"] >= 100000:
            title = "میلیونر جنگی"
        elif p["coins"] >= 20000:
            title = "ثروتمند"
        if p["level"] >= 20:
            title = "افسانه"
        elif p["level"] >= 10:
            title = "کهنه‌سرباز"
        db = await get_db()
        await db.execute("UPDATE players SET title = ? WHERE user_id = ?", (title, user_id))
        return title

    @staticmethod
    async def get_title(user_id: int) -> str:
        p = await PlayerService.get(user_id)
        if p and p.get("title"):
            return p["title"]
        return await ExtrasService.calc_title(user_id)

    # ---------- ۵. جاسوسی ----------
    @staticmethod
    async def spy(user_id: int, target_id: int) -> Tuple[bool, str]:
        if user_id == target_id:
            return False, "روی خودت جاسوسی؟ 😅"
        me = await PlayerService.get(user_id)
        target = await PlayerService.get(target_id)
        if not me or not target:
            return False, "بازیکن یافت نشد."
        cost = 30
        if me["fuel"] < cost:
            return False, f"⛽ سوخت کافی نیست (نیاز: {cost})"
        await PlayerService.update_resources(user_id, fuel=-cost)
        db = await get_db()
        await db.execute("UPDATE players SET spy_count = COALESCE(spy_count,0) + 1 WHERE user_id = ?", (user_id,))
        # شانس لو رفتن ۲۰٪
        exposed = random.random() < 0.20
        missiles = await db.fetchone(
            "SELECT COALESCE(SUM(quantity),0) as c FROM player_missiles WHERE user_id = ?", (target_id,)
        )
        buildings = await db.fetchone(
            "SELECT COUNT(*) as c FROM player_buildings WHERE user_id = ?", (target_id,)
        )
        title = await ExtrasService.get_title(target_id)
        report = (
            f"🕵️ <b>گزارش جاسوسی</b>\n\n"
            f"هدف: {target.get('first_name')} | لقب: {title}\n"
            f"📈 سطح: {target['level']}\n"
            f"💰 سکه (تقریبی): ~{max(0, target['coins'] + random.randint(-100, 100))}\n"
            f"⚡ انرژی: {target['energy']}/{target['max_energy']}\n"
            f"🚀 تعداد موشک: ~{missiles['c'] if missiles else 0}\n"
            f"🏢 ساختمان‌ها: {buildings['c'] if buildings else 0}\n"
            f"🏆 امتیاز: {target['rank_points']}\n"
        )
        if target.get("shield_until"):
            report += "🛡️ سپر دفاعی: احتمالاً فعال\n"
        if exposed:
            report += "\n⚠️ <b>لو رفتی!</b> دشمن متوجه جاسوسی شد."
        return True, report, exposed, target_id  # type: ignore

    # ---------- ۶. سپر دفاعی ----------
    @staticmethod
    async def activate_shield(user_id: int, hours: int = 4) -> Tuple[bool, str]:
        p = await PlayerService.get(user_id)
        if not p:
            return False, "یافت نشد."
        cost = 500
        if p["coins"] < cost:
            return False, f"سکه کافی نیست (نیاز: {cost})"
        # اگر سپر فعال است
        su = p.get("shield_until")
        if su:
            if isinstance(su, str):
                try:
                    su = datetime.fromisoformat(su.replace("Z", ""))
                except Exception:
                    su = None
            if su and su > datetime.utcnow():
                return False, "سپر هنوز فعال است."
        until = datetime.utcnow() + timedelta(hours=hours)
        db = await get_db()
        await PlayerService.update_resources(user_id, coins=-cost)
        await db.execute("UPDATE players SET shield_until = ? WHERE user_id = ?", (until.isoformat(), user_id))
        return True, f"🛡️ سپر دفاعی برای {hours} ساعت فعال شد!\nتا آن زمان کسی نمی‌تواند به تو حمله کند."

    @staticmethod
    async def has_shield(user_id: int) -> bool:
        p = await PlayerService.get(user_id)
        if not p or not p.get("shield_until"):
            return False
        su = p["shield_until"]
        if isinstance(su, str):
            try:
                su = datetime.fromisoformat(su.replace("Z", ""))
            except Exception:
                return False
        return su > datetime.utcnow()

    # ---------- ۷. رتبه بازیکنان یک لیست (برای گروه) ----------
    @staticmethod
    async def top_players(limit: int = 10) -> List[Dict]:
        return await PlayerService.get_top(limit, "rank_points")

    # ---------- ۸. انتقال سکه ----------
    @staticmethod
    async def transfer_coins(from_id: int, to_id: int, amount: int) -> Tuple[bool, str]:
        if amount <= 0:
            return False, "مقدار نامعتبر."
        if from_id == to_id:
            return False, "به خودت؟"
        tax = max(1, int(amount * 0.05))  # ۵٪ مالیات
        total = amount + tax
        sender = await PlayerService.get(from_id)
        receiver = await PlayerService.get(to_id)
        if not sender or not receiver:
            return False, "بازیکن یافت نشد."
        if sender["coins"] < total:
            return False, f"سکه کافی نیست (با مالیات: {total})"
        await PlayerService.update_resources(from_id, coins=-total)
        await PlayerService.update_resources(to_id, coins=amount)
        db = await get_db()
        await db.execute("UPDATE players SET gifts_sent = COALESCE(gifts_sent,0) + 1 WHERE user_id = ?", (from_id,))
        return True, f"✅ {amount} سکه ارسال شد به {receiver.get('first_name')}\nمالیات: {tax}"

    # ---------- ۹. دستاوردها ----------
    @staticmethod
    async def get_achievements(user_id: int) -> str:
        p = await PlayerService.get(user_id)
        if not p:
            return "—"
        title = await ExtrasService.get_title(user_id)
        lines = [
            f"🏅 <b>دستاوردها — {p.get('first_name')}</b>\n",
            f"لقب فعلی: <b>{title}</b>\n",
            f"{'✅' if p['attacks_count'] >= 1 else '⬜'} اولین شلیک ({p['attacks_count']}/1)",
            f"{'✅' if p['attacks_count'] >= 10 else '⬜'} ۱۰ حمله ({p['attacks_count']}/10)",
            f"{'✅' if p['attacks_count'] >= 50 else '⬜'} ۵۰ حمله ({p['attacks_count']}/50)",
            f"{'✅' if p['successful_defenses'] >= 5 else '⬜'} ۵ دفاع ({p['successful_defenses']}/5)",
            f"{'✅' if p['successful_defenses'] >= 20 else '⬜'} ۲۰ دفاع ({p['successful_defenses']}/20)",
            f"{'✅' if p['level'] >= 5 else '⬜'} سطح ۵ ({p['level']}/5)",
            f"{'✅' if p['level'] >= 10 else '⬜'} سطح ۱۰ ({p['level']}/10)",
            f"{'✅' if p['coins'] >= 5000 else '⬜'} ۵۰۰۰ سکه",
            f"{'✅' if p['buildings_count'] >= 5 else '⬜'} ۵ ساختمان ({p['buildings_count']}/5)",
            f"{'✅' if p.get('alliance_id') else '⬜'} عضویت در اتحاد",
            f"{'✅' if (p.get('spy_count') or 0) >= 3 else '⬜'} ۳ جاسوسی ({p.get('spy_count') or 0}/3)",
            f"{'✅' if (p.get('gifts_sent') or 0) >= 1 else '⬜'} کمک به دیگران",
        ]
        return "\n".join(lines)

    # ---------- ۱۰. آمار سریع برای راهنما/وضعیت ----------
    @staticmethod
    async def quick_status(user_id: int) -> str:
        p = await PlayerService.regen_energy(user_id)
        title = await ExtrasService.get_title(user_id)
        shield = "🛡️ فعال" if await ExtrasService.has_shield(user_id) else "—"
        return (
            f"📛 {p.get('first_name')} | {title}\n"
            f"Lv.{p['level']} | 💰{p['coins']} | ⛽{p['fuel']} | ⚡{p['energy']}/{p['max_energy']}\n"
            f"سپر: {shield}"
        )
