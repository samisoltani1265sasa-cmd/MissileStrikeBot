"""Player management service"""
from __future__ import annotations

from typing import Optional, Dict, List
from datetime import datetime, timedelta
from database import get_db
from config import settings
from utils.helpers import calculate_level_xp, xp_to_level


class PlayerService:
    @staticmethod
    async def get_or_create(user_id: int, username: str | None, first_name: str, last_name: str | None = None) -> Dict:
        db = await get_db()
        player = await db.fetchone("SELECT * FROM players WHERE user_id = ?", (user_id,))
        if player:
            await db.execute(
                "UPDATE players SET username = ?, first_name = ?, last_name = ?, last_active = CURRENT_TIMESTAMP WHERE user_id = ?",
                (username, first_name, last_name, user_id)
            )
            player = await db.fetchone("SELECT * FROM players WHERE user_id = ?", (user_id,))
            return player

        await db.execute(
            """INSERT INTO players (user_id, username, first_name, last_name, coins, fuel, steel, energy, max_energy)
               VALUES (?, ?, ?, ?, 500, 100, 50, 20, 20)""",
            (user_id, username, first_name, last_name)
        )
        # Give starter buildings: Command Center + Gold Mine
        await db.execute(
            "INSERT INTO player_buildings (user_id, building_id, level, hp, max_hp) VALUES (?, 1, 1, 500, 500)",
            (user_id,)
        )
        gold = await db.fetchone("SELECT id, hp_per_level FROM buildings_catalog WHERE name_en = 'Gold Mine'")
        if gold:
            hp = gold["hp_per_level"] or 200
            await db.execute(
                "INSERT OR IGNORE INTO player_buildings (user_id, building_id, level, hp, max_hp) VALUES (?, ?, 1, ?, ?)",
                (user_id, gold["id"], hp, hp)
            )
            await db.execute("UPDATE players SET buildings_count = 2 WHERE user_id = ?", (user_id,))
        # Starter missiles
        for name_en, qty in [("Grad", 5), ("Scud", 2), ("Harpoon", 1)]:
            m = await db.fetchone("SELECT id FROM missiles_catalog WHERE name_en = ?", (name_en,))
            if m:
                await db.execute(
                    "INSERT OR IGNORE INTO player_missiles (user_id, missile_id, quantity) VALUES (?, ?, ?)",
                    (user_id, m["id"], qty)
                )
        return await db.fetchone("SELECT * FROM players WHERE user_id = ?", (user_id,))

    @staticmethod
    async def get(user_id: int) -> Optional[Dict]:
        db = await get_db()
        return await db.fetchone("SELECT * FROM players WHERE user_id = ?", (user_id,))

    @staticmethod
    async def update_resources(user_id: int, **resources) -> None:
        db = await get_db()
        allowed = {"coins", "fuel", "uranium", "steel", "titanium", "crystal", "military_credit", "xp", "energy", "rank_points"}
        sets = []
        params = []
        for k, v in resources.items():
            if k in allowed:
                sets.append(f"{k} = {k} + ?")
                params.append(v)
        if not sets:
            return
        params.append(user_id)
        await db.execute(
            f"UPDATE players SET {', '.join(sets)}, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?",
            tuple(params)
        )
        # Level up check
        player = await PlayerService.get(user_id)
        if player:
            level, _, needed = xp_to_level(player["xp"])
            if level > player["level"]:
                await db.execute(
                    "UPDATE players SET level = ?, max_energy = max_energy + ? WHERE user_id = ?",
                    (level, (level - player["level"]) * 2, user_id)
                )

    @staticmethod
    async def set_resources(user_id: int, **resources) -> None:
        db = await get_db()
        allowed = {"coins", "fuel", "uranium", "steel", "titanium", "crystal", "military_credit", "xp", "energy", "is_banned", "ban_reason"}
        sets = []
        params = []
        for k, v in resources.items():
            if k in allowed:
                sets.append(f"{k} = ?")
                params.append(v)
        if not sets:
            return
        params.append(user_id)
        await db.execute(
            f"UPDATE players SET {', '.join(sets)}, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?",
            tuple(params)
        )

    @staticmethod
    async def regen_energy(user_id: int) -> Dict:
        db = await get_db()
        player = await PlayerService.get(user_id)
        if not player:
            return {}
        now = datetime.utcnow()
        last = datetime.fromisoformat(player["last_energy_update"].replace("Z", "")) if isinstance(player["last_energy_update"], str) else player["last_energy_update"]
        if last is None:
            last = now
        minutes = (now - last).total_seconds() / 60
        regen = int(minutes / settings.ENERGY_REGEN_MINUTES)
        if regen > 0 and player["energy"] < player["max_energy"]:
            new_energy = min(player["max_energy"], player["energy"] + regen)
            await db.execute(
                "UPDATE players SET energy = ?, last_energy_update = CURRENT_TIMESTAMP WHERE user_id = ?",
                (new_energy, user_id)
            )
            player["energy"] = new_energy
        return player

    @staticmethod
    async def get_top(limit: int = 20, order_by: str = "rank_points") -> List[Dict]:
        db = await get_db()
        allowed = {"rank_points", "level", "coins", "attacks_count", "successful_defenses", "xp"}
        col = order_by if order_by in allowed else "rank_points"
        return await db.fetchall(
            f"SELECT user_id, username, first_name, level, xp, coins, rank_points, attacks_count, successful_defenses FROM players WHERE is_banned = 0 ORDER BY {col} DESC LIMIT ?",
            (limit,)
        )

    @staticmethod
    async def search_players(query: str, exclude_id: int, limit: int = 20) -> List[Dict]:
        db = await get_db()
        return await db.fetchall(
            """SELECT user_id, username, first_name, level, rank_points FROM players
               WHERE is_banned = 0 AND user_id != ? AND (username LIKE ? OR first_name LIKE ?)
               ORDER BY rank_points DESC LIMIT ?""",
            (exclude_id, f"%{query}%", f"%{query}%", limit)
        )

    @staticmethod
    async def get_random_targets(exclude_id: int, limit: int = 15) -> List[Dict]:
        db = await get_db()
        return await db.fetchall(
            """SELECT user_id, username, first_name, level, rank_points FROM players
               WHERE is_banned = 0 AND user_id != ? AND level >= 1
               ORDER BY RANDOM() LIMIT ?""",
            (exclude_id, limit)
        )

    @staticmethod
    async def count_players() -> int:
        db = await get_db()
        row = await db.fetchone("SELECT COUNT(*) as c FROM players")
        return row["c"] if row else 0
