"""Market / Trading service"""
from __future__ import annotations

from typing import Optional, Dict, List, Tuple
from datetime import datetime, timedelta
from database import get_db
from services.player_service import PlayerService


class MarketService:
    @staticmethod
    async def list_item(seller_id: int, item_type: str, quantity: int, price: int, item_id: int | None = None) -> Tuple[bool, str]:
        if quantity <= 0 or price <= 0:
            return False, "مقدار و قیمت باید مثبت باشند."
        player = await PlayerService.get(seller_id)
        if not player:
            return False, "بازیکن یافت نشد."

        db = await get_db()
        if item_type == "missile":
            if not item_id:
                return False, "موشک مشخص نشده."
            owned = await db.fetchone(
                "SELECT quantity FROM player_missiles WHERE user_id = ? AND missile_id = ?",
                (seller_id, item_id)
            )
            if not owned or owned["quantity"] < quantity:
                return False, "تعداد موشک کافی نیست."
            await db.execute(
                "UPDATE player_missiles SET quantity = quantity - ? WHERE user_id = ? AND missile_id = ?",
                (quantity, seller_id, item_id)
            )
        elif item_type in ("fuel", "uranium", "steel", "titanium", "crystal"):
            if player.get(item_type, 0) < quantity:
                return False, "موجودی کافی نیست."
            await PlayerService.update_resources(seller_id, **{item_type: -quantity})
        else:
            return False, "نوع آیتم نامعتبر."

        expires = (datetime.utcnow() + timedelta(days=3)).isoformat()
        await db.execute(
            """INSERT INTO market_listings (seller_id, item_type, item_id, quantity, price_per_unit, expires_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (seller_id, item_type, item_id, quantity, price, expires)
        )
        return True, "✅ آگهی در بازار ثبت شد."

    @staticmethod
    async def get_listings(item_type: str | None = None, limit: int = 30) -> List[Dict]:
        db = await get_db()
        now = datetime.utcnow().isoformat()
        if item_type:
            return await db.fetchall(
                """SELECT ml.*, p.first_name as seller_name, mc.name_fa as missile_name
                   FROM market_listings ml
                   JOIN players p ON ml.seller_id = p.user_id
                   LEFT JOIN missiles_catalog mc ON ml.item_id = mc.id AND ml.item_type = 'missile'
                   WHERE ml.is_active = 1 AND (ml.expires_at IS NULL OR ml.expires_at > ?) AND ml.item_type = ?
                   ORDER BY ml.price_per_unit ASC LIMIT ?""",
                (now, item_type, limit)
            )
        return await db.fetchall(
            """SELECT ml.*, p.first_name as seller_name, mc.name_fa as missile_name
               FROM market_listings ml
               JOIN players p ON ml.seller_id = p.user_id
               LEFT JOIN missiles_catalog mc ON ml.item_id = mc.id AND ml.item_type = 'missile'
               WHERE ml.is_active = 1 AND (ml.expires_at IS NULL OR ml.expires_at > ?)
               ORDER BY ml.created_at DESC LIMIT ?""",
            (now, limit)
        )

    @staticmethod
    async def buy(buyer_id: int, listing_id: int, qty: int = 1) -> Tuple[bool, str]:
        db = await get_db()
        listing = await db.fetchone("SELECT * FROM market_listings WHERE id = ? AND is_active = 1", (listing_id,))
        if not listing:
            return False, "آگهی یافت نشد."
        if listing["seller_id"] == buyer_id:
            return False, "نمی‌توانید از خودتان بخرید."
        if qty > listing["quantity"] or qty <= 0:
            return False, "تعداد نامعتبر."
        total = qty * listing["price_per_unit"]
        buyer = await PlayerService.get(buyer_id)
        if not buyer or buyer["coins"] < total:
            return False, f"سکه کافی نیست (نیاز: {total})"

        await PlayerService.update_resources(buyer_id, coins=-total)
        await PlayerService.update_resources(listing["seller_id"], coins=total)

        if listing["item_type"] == "missile":
            existing = await db.fetchone(
                "SELECT id FROM player_missiles WHERE user_id = ? AND missile_id = ?",
                (buyer_id, listing["item_id"])
            )
            if existing:
                await db.execute(
                    "UPDATE player_missiles SET quantity = quantity + ? WHERE user_id = ? AND missile_id = ?",
                    (qty, buyer_id, listing["item_id"])
                )
            else:
                await db.execute(
                    "INSERT INTO player_missiles (user_id, missile_id, quantity) VALUES (?, ?, ?)",
                    (buyer_id, listing["item_id"], qty)
                )
        else:
            await PlayerService.update_resources(buyer_id, **{listing["item_type"]: qty})

        new_qty = listing["quantity"] - qty
        if new_qty <= 0:
            await db.execute("UPDATE market_listings SET is_active = 0, quantity = 0 WHERE id = ?", (listing_id,))
        else:
            await db.execute("UPDATE market_listings SET quantity = ? WHERE id = ?", (new_qty, listing_id))
        return True, f"✅ خرید موفق! {qty} عدد به قیمت {total} سکه."

    @staticmethod
    async def my_listings(user_id: int) -> List[Dict]:
        db = await get_db()
        return await db.fetchall(
            "SELECT * FROM market_listings WHERE seller_id = ? AND is_active = 1 ORDER BY created_at DESC",
            (user_id,)
        )

    @staticmethod
    async def cancel_listing(user_id: int, listing_id: int) -> Tuple[bool, str]:
        db = await get_db()
        listing = await db.fetchone(
            "SELECT * FROM market_listings WHERE id = ? AND seller_id = ? AND is_active = 1",
            (listing_id, user_id)
        )
        if not listing:
            return False, "آگهی یافت نشد."
        # Return items
        if listing["item_type"] == "missile":
            existing = await db.fetchone(
                "SELECT id FROM player_missiles WHERE user_id = ? AND missile_id = ?",
                (user_id, listing["item_id"])
            )
            if existing:
                await db.execute(
                    "UPDATE player_missiles SET quantity = quantity + ? WHERE user_id = ? AND missile_id = ?",
                    (listing["quantity"], user_id, listing["item_id"])
                )
            else:
                await db.execute(
                    "INSERT INTO player_missiles (user_id, missile_id, quantity) VALUES (?, ?, ?)",
                    (user_id, listing["item_id"], listing["quantity"])
                )
        else:
            await PlayerService.update_resources(user_id, **{listing["item_type"]: listing["quantity"]})
        await db.execute("UPDATE market_listings SET is_active = 0 WHERE id = ?", (listing_id,))
        return True, "آگهی لغو و آیتم‌ها بازگردانده شد."
