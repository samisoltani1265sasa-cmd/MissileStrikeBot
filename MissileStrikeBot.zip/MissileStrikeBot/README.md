# 🚀 نبرد موشکی | Missile Strike

ربات بازی تلگرامی حرفه‌ای جنگ موشکی مخصوص گروه‌ها و چت خصوصی.

**Python 3.13 + aiogram 3.x + SQLite (aiosqlite)**

کاملاً ماژولار | بدون HTML/CSS/JS/WebView | قابل اجرا روی Termux / Render / Koyeb / VPS

---

## ✨ ویژگی‌ها

- بیش از **۷۰ موشک** واقعی (تاماهاوک، اسکندر، کینژال، پاتریوت، تاد، براهموس و ...)
- بیش از **۳۰ ساختمان** (مرکز فرماندهی، پالایشگاه، معدن اورانیوم، سامانه‌های پدافند و ...)
- سیستم نبرد زنده با شمارش معکوس، رهگیری و غارت منابع
- اقتصاد کامل (سکه، سوخت، اورانیوم، فولاد، تیتانیوم، کریستال)
- اتحاد، جنگ اتحادها، نقشه جهانی و تصرف مناطق
- بازار آزاد بین بازیکنان
- مأموریت‌های روزانه/هفتگی/ماهانه/فصلی
- جدول رتبه‌بندی جهانی، هفتگی، حمله، دفاع، ثروت، سطح و اتحاد
- پنل ادمین کامل (بن، منابع، بکاپ، پیام همگانی و ...)
- ضد اسپم، محدودیت حمله، لاگ و امنیت

---

## 📦 نصب

### ۱. کلون / دانلود

```bash
cd MissileStrikeBot
```

### ۲. ساخت محیط مجازی (پیشنهادی)

```bash
python -m venv venv
# Linux / Termux / macOS:
source venv/bin/activate
# Windows:
venv\Scripts\activate
```

### ۳. نصب وابستگی‌ها

```bash
pip install -r requirements.txt
```

### ۴. تنظیم توکن

```bash
cp .env.example .env
nano .env   # یا هر ادیتور
```

محتوای `.env`:

```env
BOT_TOKEN=1234567890:AAHxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
ADMIN_IDS=123456789,987654321
```

- توکن را از [@BotFather](https://t.me/BotFather) بگیرید.
- `ADMIN_IDS` را با آیدی عددی خودتان پر کنید (از @userinfobot).

### ۵. اجرا

```bash
python main.py
```

---

## 📱 اجرا در Termux

```bash
pkg update && pkg upgrade
pkg install python git
cd MissileStrikeBot
pip install -r requirements.txt
cp .env.example .env
# ویرایش .env
python main.py
```

برای اجرای دائمی:

```bash
pkg install termux-services
# یا با nohup / screen / tmux
nohup python main.py > logs/out.log 2>&1 &
```

---

## ☁️ اجرا روی Render

1. ریپو را به GitHub پوش کنید.
2. در [Render](https://render.com) یک **Web Service** بسازید.
3. Runtime: Python
4. Build Command: `pip install -r requirements.txt`
5. Start Command: `python main.py`
6. Environment Variables:
   - `BOT_TOKEN`
   - `ADMIN_IDS`
   - `USE_WEBHOOK=true` (اختیاری)
   - `WEBHOOK_HOST=https://your-app.onrender.com`

> توجه: پلن رایگان Render بعد از مدتی sleep می‌شود. برای بات تلگرام بهتر است از Background Worker استفاده کنید یا سرویس پولی.

---

## 🚀 اجرا روی Koyeb

1. اپلیکیشن جدید از GitHub.
2. Build: `pip install -r requirements.txt`
3. Run: `python main.py`
4. متغیرهای محیطی همانند بالا.

---

## 🖥️ اجرا روی VPS

```bash
sudo apt update
sudo apt install python3.13 python3.13-venv python3-pip git -y
git clone <repo> MissileStrikeBot
cd MissileStrikeBot
python3.13 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# ویرایش .env
```

با systemd:

```ini
# /etc/systemd/system/missile-strike.service
[Unit]
Description=Missile Strike Telegram Bot
After=network.target

[Service]
Type=simple
User=ubuntu
WorkingDirectory=/home/ubuntu/MissileStrikeBot
ExecStart=/home/ubuntu/MissileStrikeBot/venv/bin/python main.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable missile-strike
sudo systemctl start missile-strike
sudo systemctl status missile-strike
```

---

## 📁 ساختار پروژه

```
MissileStrikeBot/
├── main.py              # نقطه ورود
├── config.py            # تنظیمات
├── requirements.txt
├── .env.example
├── README.md
├── database/
│   ├── db.py            # لایه دیتابیس
│   └── schema.sql       # اسکیما کامل
├── handlers/            # هندلرهای دستورات و دکمه‌ها
├── keyboards/           # اینلاین کیبوردها
├── services/            # منطق بازی (حمله، ساختمان، اتحاد و ...)
├── middlewares/         # احراز هویت، ضد اسپم، throttling
├── filters/
├── states/
├── utils/
├── admin/
├── assets/
├── logs/
└── backups/
```

---

## 🎮 دستورات بازیکن

| دستور / دکمه | توضیح |
|--------------|--------|
| /start | شروع و منوی اصلی |
| /help | راهنما |
| 👤 پروفایل | مشاهده وضعیت |
| 🚀 حمله | انتخاب هدف و شلیک موشک |
| 🏢 ساختمان‌ها | ساخت و ارتقا |
| 📦 انبار موشک | مشاهده موشک‌ها |
| 🏪 بازار | خرید/فروش |
| 🤝 اتحاد | ایجاد / پیوستن / مدیریت |
| 📋 مأموریت‌ها | روزانه و هفتگی |
| 🏆 رتبه‌بندی | جداول مختلف |

---

## ⚙️ پنل ادمین

فقط برای `ADMIN_IDS`:

- افزودن / حذف منابع
- دادن / حذف موشک
- بن / آنبن
- پیام همگانی
- ایجاد رویداد
- آمار سیستم
- بکاپ و بازیابی

---

## 🔒 امنیت

- Middleware ضد اسپم و Flood
- محدودیت تعداد حمله در ساعت
- کول‌داون بین حملات
- بررسی بن بودن بازیکن
- لاگ کامل با loguru

---

## 📝 نکات

- دیتابیس SQLite به صورت خودکار ساخته و seed می‌شود (موشک‌ها و ساختمان‌ها).
- حملات با `asyncio.create_task` بعد از زمان پرواز حل می‌شوند.
- در صورت ری‌استارت بات، تسک پس‌زمینه حملات معوق را حل می‌کند.
- برای گروه‌ها: ربات را ادمین کنید و حریم خصوصی را باز کنید (`/setprivacy` در BotFather → Disable).

---

## 📄 لایسنس

آزاد برای استفاده شخصی و تجاری با ذکر منبع.

---

**ساخته شده با ❤️ برای جامعه تلگرام فارسی**

پس از قرار دادن `BOT_TOKEN` فقط کافی است:

```bash
python main.py
```
