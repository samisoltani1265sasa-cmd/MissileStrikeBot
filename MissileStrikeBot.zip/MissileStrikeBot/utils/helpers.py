"""Helper utilities"""
from typing import Tuple


def format_number(n: int | float) -> str:
    """Format large numbers with K, M, B suffixes"""
    if n is None:
        return "0"
    n = int(n)
    if abs(n) >= 1_000_000_000:
        return f"{n / 1_000_000_000:.1f}B"
    if abs(n) >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if abs(n) >= 1_000:
        return f"{n / 1_000:.1f}K"
    return str(n)


def format_time(seconds: int) -> str:
    """Format seconds to human readable time"""
    if seconds < 60:
        return f"{seconds}ث"
    if seconds < 3600:
        m, s = divmod(seconds, 60)
        return f"{m}د {s}ث" if s else f"{m}د"
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    if m:
        return f"{h}س {m}د"
    return f"{h}س"


def calculate_level_xp(level: int) -> int:
    """XP required for next level"""
    return int(100 * (level ** 1.5))


def get_rarity_emoji(rarity: str) -> str:
    mapping = {
        "common": "⚪",
        "uncommon": "🟢",
        "rare": "🔵",
        "epic": "🟣",
        "legendary": "🟠",
    }
    return mapping.get(rarity, "⚪")


def get_class_emoji(missile_class: str) -> str:
    mapping = {
        "ballistic": "🚀",
        "cruise": "✈️",
        "hypersonic": "⚡",
        "air_defense": "🛡️",
        "tactical": "🎯",
    }
    return mapping.get(missile_class, "🚀")


def get_building_emoji(building_type: str) -> str:
    mapping = {
        "production": "🏭",
        "defense": "🛡️",
        "storage": "📦",
        "research": "🔬",
        "military": "🎖️",
        "special": "⭐",
    }
    return mapping.get(building_type, "🏢")


def xp_to_level(xp: int) -> Tuple[int, int, int]:
    """Return (level, current_xp_in_level, xp_needed)"""
    level = 1
    remaining = xp
    while True:
        needed = calculate_level_xp(level)
        if remaining < needed:
            return level, remaining, needed
        remaining -= needed
        level += 1
