from aiogram import Router, F, Bot
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from keyboards.admin_kb import admin_menu_kb
from keyboards.main_menu import back_kb
from filters.admin import IsAdmin
from services.player_service import PlayerService
from states.user_states import AdminState
from database import get_db
from config import settings
from utils.helpers import format_number
import shutil
from datetime import datetime
from pathlib import Path

router = Router()
router.message.filter(IsAdmin())
router.callback_query.filter(IsAdmin())


@router.callback_query(F.data == "admin:add_res")
async def admin_add_res(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AdminState.add_resource)
    await callback.message.edit_text(
        "فرمت: <code>user_id resource amount</code>\n"
        "مثال: <code>123456 coins 10000</code>\n"
        "منابع: coins, fuel, uranium, steel, titanium, crystal, xp, energy",
        reply_markup=back_kb("menu:admin"),
        parse_mode="HTML"
    )
    await callback.answer()


@router.message(AdminState.add_resource)
async def admin_add_res_msg(message: Message, state: FSMContext):
    parts = message.text.strip().split()
    if len(parts) != 3:
        await message.answer("فرمت اشتباه.")
        return
    try:
        uid, resource, amount = int(parts[0]), parts[1], int(parts[2])
    except ValueError:
        await message.answer("مقادیر نامعتبر.")
        return
    await PlayerService.update_resources(uid, **{resource: amount})
    await state.clear()
    await message.answer(f"✅ {amount} {resource} به {uid} اضافه شد.", reply_markup=back_kb("menu:admin"))


@router.callback_query(F.data == "admin:rem_res")
async def admin_rem_res(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AdminState.remove_resource)
    await callback.message.edit_text(
        "فرمت: <code>user_id resource amount</code>",
        reply_markup=back_kb("menu:admin"),
        parse_mode="HTML"
    )
    await callback.answer()


@router.message(AdminState.remove_resource)
async def admin_rem_res_msg(message: Message, state: FSMContext):
    parts = message.text.strip().split()
    if len(parts) != 3:
        await message.answer("فرمت اشتباه.")
        return
    try:
        uid, resource, amount = int(parts[0]), parts[1], int(parts[2])
    except ValueError:
        await message.answer("نامعتبر.")
        return
    await PlayerService.update_resources(uid, **{resource: -amount})
    await state.clear()
    await message.answer(f"✅ {amount} {resource} از {uid} کم شد.", reply_markup=back_kb("menu:admin"))


@router.callback_query(F.data == "admin:ban")
async def admin_ban(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AdminState.ban_user)
    await callback.message.edit_text(
        "فرمت: <code>user_id دلیل</code>",
        reply_markup=back_kb("menu:admin"),
        parse_mode="HTML"
    )
    await callback.answer()


@router.message(AdminState.ban_user)
async def admin_ban_msg(message: Message, state: FSMContext):
    parts = message.text.strip().split(maxsplit=1)
    if len(parts) < 1:
        await message.answer("user_id لازم است.")
        return
    uid = int(parts[0])
    reason = parts[1] if len(parts) > 1 else "تخلف"
    await PlayerService.set_resources(uid, is_banned=1, ban_reason=reason)
    await state.clear()
    await message.answer(f"🚫 کاربر {uid} بن شد.", reply_markup=back_kb("menu:admin"))


@router.callback_query(F.data == "admin:unban")
async def admin_unban(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AdminState.unban_user)
    await callback.message.edit_text(
        "user_id را وارد کنید:",
        reply_markup=back_kb("menu:admin")
    )
    await callback.answer()


@router.message(AdminState.unban_user)
async def admin_unban_msg(message: Message, state: FSMContext):
    try:
        uid = int(message.text.strip())
    except ValueError:
        await message.answer("عدد وارد کنید.")
        return
    await PlayerService.set_resources(uid, is_banned=0, ban_reason=None)
    await state.clear()
    await message.answer(f"✅ کاربر {uid} آنبن شد.", reply_markup=back_kb("menu:admin"))


@router.callback_query(F.data == "admin:broadcast")
async def admin_broadcast(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AdminState.broadcast)
    await callback.message.edit_text(
        "پیام همگانی را بنویسید:",
        reply_markup=back_kb("menu:admin")
    )
    await callback.answer()


@router.message(AdminState.broadcast)
async def admin_broadcast_msg(message: Message, state: FSMContext, bot: Bot):
    db = await get_db()
    players = await db.fetchall("SELECT user_id FROM players WHERE is_banned = 0")
    success = 0
    for p in players:
        try:
            await bot.send_message(p["user_id"], f"📢 <b>پیام مدیریت</b>\n\n{message.text}", parse_mode="HTML")
            success += 1
        except Exception:
            pass
    await state.clear()
    await message.answer(f"✅ ارسال شد به {success}/{len(players)} نفر.", reply_markup=back_kb("menu:admin"))


@router.callback_query(F.data == "admin:stats")
async def admin_stats(callback: CallbackQuery):
    db = await get_db()
    players = await db.fetchone("SELECT COUNT(*) as c FROM players")
    attacks = await db.fetchone("SELECT COUNT(*) as c FROM attacks")
    alliances = await db.fetchone("SELECT COUNT(*) as c FROM alliances")
    text = (
        f"📊 <b>آمار سیستم</b>\n\n"
        f"بازیکنان: {players['c'] if players else 0}\n"
        f"حملات کل: {attacks['c'] if attacks else 0}\n"
        f"اتحادها: {alliances['c'] if alliances else 0}\n"
    )
    await callback.message.edit_text(text, reply_markup=back_kb("menu:admin"), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "admin:backup")
async def admin_backup(callback: CallbackQuery):
    src = settings.db_path
    dest = settings.backup_dir / f"backup_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.db"
    shutil.copy2(src, dest)
    await callback.answer(f"بکاپ ذخیره شد: {dest.name}", show_alert=True)


@router.callback_query(F.data == "admin:give_missile")
async def admin_give_missile(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AdminState.give_missile)
    await callback.message.edit_text(
        "فرمت: <code>user_id missile_id quantity</code>",
        reply_markup=back_kb("menu:admin"),
        parse_mode="HTML"
    )
    await callback.answer()


@router.message(AdminState.give_missile)
async def admin_give_missile_msg(message: Message, state: FSMContext):
    parts = message.text.strip().split()
    if len(parts) != 3:
        await message.answer("فرمت اشتباه.")
        return
    try:
        uid, mid, qty = int(parts[0]), int(parts[1]), int(parts[2])
    except ValueError:
        await message.answer("نامعتبر.")
        return
    db = await get_db()
    existing = await db.fetchone(
        "SELECT id FROM player_missiles WHERE user_id = ? AND missile_id = ?", (uid, mid)
    )
    if existing:
        await db.execute(
            "UPDATE player_missiles SET quantity = quantity + ? WHERE user_id = ? AND missile_id = ?",
            (qty, uid, mid)
        )
    else:
        await db.execute(
            "INSERT INTO player_missiles (user_id, missile_id, quantity) VALUES (?, ?, ?)",
            (uid, mid, qty)
        )
    await state.clear()
    await message.answer(f"✅ {qty} موشک #{mid} به {uid} داده شد.", reply_markup=back_kb("menu:admin"))
