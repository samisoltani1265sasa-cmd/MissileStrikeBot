"""حمله گروهی با ریپلای + حمله خصوصی — بدون اسپم پیام"""
from __future__ import annotations
import asyncio
import re
from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from keyboards.main_menu import (
    attack_menu_kb, back_kb, targets_inline_kb,
    missiles_inline_kb, confirm_attack_inline,
)
from services.attack_service import AttackService
from services.player_service import PlayerService
from services.mission_service import MissionService
from states.user_states import AttackState
from utils.helpers import format_time
from database import get_db
from services.extras_service import ExtrasService

router = Router()


@router.message(F.reply_to_message, F.text.regexp(r"(?i)^\s*حمله\s+(.+)$"))
async def group_reply_attack(message: Message, bot: Bot, player: dict):
    target_user = message.reply_to_message.from_user
    if not target_user or target_user.is_bot:
        await message.reply("❌ نمی‌توان به ربات حمله کرد.")
        return
    if target_user.id == message.from_user.id:
        await message.reply("❌ به خودتان نمی‌شود حمله کرد!")
        return

    match = re.match(r"(?i)^\s*حمله\s+(.+)$", message.text.strip())
    if not match:
        return
    missile_query = match.group(1).strip()
    missile = await _find_missile_by_name(missile_query)
    if not missile:
        await message.reply(f"❌ موشک «{missile_query}» پیدا نشد.\nمثال: <code>حمله اسکندر</code>", parse_mode="HTML")
        return
    if missile.get("is_defensive"):
        await message.reply("❌ این موشک دفاعی است.")
        return

    await PlayerService.get_or_create(
        target_user.id, target_user.username,
        target_user.first_name or "Unknown", target_user.last_name
    )

    # سپر دفاعی
    if await ExtrasService.has_shield(target_user.id):
        await message.reply("🛡️ این بازیکن سپر دفاعی فعال دارد. فعلاً نمی‌شود حمله کرد.")
        return

    ok, msg, attack_data = await AttackService.launch_attack(
        message.from_user.id, target_user.id, missile["id"]
    )
    if not ok:
        await message.reply(f"❌ {msg}")
        return

    travel = attack_data["travel_time"]
    missile_name = attack_data["missile_name"]
    attacker_name = message.from_user.first_name
    target_name = target_user.first_name

    status_msg = await message.reply(
        f"🚀 <b>حمله آغاز شد!</b>\n"
        f"{attacker_name} → {target_name}\n"
        f"موشک: <b>{missile_name}</b>\n"
        f"زمان: {format_time(travel)}",
        parse_mode="HTML"
    )
    # خبر واقعی به مدافع + ثبت برای انتقام
    await ExtrasService.set_last_attacker(target_user.id, message.from_user.id)
    try:
        await bot.send_message(
            target_user.id,
            f"⚠️ <b>هشدار حمله!</b>\n"
            f"{attacker_name} موشک <b>{missile_name}</b> به سمت تو شلیک کرد!\n"
            f"زمان تا برخورد: {format_time(travel)}\n"
            f"برای انتقام در خصوصی ربات بنویس: <code>انتقام</code>",
            parse_mode="HTML"
        )
    except Exception:
        pass

    async def resolve_later():
        await asyncio.sleep(travel)
        result = await AttackService.resolve_attack(attack_data["id"])
        status = result.get("status", "unknown")
        if status == "intercepted":
            report = f"🛡️ موشک {missile_name} رهگیری شد! ({target_name} دفاع کرد)"
        elif status == "missed":
            report = f"❌ موشک {missile_name} منحرف شد."
        else:
            loot = result.get("loot") or {}
            loot_s = (" | غنیمت: " + ", ".join(f"{k}:{v}" for k, v in loot.items())) if loot else ""
            report = (
                f"💥 برخورد! {missile_name}\n"
                f"{attacker_name} → {target_name}\n"
                f"خسارت: {result.get('damage', 0)}{loot_s}"
            )
            await MissionService.update_progress(message.from_user.id, "attack", 1)
        # پیام در گروه + خبر نتیجه به طرفین (فقط یک‌بار، حمله واقعی)
        try:
            await status_msg.reply(report)
        except Exception:
            try:
                await bot.send_message(message.chat.id, report)
            except Exception:
                pass
        for uid in (message.from_user.id, target_user.id):
            try:
                await bot.send_message(uid, report)
            except Exception:
                pass

    asyncio.create_task(resolve_later())


async def _find_missile_by_name(query: str):
    db = await get_db()
    q = query.strip()
    row = await db.fetchone(
        """SELECT * FROM missiles_catalog WHERE is_defensive = 0 AND (
             name_fa = ? OR name_en = ? OR lower(name_en) = lower(?)) LIMIT 1""",
        (q, q, q)
    )
    if row:
        return row
    return await db.fetchone(
        """SELECT * FROM missiles_catalog WHERE is_defensive = 0 AND (
             name_fa LIKE ? OR name_en LIKE ? OR lower(name_en) LIKE lower(?))
           ORDER BY length(name_fa) ASC LIMIT 1""",
        (f"%{q}%", f"%{q}%", f"%{q}%")
    )


@router.message(F.text == "🎯 هدف تصادفی")
async def attack_random(message: Message, state: FSMContext):
    if message.chat.type != "private":
        return
    targets = await PlayerService.get_random_targets(message.from_user.id)
    if not targets:
        await message.answer("هدفی نیست!", reply_markup=attack_menu_kb())
        return
    await state.update_data(targets=targets)
    await message.answer("🎯 هدف را انتخاب کنید:", reply_markup=targets_inline_kb(targets))


@router.message(F.text == "📜 تاریخچه حملات")
async def attack_history(message: Message):
    if message.chat.type != "private":
        return
    history = await AttackService.get_attack_history(message.from_user.id)
    if not history:
        await message.answer("📜 خالی است.", reply_markup=back_kb())
        return
    lines = ["📜 <b>تاریخچه</b>\n"]
    for h in history[:10]:
        em = {"hit": "💥", "intercepted": "🛡️", "missed": "❌", "in_flight": "🚀"}.get(h["status"], "?")
        lines.append(f"{em} {h.get('missile_name','?')} dmg:{h.get('damage',0)}")
    await message.answer("\n".join(lines), reply_markup=back_kb(), parse_mode="HTML")


@router.callback_query(F.data.startswith("attack:targets_page:"))
async def attack_targets_page(callback: CallbackQuery, state: FSMContext):
    page = int(callback.data.split(":")[-1])
    data = await state.get_data()
    await callback.message.edit_reply_markup(reply_markup=targets_inline_kb(data.get("targets", []), page=page))
    await callback.answer()


@router.callback_query(F.data.startswith("attack:target:"))
async def attack_select_target(callback: CallbackQuery, state: FSMContext):
    target_id = int(callback.data.split(":")[-1])
    target = await PlayerService.get(target_id)
    if not target:
        await callback.answer("یافت نشد", show_alert=True)
        return
    missiles = await AttackService.get_player_missiles(callback.from_user.id, offensive_only=True)
    if not missiles:
        await callback.answer("موشک ندارید! از فروشگاه بخرید.", show_alert=True)
        return
    await state.update_data(target_id=target_id)
    await callback.message.edit_text(
        f"هدف: <b>{target.get('first_name')}</b>\nموشک را انتخاب کنید:",
        reply_markup=missiles_inline_kb(missiles),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("attack:page:"))
async def attack_missile_page(callback: CallbackQuery):
    page = int(callback.data.split(":")[-1])
    missiles = await AttackService.get_player_missiles(callback.from_user.id, offensive_only=True)
    await callback.message.edit_reply_markup(reply_markup=missiles_inline_kb(missiles, page=page))
    await callback.answer()


@router.callback_query(F.data.startswith("attack:missile:"))
async def attack_select_missile(callback: CallbackQuery, state: FSMContext):
    missile_id = int(callback.data.split(":")[-1])
    data = await state.get_data()
    target_id = data.get("target_id")
    if not target_id:
        await callback.answer("اول هدف را انتخاب کنید", show_alert=True)
        return
    missile = await AttackService.get_missile(missile_id)
    target = await PlayerService.get(target_id)
    text = (
        f"🚀 تأیید\nموشک: <b>{missile['name_fa']}</b>\n"
        f"قدرت: {missile['power']} | زمان: {format_time(missile['travel_time'])}\n"
        f"هدف: {target.get('first_name')}"
    )
    await callback.message.edit_text(text, reply_markup=confirm_attack_inline(target_id, missile_id), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("attack:confirm:"))
async def attack_confirm(callback: CallbackQuery, state: FSMContext, bot: Bot):
    parts = callback.data.split(":")
    target_id, missile_id = int(parts[2]), int(parts[3])
    ok, msg, attack_data = await AttackService.launch_attack(callback.from_user.id, target_id, missile_id)
    if not ok:
        await callback.answer(msg, show_alert=True)
        return
    await state.clear()
    travel = attack_data["travel_time"]
    await callback.message.edit_text(f"🚀 شلیک شد!\n{attack_data['missile_name']}\nزمان: {format_time(travel)}")
    await callback.answer()

    async def resolve_later():
        await asyncio.sleep(travel)
        result = await AttackService.resolve_attack(attack_data["id"])
        st = result.get("status")
        if st == "hit":
            report = f"💥 برخورد! خسارت: {result.get('damage', 0)}"
            await MissionService.update_progress(callback.from_user.id, "attack", 1)
        elif st == "intercepted":
            report = "🛡️ رهگیری شد"
        else:
            report = "❌ منحرف شد"
        try:
            await bot.send_message(callback.from_user.id, report)
        except Exception:
            pass

    asyncio.create_task(resolve_later())


@router.callback_query(F.data == "attack:cancel")
async def attack_cancel(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    await callback.message.edit_text("❌ لغو شد")
    await callback.answer()
