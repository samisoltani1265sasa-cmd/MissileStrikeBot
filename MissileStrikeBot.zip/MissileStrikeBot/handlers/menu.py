"""منوها — فقط در چت خصوصی"""
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from keyboards.main_menu import (
    main_menu_kb, back_kb, attack_menu_kb, shop_kb, alliance_kb,
    buildings_menu_kb, market_menu_kb, shop_items_inline,
    build_list_inline, bld_detail_inline, targets_inline_kb,
)
from services.player_service import PlayerService
from services.building_service import BuildingService
from services.mission_service import MissionService
from services.alliance_service import AllianceService
from services.attack_service import AttackService
from services.shop_service import ShopService
from services.market_service import MarketService
from states.user_states import AllianceState, MarketState
from config import settings
from utils.helpers import format_number, xp_to_level, get_rarity_emoji, get_class_emoji, format_time

router = Router()


def private_only(handler):
    """رد پیام‌های گروهی برای منو"""
    async def wrapper(message: Message, *args, **kwargs):
        if message.chat.type != "private":
            return
        return await handler(message, *args, **kwargs)
    return wrapper


# ---------- منوی اصلی ----------
@router.message(F.text == "🔙 منوی اصلی")
async def menu_main(message: Message, player: dict):
    if message.chat.type != "private":
        return
    is_admin = message.from_user.id in settings.admin_ids
    text = (
        f"🏠 <b>منوی اصلی</b>\n\n"
        f"فرمانده: <b>{player.get('first_name')}</b>\n"
        f"سطح {player['level']} | ⚡ {player['energy']}/{player['max_energy']}\n"
        f"💰 {format_number(player['coins'])} | ⛽ {format_number(player['fuel'])}"
    )
    await message.answer(text, reply_markup=main_menu_kb(is_admin), parse_mode="HTML")


@router.message(F.text == "👤 پروفایل")
async def menu_profile(message: Message, player: dict):
    if message.chat.type != "private":
        return
    player = await PlayerService.regen_energy(message.from_user.id)
    _, cur_xp, needed = xp_to_level(player["xp"])
    text = (
        f"👤 <b>پروفایل</b>\n\n"
        f"🆔 <code>{player['user_id']}</code>\n"
        f"📛 {player.get('first_name')} @{player.get('username') or '—'}\n"
        f"📈 سطح: <b>{player['level']}</b> | XP: {format_number(player['xp'])} ({cur_xp}/{needed})\n\n"
        f"💰 سکه: {format_number(player['coins'])}\n"
        f"⛽ سوخت: {format_number(player['fuel'])}\n"
        f"☢️ اورانیوم: {format_number(player['uranium'])}\n"
        f"🔩 فولاد: {format_number(player['steel'])}\n"
        f"⚙️ تیتانیوم: {format_number(player['titanium'])}\n"
        f"💎 کریستال: {format_number(player['crystal'])}\n"
        f"🎖️ اعتبار: {format_number(player['military_credit'])}\n\n"
        f"⚡ انرژی: {player['energy']}/{player['max_energy']}\n"
        f"🚀 حملات: {player['attacks_count']} | 🛡️ دفاع: {player['successful_defenses']}\n"
        f"🏆 امتیاز: {format_number(player['rank_points'])}\n"
        f"🏢 ساختمان: {player['buildings_count']}\n"
    )
    if player.get("alliance_id"):
        a = await AllianceService.get(player["alliance_id"])
        if a:
            text += f"🤝 اتحاد: [{a['tag']}] {a['name']}\n"
    await message.answer(text, reply_markup=back_kb(), parse_mode="HTML")


# ---------- فروشگاه ----------
@router.message(F.text == "🛒 فروشگاه")
async def menu_shop(message: Message):
    if message.chat.type != "private":
        return
    text = (
        "🛒 <b>فروشگاه موشک</b>\n\n"
        "با سکه موشک بخرید.\n"
        "دسته را انتخاب کنید:"
    )
    await message.answer(text, reply_markup=shop_kb(), parse_mode="HTML")


@router.message(F.text == "🛒 موشک‌های عادی")
async def shop_common(message: Message):
    if message.chat.type != "private":
        return
    items = await ShopService.list_missiles("common_uncommon")
    if not items:
        await message.answer("موردی نیست.", reply_markup=shop_kb())
        return
    await message.answer(
        "🛒 <b>موشک‌های عادی / غیرمعمول</b>\nروی مورد بزنید تا بخرید:",
        reply_markup=shop_items_inline(items),
        parse_mode="HTML"
    )


@router.message(F.text == "💎 موشک‌های نادر")
async def shop_rare(message: Message):
    if message.chat.type != "private":
        return
    items = await ShopService.list_missiles("rare_epic")
    await message.answer(
        "💎 <b>موشک‌های نادر / حماسی</b>",
        reply_markup=shop_items_inline(items) if items else back_kb(),
        parse_mode="HTML"
    )


@router.message(F.text == "⚡ هایپرسونیک")
async def shop_hyper(message: Message):
    if message.chat.type != "private":
        return
    items = await ShopService.list_missiles("hypersonic")
    await message.answer(
        "⚡ <b>موشک‌های هایپرسونیک</b>",
        reply_markup=shop_items_inline(items) if items else back_kb(),
        parse_mode="HTML"
    )


@router.message(F.text == "🛡️ پدافند")
async def shop_def(message: Message):
    if message.chat.type != "private":
        return
    items = await ShopService.list_missiles("defense")
    await message.answer(
        "🛡️ <b>سامانه‌های پدافند</b>",
        reply_markup=shop_items_inline(items) if items else back_kb(),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("shop:buy:"))
async def shop_buy(callback: CallbackQuery):
    mid = int(callback.data.split(":")[-1])
    ok, msg = await ShopService.buy_missile(callback.from_user.id, mid, 1)
    await callback.answer(msg, show_alert=True)


@router.callback_query(F.data.startswith("shop:page:"))
async def shop_page(callback: CallbackQuery):
    parts = callback.data.split(":")
    page = int(parts[2])
    filt = parts[3] if len(parts) > 3 else "all"
    items = await ShopService.list_missiles(filt if filt != "all" else None)
    await callback.message.edit_reply_markup(reply_markup=shop_items_inline(items, page=page))
    await callback.answer()


# ---------- ساختمان‌ها ----------
@router.message(F.text == "🏢 ساختمان‌ها")
async def menu_buildings(message: Message, player: dict):
    if message.chat.type != "private":
        return
    await BuildingService.finish_upgrades(message.from_user.id)
    buildings = await BuildingService.get_all_for_user(message.from_user.id)
    owned = [b for b in buildings if b.get("owned")]
    lines = [
        f"🏢 <b>ساختمان‌های پایگاه</b>\n"
        f"تعداد: {len(owned)}\n\n"
        f"⛏️ <b>معدن طلا</b> هر ساعت سکه می‌دهد (پایه ۵۰۰، با ارتقا بیشتر).\n"
        f"از دکمه‌ها استفاده کنید:\n"
    ]
    for b in owned[:12]:
        prod = ""
        if b.get("production_type") == "coins":
            p = BuildingService.calc_production(b["base_production"], b["production_per_level"], b["level"])
            prod = f" | +{p}/ساعت💰"
        lines.append(f"• {b['name_fa']} Lv.{b['level']} HP:{b['hp']}/{b['max_hp']}{prod}")
    await message.answer("\n".join(lines), reply_markup=buildings_menu_kb(), parse_mode="HTML")


@router.message(F.text == "💰 جمع‌آوری منابع")
async def collect_all(message: Message):
    if message.chat.type != "private":
        return
    ok, msg, total = await BuildingService.collect_resources(message.from_user.id)
    await message.answer(msg, reply_markup=buildings_menu_kb(), parse_mode="HTML")
    if ok:
        await MissionService.update_progress(message.from_user.id, "collect", sum(total.values()) or 1)


@router.message(F.text == "🏗️ ساخت ساختمان جدید")
async def build_new(message: Message):
    if message.chat.type != "private":
        return
    buildings = await BuildingService.get_all_for_user(message.from_user.id)
    await message.answer(
        "🏗️ <b>ساخت ساختمان</b>\nیکی را انتخاب کنید:",
        reply_markup=build_list_inline(buildings),
        parse_mode="HTML"
    )


@router.message(F.text == "⬆️ ارتقای ساختمان")
async def upgrade_list(message: Message):
    if message.chat.type != "private":
        return
    buildings = await BuildingService.get_all_for_user(message.from_user.id)
    owned = [b for b in buildings if b.get("owned")]
    if not owned:
        await message.answer("ساختمانی ندارید.", reply_markup=buildings_menu_kb())
        return
    await message.answer(
        "⬆️ ساختمان برای ارتقا:",
        reply_markup=build_list_inline(owned),
        parse_mode="HTML"
    )


@router.callback_query(F.data.startswith("bld:page:"))
async def bld_page(callback: CallbackQuery):
    page = int(callback.data.split(":")[-1])
    buildings = await BuildingService.get_all_for_user(callback.from_user.id)
    await callback.message.edit_reply_markup(reply_markup=build_list_inline(buildings, page=page))
    await callback.answer()


@router.callback_query(F.data.startswith("bld:view:"))
async def bld_view(callback: CallbackQuery):
    bid = int(callback.data.split(":")[-1])
    buildings = await BuildingService.get_all_for_user(callback.from_user.id)
    b = next((x for x in buildings if x["id"] == bid), None)
    if not b:
        await callback.answer("یافت نشد", show_alert=True)
        return
    text = f"🏢 <b>{b['name_fa']} ({b['name_en']})</b>\n\nنوع: {b.get('building_type')}\nسطح لازم: {b.get('required_level', 1)}\n"
    if b.get("owned"):
        text += f"سطح: {b['level']}/{b.get('max_level', 20)}\nHP: {b['hp']}/{b['max_hp']}\n"
        if b.get("production_type"):
            prod = BuildingService.calc_production(b["base_production"], b["production_per_level"], b["level"])
            text += f"تولید: {prod} {b['production_type']}/ساعت\n"
        cost = BuildingService.calc_upgrade_cost(b["base_cost"], b["cost_multiplier"], b["level"])
        text += f"هزینه ارتقا: {format_number(cost)}💰"
        can_up = b["level"] < b.get("max_level", 20) and not b.get("is_upgrading")
        kb = bld_detail_inline(bid, True, can_up)
    else:
        text += f"هزینه ساخت: {format_number(b['base_cost'])}💰\n"
        kb = bld_detail_inline(bid, False, False)
    await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("bld:buy:"))
async def bld_buy(callback: CallbackQuery):
    bid = int(callback.data.split(":")[-1])
    ok, msg = await BuildingService.buy_building(callback.from_user.id, bid)
    await callback.answer(msg, show_alert=True)
    if ok:
        await MissionService.update_progress(callback.from_user.id, "build", 1)


@router.callback_query(F.data.startswith("bld:up:"))
async def bld_up(callback: CallbackQuery):
    bid = int(callback.data.split(":")[-1])
    ok, msg = await BuildingService.upgrade_building(callback.from_user.id, bid)
    await callback.answer(msg, show_alert=True)
    if ok:
        await MissionService.update_progress(callback.from_user.id, "build", 1)


@router.callback_query(F.data.startswith("bld:repair:"))
async def bld_repair(callback: CallbackQuery):
    bid = int(callback.data.split(":")[-1])
    ok, msg = await BuildingService.repair_building(callback.from_user.id, bid)
    await callback.answer(msg, show_alert=True)


# ---------- انبار موشک ----------
@router.message(F.text == "📦 انبار موشک")
async def menu_missiles(message: Message):
    if message.chat.type != "private":
        return
    missiles = await AttackService.get_player_missiles(message.from_user.id, offensive_only=False)
    if not missiles:
        text = "📦 انبار خالی است!\nاز 🛒 فروشگاه موشک بخرید."
    else:
        lines = ["📦 <b>انبار موشک</b>\n"]
        for m in missiles:
            r = get_rarity_emoji(m.get("rarity", "common"))
            c = get_class_emoji(m.get("missile_class", "ballistic"))
            lines.append(f"{r}{c} <b>{m['name_fa']}</b> ({m['name_en']}) ×{m['quantity']}\n  قدرت:{m['power']} سوخت:{m['fuel_consumption']}")
        lines.append("\n💡 در گروه: ریپلای + <code>حمله نام‌موشک</code>")
        text = "\n".join(lines)
    await message.answer(text, reply_markup=back_kb(), parse_mode="HTML")


# ---------- حمله ----------
@router.message(F.text == "🚀 حمله")
async def menu_attack(message: Message, player: dict):
    if message.chat.type != "private":
        return
    can, msg = await AttackService.can_attack(message.from_user.id)
    status = "✅ آماده" if can else f"❌ {msg}"
    text = (
        f"🚀 <b>حمله</b>\n\nوضعیت: {status}\n"
        f"⚡ {player['energy']}/{player['max_energy']} | ⛽ {format_number(player['fuel'])}\n\n"
        f"<b>در گروه:</b> ریپلای + <code>حمله فتاح</code>\n"
        f"یا هدف تصادفی از دکمه زیر:"
    )
    await message.answer(text, reply_markup=attack_menu_kb(), parse_mode="HTML")


# ---------- اتحاد ----------
@router.message(F.text == "🤝 اتحاد")
async def menu_alliance(message: Message, player: dict):
    if message.chat.type != "private":
        return
    has = bool(player.get("alliance_id"))
    text = "🤝 <b>اتحاد</b>\n\n"
    if has:
        a = await AllianceService.get(player["alliance_id"])
        members = await AllianceService.get_members(player["alliance_id"])
        text += (
            f"[{a['tag']}] <b>{a['name']}</b>\n"
            f"سطح: {a['level']} | اعضا: {len(members)}/{a['max_members']}\n"
            f"💰 خزانه: {format_number(a['coins'])}\n"
            f"🗺️ قلمرو: {a['territory_points']}\n"
        )
    else:
        text += "عضو اتحادی نیستید.\nاز دکمه‌ها اتحاد بسازید یا به لیست بپیوندید."
    await message.answer(text, reply_markup=alliance_kb(has), parse_mode="HTML")


@router.message(F.text == "➕ ساخت اتحاد")
async def alliance_create_start(message: Message, state: FSMContext):
    if message.chat.type != "private":
        return
    await state.set_state(AllianceState.creating_name)
    await message.answer(
        "➕ نام اتحاد را بنویسید (۳ تا ۳۰ حرف):\nهزینه: ۱۰۰۰ سکه",
        reply_markup=back_kb()
    )


@router.message(AllianceState.creating_name)
async def alliance_name(message: Message, state: FSMContext):
    if message.chat.type != "private":
        return
    name = (message.text or "").strip()
    if name == "🔙 منوی اصلی":
        await state.clear()
        return await menu_main(message, await PlayerService.get(message.from_user.id))
    if len(name) < 3 or len(name) > 30:
        await message.answer("نام باید ۳ تا ۳۰ کاراکتر باشد.")
        return
    await state.update_data(name=name)
    await state.set_state(AllianceState.creating_tag)
    await message.answer("تگ اتحاد را بنویسید (۲ تا ۵ حرف لاتین):")


@router.message(AllianceState.creating_tag)
async def alliance_tag(message: Message, state: FSMContext):
    if message.chat.type != "private":
        return
    tag = (message.text or "").strip().upper()
    data = await state.get_data()
    ok, msg = await AllianceService.create(message.from_user.id, data.get("name", ""), tag)
    await state.clear()
    player = await PlayerService.get(message.from_user.id)
    await message.answer(msg, reply_markup=alliance_kb(bool(player and player.get("alliance_id"))))


@router.message(F.text == "🔍 لیست اتحادها")
async def alliance_list(message: Message):
    if message.chat.type != "private":
        return
    alliances = await AllianceService.list_alliances(20)
    if not alliances:
        await message.answer("اتحادی نیست. خودتان بسازید!", reply_markup=alliance_kb(False))
        return
    lines = ["🔍 <b>لیست اتحادها</b>\nبرای پیوستن بنویسید:\n<code>پیوستن به TAG</code>\n"]
    for a in alliances:
        lines.append(f"• [{a['tag']}] {a['name']} | Lv.{a.get('level',1)} | 👥{a.get('member_count',0)}")
    await message.answer("\n".join(lines), reply_markup=alliance_kb(False), parse_mode="HTML")


@router.message(F.text.regexp(r"^پیوستن به\s+(\w+)$"))
async def alliance_join_cmd(message: Message):
    if message.chat.type != "private":
        return
    import re
    m = re.match(r"^پیوستن به\s+(\w+)$", message.text.strip())
    tag = m.group(1).upper()
    from database import get_db
    db = await get_db()
    a = await db.fetchone("SELECT id FROM alliances WHERE tag = ?", (tag,))
    if not a:
        await message.answer("اتحاد با این تگ یافت نشد.")
        return
    ok, msg = await AllianceService.join(message.from_user.id, a["id"])
    player = await PlayerService.get(message.from_user.id)
    await message.answer(msg, reply_markup=alliance_kb(bool(player and player.get("alliance_id"))))


@router.message(F.text == "👥 اعضای اتحاد")
async def alliance_members(message: Message, player: dict):
    if message.chat.type != "private" or not player.get("alliance_id"):
        return
    members = await AllianceService.get_members(player["alliance_id"])
    lines = ["👥 <b>اعضا</b>\n"]
    for m in members:
        role = {"leader": "👑", "officer": "⭐"}.get(m.get("role"), "👤")
        lines.append(f"{role} {m.get('first_name')} | امتیاز:{m.get('contribution',0)}")
    await message.answer("\n".join(lines), reply_markup=alliance_kb(True), parse_mode="HTML")


@router.message(F.text == "📊 آمار اتحاد")
async def alliance_stats(message: Message, player: dict):
    if message.chat.type != "private" or not player.get("alliance_id"):
        return
    a = await AllianceService.get(player["alliance_id"])
    text = (
        f"📊 <b>[{a['tag']}] {a['name']}</b>\n\n"
        f"💰 {format_number(a['coins'])} | ⛽ {format_number(a['fuel'])}\n"
        f"☢️ {format_number(a['uranium'])} | 🔩 {format_number(a['steel'])}\n"
        f"🗺️ قلمرو: {a['territory_points']}\n"
        f"⚔️ {a['war_wins']}/{a['war_losses']}"
    )
    await message.answer(text, reply_markup=alliance_kb(True), parse_mode="HTML")


@router.message(F.text == "📦 کمک به اتحاد")
async def alliance_donate_help(message: Message, state: FSMContext):
    if message.chat.type != "private":
        return
    await state.set_state(AllianceState.transferring)
    await message.answer("بنویسید مثلاً: <code>coins 100</code> یا <code>fuel 50</code>", parse_mode="HTML", reply_markup=back_kb())


@router.message(AllianceState.transferring)
async def alliance_donate_do(message: Message, state: FSMContext):
    if message.chat.type != "private":
        return
    if message.text == "🔙 منوی اصلی":
        await state.clear()
        return
    parts = (message.text or "").strip().split()
    if len(parts) != 2:
        await message.answer("فرمت: coins 100")
        return
    try:
        amount = int(parts[1])
    except ValueError:
        await message.answer("مقدار عدد باشد.")
        return
    ok, msg = await AllianceService.donate(message.from_user.id, parts[0].lower(), amount)
    await state.clear()
    await message.answer(msg, reply_markup=alliance_kb(True))


@router.message(F.text == "🗺️ مناطق")
async def alliance_territories(message: Message):
    if message.chat.type != "private":
        return
    territories = await AllianceService.get_territories()
    lines = ["🗺️ <b>نقشه جهانی</b>\n"]
    for t in territories:
        owner = f"[{t['alliance_tag']}]" if t.get("alliance_tag") else "آزاد"
        lines.append(f"• {t['name_fa']} — {owner}")
    await message.answer("\n".join(lines), reply_markup=back_kb(), parse_mode="HTML")


@router.message(F.text == "🚪 ترک اتحاد")
async def alliance_leave(message: Message, player: dict):
    if message.chat.type != "private":
        return
    ok, msg = await AllianceService.leave(message.from_user.id)
    await message.answer(msg, reply_markup=alliance_kb(False))


# ---------- بازار ----------
@router.message(F.text == "🏪 بازار")
async def menu_market(message: Message):
    if message.chat.type != "private":
        return
    await message.answer(
        "🏪 <b>بازار آزاد</b>\nخرید و فروش بین بازیکنان.",
        reply_markup=market_menu_kb(),
        parse_mode="HTML"
    )


@router.message(F.text == "🛒 خرید از بازار")
async def market_buy_list(message: Message):
    if message.chat.type != "private":
        return
    listings = await MarketService.get_listings(limit=20)
    if not listings:
        await message.answer("آگهی فعالی نیست. خودتان بفروشید!", reply_markup=market_menu_kb())
        return
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    from aiogram.types import InlineKeyboardButton
    builder = InlineKeyboardBuilder()
    lines = ["🛒 <b>آگهی‌های بازار</b>\n"]
    for item in listings[:15]:
        name = item.get("missile_name") or item.get("item_type")
        lines.append(f"#{item['id']} {name} ×{item['quantity']} — {format_number(item['price_per_unit'])}💰")
        builder.row(InlineKeyboardButton(
            text=f"خرید #{item['id']} ({format_number(item['price_per_unit'])}💰)",
            callback_data=f"mkt:buy:{item['id']}"
        ))
    await message.answer("\n".join(lines), reply_markup=builder.as_markup(), parse_mode="HTML")


@router.callback_query(F.data.startswith("mkt:buy:"))
async def market_buy_cb(callback: CallbackQuery):
    lid = int(callback.data.split(":")[-1])
    ok, msg = await MarketService.buy(callback.from_user.id, lid, 1)
    await callback.answer(msg, show_alert=True)


@router.message(F.text == "💰 فروش در بازار")
async def market_sell_help(message: Message, state: FSMContext):
    if message.chat.type != "private":
        return
    await state.set_state(MarketState.listing_qty)
    await message.answer(
        "برای فروش بنویسید:\n"
        "<code>فروش سوخت 100 10</code> → ۱۰۰ سوخت هر واحد ۱۰ سکه\n"
        "<code>فروش موشک ID تعداد قیمت</code>\n"
        "مثال: <code>فروش موشک 1 2 500</code>",
        parse_mode="HTML",
        reply_markup=back_kb()
    )


@router.message(MarketState.listing_qty, F.text.regexp(r"^فروش\s+"))
async def market_sell_do(message: Message, state: FSMContext):
    if message.chat.type != "private":
        return
    parts = message.text.strip().split()
    # فروش سوخت 100 10
    # فروش موشک 1 2 500
    try:
        if parts[1] in ("سوخت", "fuel"):
            qty, price = int(parts[2]), int(parts[3])
            ok, msg = await MarketService.list_item(message.from_user.id, "fuel", qty, price)
        elif parts[1] in ("اورانیوم", "uranium"):
            qty, price = int(parts[2]), int(parts[3])
            ok, msg = await MarketService.list_item(message.from_user.id, "uranium", qty, price)
        elif parts[1] in ("فولاد", "steel"):
            qty, price = int(parts[2]), int(parts[3])
            ok, msg = await MarketService.list_item(message.from_user.id, "steel", qty, price)
        elif parts[1] in ("موشک", "missile"):
            mid, qty, price = int(parts[2]), int(parts[3]), int(parts[4])
            ok, msg = await MarketService.list_item(message.from_user.id, "missile", qty, price, mid)
        else:
            await message.answer("فرمت اشتباه.")
            return
    except (IndexError, ValueError):
        await message.answer("فرمت اشتباه. مثال: فروش سوخت 100 10")
        return
    await state.clear()
    await message.answer(msg, reply_markup=market_menu_kb())


@router.message(F.text == "📋 آگهی‌های من")
async def market_my(message: Message):
    if message.chat.type != "private":
        return
    listings = await MarketService.my_listings(message.from_user.id)
    if not listings:
        await message.answer("آگهی ندارید.", reply_markup=market_menu_kb())
        return
    lines = ["📋 <b>آگهی‌های شما</b>\n"]
    for l in listings:
        lines.append(f"#{l['id']} {l['item_type']} ×{l['quantity']} @ {format_number(l['price_per_unit'])}")
    await message.answer("\n".join(lines), reply_markup=market_menu_kb(), parse_mode="HTML")


# ---------- مأموریت / رتبه / آمار ----------
@router.message(F.text == "📋 مأموریت‌ها")
async def menu_missions(message: Message):
    if message.chat.type != "private":
        return
    missions = await MissionService.get_player_missions(message.from_user.id)
    lines = ["📋 <b>مأموریت‌ها</b>\n"]
    for m in missions:
        st = "✅" if m.get("is_completed") else "⏳"
        lines.append(f"{st} {m['name_fa']} ({m.get('progress',0)}/{m.get('requirement_value',0)})")
        if m.get("is_completed") and not m.get("is_claimed"):
            lines.append(f"   → برای دریافت بنویس: <code>پاداش {m['mission_id']}</code>")
    await message.answer("\n".join(lines), reply_markup=back_kb(), parse_mode="HTML")


@router.message(F.text.regexp(r"^پاداش\s+(\d+)$"))
async def claim_mission(message: Message):
    if message.chat.type != "private":
        return
    import re
    mid = int(re.match(r"^پاداش\s+(\d+)$", message.text.strip()).group(1))
    ok, msg = await MissionService.claim(message.from_user.id, mid)
    await message.answer(msg, reply_markup=back_kb())


@router.message(F.text == "🏆 رتبه‌بندی")
async def menu_lb(message: Message):
    if message.chat.type != "private":
        return
    players = await PlayerService.get_top(15, "rank_points")
    lines = ["🏆 <b>رتبه‌بندی</b>\n"]
    for i, p in enumerate(players, 1):
        medal = {1: "🥇", 2: "🥈", 3: "🥉"}.get(i, f"{i}.")
        name = p.get("first_name") or str(p["user_id"])
        lines.append(f"{medal} {name} Lv.{p['level']} — {format_number(p['rank_points'])}")
    await message.answer("\n".join(lines), reply_markup=back_kb(), parse_mode="HTML")


@router.message(F.text == "📊 آمار")
async def menu_stats(message: Message, player: dict):
    if message.chat.type != "private":
        return
    total = await PlayerService.count_players()
    text = (
        f"📊 <b>آمار</b>\n\nبازیکنان: {format_number(total)}\n"
        f"حملات: {player['attacks_count']} | دفاع: {player['successful_defenses']}\n"
        f"امتیاز: {format_number(player['rank_points'])}"
    )
    await message.answer(text, reply_markup=back_kb(), parse_mode="HTML")


@router.message(F.text == "⚙️ پنل ادمین")
async def menu_admin(message: Message):
    if message.chat.type != "private":
        return
    if message.from_user.id not in settings.admin_ids:
        await message.answer("دسترسی ندارید!")
        return
    await message.answer(
        "⚙️ <b>ادمین</b>\n"
        "<code>ادمین سکه UID مقدار</code>\n"
        "<code>ادمین موشک UID ID تعداد</code>\n"
        "<code>ادمین بن UID دلیل</code>\n"
        "<code>ادمین آنبن UID</code>\n"
        "<code>ادمین آمار</code>",
        reply_markup=back_kb(),
        parse_mode="HTML"
    )


@router.message(F.text.regexp(r"^ادمین\s+"))
async def admin_cmds(message: Message):
    if message.chat.type != "private" or message.from_user.id not in settings.admin_ids:
        return
    parts = message.text.split()
    from database import get_db
    db = await get_db()
    try:
        if parts[1] == "سکه" and len(parts) >= 4:
            await PlayerService.update_resources(int(parts[2]), coins=int(parts[3]))
            await message.answer("✅ انجام شد")
        elif parts[1] == "موشک" and len(parts) >= 5:
            uid, mid, qty = int(parts[2]), int(parts[3]), int(parts[4])
            ex = await db.fetchone("SELECT id FROM player_missiles WHERE user_id=? AND missile_id=?", (uid, mid))
            if ex:
                await db.execute("UPDATE player_missiles SET quantity=quantity+? WHERE user_id=? AND missile_id=?", (qty, uid, mid))
            else:
                await db.execute("INSERT INTO player_missiles (user_id,missile_id,quantity) VALUES (?,?,?)", (uid, mid, qty))
            await message.answer("✅ موشک داده شد")
        elif parts[1] == "بن" and len(parts) >= 3:
            reason = " ".join(parts[3:]) if len(parts) > 3 else "تخلف"
            await PlayerService.set_resources(int(parts[2]), is_banned=1, ban_reason=reason)
            await message.answer("🚫 بن شد")
        elif parts[1] == "آنبن" and len(parts) >= 3:
            await PlayerService.set_resources(int(parts[2]), is_banned=0, ban_reason=None)
            await message.answer("✅ آنبن")
        elif parts[1] == "آمار":
            c = await db.fetchone("SELECT COUNT(*) as c FROM players")
            await message.answer(f"بازیکنان: {c['c']}")
        else:
            await message.answer("دستور نامعتبر")
    except Exception as e:
        await message.answer(f"خطا: {e}")
