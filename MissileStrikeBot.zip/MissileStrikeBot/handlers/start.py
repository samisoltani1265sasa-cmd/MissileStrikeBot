from aiogram import Router, F
from aiogram.types import Message, ReplyKeyboardRemove
from aiogram.filters import CommandStart, Command
from keyboards.main_menu import main_menu_kb
from config import settings
from utils.helpers import format_number

router = Router()


def _is_private(message: Message) -> bool:
    return message.chat.type == "private"


@router.message(CommandStart())
async def cmd_start(message: Message, player: dict):
    is_admin = message.from_user.id in settings.admin_ids
    text = (
        f"🚀 <b>نبرد موشکی | Missile Strike</b>\n\n"
        f"سلام <b>{player.get('first_name', 'فرمانده')}</b>!\n\n"
        f"📊 سطح: <b>{player['level']}</b>\n"
        f"💰 سکه: <b>{format_number(player['coins'])}</b>\n"
        f"⛽ سوخت: <b>{format_number(player['fuel'])}</b>\n"
        f"⚡ انرژی: <b>{player['energy']}/{player['max_energy']}</b>\n\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
        f"<b>⚔️ حمله در گروه:</b>\n"
        f"ریپلای روی پیام طرف + بنویس:\n"
        f"<code>حمله فتاح</code> یا <code>حمله اسکندر</code>\n"
        f"━━━━━━━━━━━━━━━━━━━━\n"
    )
    if _is_private(message):
        text += "\nاز دکمه‌های پایین استفاده کنید:"
        await message.answer(text, reply_markup=main_menu_kb(is_admin), parse_mode="HTML")
    else:
        text += "\nمنو و دکمه‌ها فقط در چت خصوصی با ربات فعال است.\nهمینجا به ربات پیام خصوصی بدهید: /start"
        await message.answer(text, reply_markup=ReplyKeyboardRemove(), parse_mode="HTML")


@router.message(Command("help"))
@router.message(F.text == "ℹ️ راهنما")
async def cmd_help(message: Message):
    text = (
        "📖 <b>راهنما</b>\n\n"
        "🛒 <b>فروشگاه:</b> خرید موشک با سکه\n"
        "🏢 <b>ساختمان‌ها:</b> معدن طلا هر ساعت سکه می‌دهد\n"
        "🤝 <b>اتحاد:</b> ساخت و پیوستن\n"
        "🏪 <b>بازار:</b> خرید/فروش بین بازیکنان\n\n"
        "⚔️ <b>حمله در گروه:</b>\n"
        "ریپلای + <code>حمله نام‌موشک</code>\n\n"
        "منوها فقط در چت <b>خصوصی</b> با ربات هستند."
    )
    if _is_private(message):
        from keyboards.main_menu import back_kb
        await message.answer(text, reply_markup=back_kb(), parse_mode="HTML")
    else:
        await message.answer(text, parse_mode="HTML")
