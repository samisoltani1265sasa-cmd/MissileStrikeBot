from aiogram import Router
from .start import router as start_router
from .menu import router as menu_router
from .attack import router as attack_router
from .extras import router as extras_router


def setup_routers() -> Router:
    root = Router()
    root.include_router(start_router)
    root.include_router(extras_router)  # راهنما و قابلیت‌های جدید اول
    root.include_router(menu_router)
    root.include_router(attack_router)
    return root
