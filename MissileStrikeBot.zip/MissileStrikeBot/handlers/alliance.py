from aiogram import Router, F
from aiogram.types import CallbackQuery, Message, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from aiogram.fsm.context import FSMContext
from keyboards.alliance_kb import alliance_menu_kb, alliance_members_kb, alliance_list_kb
from keyboards.main_menu import back_kb, confirm_kb
from services.alliance_service import AllianceService
from states.user_states import AllianceState
from utils.helpers import format_number

router = Router()


@router.callback_query(F.data == "alliance:create")
async def alliance_create(callback: CallbackQuery, state: FSMContext):
    await state.set_state(AllianceState.creating_name)
    await callback.message.edit_text(
        "➕ نام اتحاد را وارد کنید (۳-۳۰ کاراکتر):\nهزینه: ۱۰۰۰ سکه",
        reply_markup=back_kb("menu:alliance")
    )
    await callback.answer()


@router.message(AllianceState.creating_name)
async def alliance_create_name(message: Message, state: FSMContext):
    name = message.text.strip()
    if len(name) < 3 or len(name) > 30:
        await message.answer("نام باید ۳ تا ۳۰ کاراکتر باشد.")
        return
    await state.update_data(name=name)
    await state.set_state(AllianceState.creating_tag)
    await message.answer("تگ اتحاد را وارد کنید (۲-۵ کاراکتر لاتین):")


@router.message(AllianceState.creating_tag)
async def alliance_create_tag(message: Message, state: FSMContext):
    tag = message.text.strip().upper()
    if len(tag) < 2 or len(tag) > 5 or not tag.isalnum():
        await message.answer("تگ باید ۲ تا ۵ کاراکتر حروف/عدد باشد.")
        return
    data = await state.get_data()
    ok, msg = await AllianceService.create(message.from_user.id, data["name"], tag)
    await state.clear()
    await message.answer(msg, reply_markup=back_kb("menu:alliance"))


@router.callback_query(F.data == "alliance:join")
async def alliance_join_prompt(callback: CallbackQuery):
    alliances = await AllianceService.list_alliances()
    if not alliances:
        await callback.answer("اتحادی وجود ندارد!", show_alert=True)
        return
    await callback.message.edit_text(
        "🔍 اتحاد مورد نظر را انتخاب کنید:",
        reply_markup=alliance_list_kb(alliances),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "alliance:list")
async def alliance_list(callback: CallbackQuery):
    alliances = await AllianceService.list_alliances()
    await callback.message.edit_text(
        "📋 <b>لیست اتحادها</b>",
        reply_markup=alliance_list_kb(alliances),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data.startswith("alliance:view:"))
async def alliance_view(callback: CallbackQuery):
    aid = int(callback.data.split(":")[-1])
    alliance = await AllianceService.get(aid)
    if not alliance:
        await callback.answer("یافت نشد!", show_alert=True)
        return
    members = await AllianceService.get_members(aid)
    text = (
        f"[{alliance['tag']}] <b>{alliance['name']}</b>\n\n"
        f"سطح: {alliance['level']}\n"
        f"اعضا: {len(members)}/{alliance['max_members']}\n"
        f"امتیاز قلمرو: {alliance['territory_points']}\n"
        f"برد جنگ: {alliance['war_wins']} | باخت: {alliance['war_losses']}\n\n"
        f"برای پیوستن روی دکمه زیر بزنید:"
    )
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="✅ پیوستن", callback_data=f"alliance:join_confirm:{aid}"))
    builder.row(InlineKeyboardButton(text="🔙 بازگشت", callback_data="menu:alliance"))
    await callback.message.edit_text(text, reply_markup=builder.as_markup(), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("alliance:join_confirm:"))
async def alliance_join_confirm(callback: CallbackQuery):
    aid = int(callback.data.split(":")[-1])
    ok, msg = await AllianceService.join(callback.from_user.id, aid)
    await callback.answer(msg, show_alert=True)
    if ok:
        await callback.message.edit_text(msg, reply_markup=back_kb("menu:alliance"))


@router.callback_query(F.data == "alliance:members")
async def alliance_members(callback: CallbackQuery, player: dict):
    if not player.get("alliance_id"):
        await callback.answer("عضو اتحاد نیستید!", show_alert=True)
        return
    members = await AllianceService.get_members(player["alliance_id"])
    await callback.message.edit_text(
        "👥 <b>اعضای اتحاد</b>",
        reply_markup=alliance_members_kb(members),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "alliance:leave")
async def alliance_leave(callback: CallbackQuery):
    await callback.message.edit_text(
        "آیا مطمئن هستید که می‌خواهید اتحاد را ترک کنید؟",
        reply_markup=confirm_kb("alliance:leave_confirm", "menu:alliance")
    )
    await callback.answer()


@router.callback_query(F.data == "alliance:leave_confirm")
async def alliance_leave_confirm(callback: CallbackQuery):
    ok, msg = await AllianceService.leave(callback.from_user.id)
    await callback.answer(msg, show_alert=True)
    await callback.message.edit_text(msg, reply_markup=back_kb("menu:main"))


@router.callback_query(F.data == "alliance:stats")
async def alliance_stats(callback: CallbackQuery, player: dict):
    if not player.get("alliance_id"):
        await callback.answer("عضو نیستید!", show_alert=True)
        return
    a = await AllianceService.get(player["alliance_id"])
    text = (
        f"📊 <b>آمار اتحاد [{a['tag']}]</b>\n\n"
        f"💰 سکه: {format_number(a['coins'])}\n"
        f"⛽ سوخت: {format_number(a['fuel'])}\n"
        f"☢️ اورانیوم: {format_number(a['uranium'])}\n"
        f"🔩 فولاد: {format_number(a['steel'])}\n"
        f"🗺️ امتیاز قلمرو: {a['territory_points']}\n"
        f"⚔️ برد/باخت: {a['war_wins']}/{a['war_losses']}"
    )
    await callback.message.edit_text(text, reply_markup=back_kb("menu:alliance"), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "alliance:territories")
async def alliance_territories(callback: CallbackQuery):
    territories = await AllianceService.get_territories()
    lines = ["🗺️ <b>نقشه جهانی</b>\n"]
    for t in territories:
        owner = f"[{t['alliance_tag']}]" if t.get("alliance_tag") else "آزاد"
        lines.append(f"• {t['name_fa']} ({t['name_en']}) — {owner}")
    await callback.message.edit_text("\n".join(lines), reply_markup=back_kb("menu:alliance"), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data == "alliance:donate")
async def alliance_donate(callback: CallbackQuery, state: FSMContext):
    await callback.message.edit_text(
        "📦 برای کمک منابع، به صورت زیر بنویسید:\n"
        "<code>coins 100</code> یا <code>fuel 50</code>\n\n"
        "منابع مجاز: coins, fuel, uranium, steel, titanium, crystal",
        reply_markup=back_kb("menu:alliance"),
        parse_mode="HTML"
    )
    await state.set_state(AllianceState.transferring)
    await callback.answer()


@router.message(AllianceState.transferring)
async def alliance_donate_msg(message: Message, state: FSMContext):
    parts = message.text.strip().split()
    if len(parts) != 2:
        await message.answer("فرمت اشتباه. مثال: coins 100")
        return
    resource, amount_str = parts[0].lower(), parts[1]
    try:
        amount = int(amount_str)
    except ValueError:
        await message.answer("مقدار باید عدد باشد.")
        return
    ok, msg = await AllianceService.donate(message.from_user.id, resource, amount)
    await state.clear()
    await message.answer(msg, reply_markup=back_kb("menu:alliance"))


@router.callback_query(F.data == "alliance:war")
async def alliance_war(callback: CallbackQuery):
    await callback.message.edit_text(
        "⚔️ سیستم جنگ اتحادها به زودی کامل‌تر می‌شود.\nفعلاً از طریق حمله گروهی به اعضای اتحاد دشمن عمل کنید.",
        reply_markup=back_kb("menu:alliance"),
        parse_mode="HTML"
    )
    await callback.answer()


@router.callback_query(F.data == "alliance:chat")
async def alliance_chat(callback: CallbackQuery):
    await callback.answer("برای چت اتحاد، یک گروه تلگرام بسازید و ربات را اضافه کنید.", show_alert=True)


@router.callback_query(F.data == "alliance:manage")
async def alliance_manage(callback: CallbackQuery):
    await callback.message.edit_text(
        "⚙️ مدیریت اتحاد:\n• برای انتقال رهبری با پشتیبانی تماس بگیرید.\n• اعضا را از لیست اعضا مدیریت کنید.",
        reply_markup=back_kb("menu:alliance"),
        parse_mode="HTML"
    )
    await callback.answer()
