from aiogram import Router, F
from aiogram.types import CallbackQuery
from keyboards.building_kb import buildings_kb, building_detail_kb
from keyboards.main_menu import back_kb
from services.building_service import BuildingService
from services.mission_service import MissionService
from utils.helpers import format_number, format_time, get_building_emoji

router = Router()


@router.callback_query(F.data.startswith("building:page:"))
async def building_page(callback: CallbackQuery):
    page = int(callback.data.split(":")[-1])
    buildings = await BuildingService.get_all_for_user(callback.from_user.id)
    await callback.message.edit_reply_markup(reply_markup=buildings_kb(buildings, page=page))
    await callback.answer()


@router.callback_query(F.data.startswith("building:view:"))
async def building_view(callback: CallbackQuery):
    bid = int(callback.data.split(":")[-1])
    buildings = await BuildingService.get_all_for_user(callback.from_user.id)
    b = next((x for x in buildings if x["id"] == bid), None)
    if not b:
        await callback.answer("یافت نشد!", show_alert=True)
        return

    emoji = get_building_emoji(b.get("building_type", ""))
    text = (
        f"{emoji} <b>{b['name_fa']} ({b['name_en']})</b>\n\n"
        f"نوع: {b.get('building_type')}\n"
        f"سطح مورد نیاز: {b.get('required_level', 1)}\n"
    )
    if b.get("owned"):
        text += (
            f"سطح فعلی: <b>{b['level']}</b> / {b.get('max_level', 20)}\n"
            f"HP: {b['hp']}/{b['max_hp']}\n"
        )
        if b.get("production_type"):
            prod = BuildingService.calc_production(
                b["base_production"], b["production_per_level"], b["level"]
            )
            text += f"تولید ساعتی: {prod} {b['production_type']}\n"
        if b.get("is_upgrading"):
            text += "⏳ در حال ارتقا...\n"
        cost = BuildingService.calc_upgrade_cost(b["base_cost"], b["cost_multiplier"], b["level"])
        time_sec = BuildingService.calc_upgrade_time(b["base_upgrade_time"], b["level"])
        text += f"\nهزینه ارتقا بعدی: {format_number(cost)} سکه\nزمان: {format_time(time_sec)}"
        can_upgrade = b["level"] < b.get("max_level", 20) and not b.get("is_upgrading")
        can_collect = bool(b.get("production_type"))
        kb = building_detail_kb(bid, can_upgrade, can_collect, True)
    else:
        text += f"هزینه ساخت: {format_number(b['base_cost'])} سکه\n"
        text += f"دفاع پایه: {b.get('defense_bonus', 0)}\n"
        kb = building_detail_kb(bid, False, False, False)

    await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("building:buy:"))
async def building_buy(callback: CallbackQuery):
    bid = int(callback.data.split(":")[-1])
    ok, msg = await BuildingService.buy_building(callback.from_user.id, bid)
    await callback.answer(msg, show_alert=True)
    if ok:
        await MissionService.update_progress(callback.from_user.id, "build", 1)
        # Refresh view
        callback.data = f"building:view:{bid}"
        await building_view(callback)


@router.callback_query(F.data.startswith("building:upgrade:"))
async def building_upgrade(callback: CallbackQuery):
    bid = int(callback.data.split(":")[-1])
    ok, msg = await BuildingService.upgrade_building(callback.from_user.id, bid)
    await callback.answer(msg, show_alert=True)
    if ok:
        await MissionService.update_progress(callback.from_user.id, "build", 1)


@router.callback_query(F.data.startswith("building:collect:"))
async def building_collect(callback: CallbackQuery):
    bid = int(callback.data.split(":")[-1])
    ok, msg, _ = await BuildingService.collect_resources(callback.from_user.id, bid)
    await callback.answer(msg if len(msg) < 200 else "منابع جمع شد!", show_alert=True)
    if ok:
        await MissionService.update_progress(callback.from_user.id, "collect", 1)


@router.callback_query(F.data == "building:collect_all")
async def building_collect_all(callback: CallbackQuery):
    ok, msg, total = await BuildingService.collect_resources(callback.from_user.id)
    await callback.answer(msg if len(msg) < 200 else "منابع جمع شد!", show_alert=True)
    if ok:
        amount = sum(total.values())
        await MissionService.update_progress(callback.from_user.id, "collect", amount)


@router.callback_query(F.data.startswith("building:repair:"))
async def building_repair(callback: CallbackQuery):
    bid = int(callback.data.split(":")[-1])
    ok, msg = await BuildingService.repair_building(callback.from_user.id, bid)
    await callback.answer(msg, show_alert=True)
