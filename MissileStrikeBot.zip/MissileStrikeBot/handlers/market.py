from aiogram import Router, F
from aiogram.types import CallbackQuery, Message
from aiogram.fsm.context import FSMContext
from keyboards.market_kb import market_kb, market_items_kb, sell_type_kb
from keyboards.main_menu import back_kb
from services.market_service import MarketService
from states.user_states import MarketState
from utils.helpers import format_number

router = Router()


@router.callback_query(F.data == "market:buy")
async def market_buy(callback: CallbackQuery):
    listings = await MarketService.get_listings()
    if not listings:
        await callback.message.edit_text("🛒 بازاری خالی است.", reply_markup=back_kb("menu:market"))
    else:
        await callback.message.edit_text(
            "🛒 <b>آگهی‌های فعال</b>",
            reply_markup=market_items_kb(listings),
            parse_mode="HTML"
        )
    await callback.answer()


@router.callback_query(F.data.startswith("market:buy_item:"))
async def market_buy_item(callback: CallbackQuery):
    lid = int(callback.data.split(":")[-1])
    ok, msg = await MarketService.buy(callback.from_user.id, lid, 1)
    await callback.answer(msg, show_alert=True)


@router.callback_query(F.data == "market:sell")
async def market_sell(callback: CallbackQuery, state: FSMContext):
    await callback.message.edit_text(
        "💰 چه چیزی می‌خواهید بفروشید؟",
        reply_markup=sell_type_kb()
    )
    await callback.answer()


@router.callback_query(F.data.startswith("market:sell_type:"))
async def market_sell_type(callback: CallbackQuery, state: FSMContext):
    item_type = callback.data.split(":")[-1]
    await state.update_data(sell_type=item_type)
    if item_type == "missile":
        await state.set_state(MarketState.listing_item)
        await callback.message.edit_text(
            "شناسه موشک (ID) و تعداد را بنویسید:\nمثال: <code>5 2</code>\n(از منوی انبار ID را ببینید)",
            reply_markup=back_kb("menu:market"),
            parse_mode="HTML"
        )
    else:
        await state.set_state(MarketState.listing_qty)
        await callback.message.edit_text(
            f"تعداد {item_type} و قیمت هر واحد را بنویسید:\nمثال: <code>100 50</code>",
            reply_markup=back_kb("menu:market"),
            parse_mode="HTML"
        )
    await callback.answer()


@router.message(MarketState.listing_item)
async def market_sell_missile(message: Message, state: FSMContext):
    parts = message.text.strip().split()
    if len(parts) != 2:
        await message.answer("فرمت: ID تعداد")
        return
    try:
        mid, qty = int(parts[0]), int(parts[1])
    except ValueError:
        await message.answer("اعداد نامعتبر.")
        return
    await state.update_data(item_id=mid, quantity=qty)
    await state.set_state(MarketState.listing_price)
    await message.answer("قیمت هر واحد (سکه) را وارد کنید:")


@router.message(MarketState.listing_qty)
async def market_sell_resource(message: Message, state: FSMContext):
    parts = message.text.strip().split()
    if len(parts) != 2:
        await message.answer("فرمت: تعداد قیمت")
        return
    try:
        qty, price = int(parts[0]), int(parts[1])
    except ValueError:
        await message.answer("اعداد نامعتبر.")
        return
    data = await state.get_data()
    ok, msg = await MarketService.list_item(
        message.from_user.id, data["sell_type"], qty, price
    )
    await state.clear()
    await message.answer(msg, reply_markup=back_kb("menu:market"))


@router.message(MarketState.listing_price)
async def market_sell_price(message: Message, state: FSMContext):
    try:
        price = int(message.text.strip())
    except ValueError:
        await message.answer("عدد وارد کنید.")
        return
    data = await state.get_data()
    ok, msg = await MarketService.list_item(
        message.from_user.id, "missile", data["quantity"], price, data.get("item_id")
    )
    await state.clear()
    await message.answer(msg, reply_markup=back_kb("menu:market"))


@router.callback_query(F.data == "market:my_listings")
async def market_my(callback: CallbackQuery):
    listings = await MarketService.my_listings(callback.from_user.id)
    if not listings:
        text = "📋 آگهی فعالی ندارید."
    else:
        lines = ["📋 <b>آگهی‌های شما</b>\n"]
        for l in listings:
            lines.append(f"#{l['id']} {l['item_type']} ×{l['quantity']} @ {format_number(l['price_per_unit'])}")
        text = "\n".join(lines)
    await callback.message.edit_text(text, reply_markup=back_kb("menu:market"), parse_mode="HTML")
    await callback.answer()
