from aiogram import Router, F
from aiogram.types import CallbackQuery
from services.attack_service import AttackService
from keyboards.main_menu import back_kb
from utils.helpers import format_number, get_rarity_emoji, get_class_emoji, format_time

router = Router()


@router.callback_query(F.data.startswith("view:missile:"))
async def view_missile(callback: CallbackQuery):
    mid = int(callback.data.split(":")[-1])
    missile = await AttackService.get_missile(mid)
    if not missile:
        await callback.answer("یافت نشد!", show_alert=True)
        return
    rarity = get_rarity_emoji(missile["rarity"])
    cls = get_class_emoji(missile["missile_class"])
    text = (
        f"{rarity}{cls} <b>{missile['name_fa']} ({missile['name_en']})</b>\n\n"
        f"کلاس: {missile['missile_class']}\n"
        f"کمیابی: {missile['rarity']}\n"
        f"قدرت: {missile['power']}\n"
        f"برد: {missile['range_km']} کیلومتر\n"
        f"سرعت: {missile['speed']} کیلومتر/ساعت\n"
        f"دقت: {int(missile['accuracy']*100)}%\n"
        f"شانس اصابت: {int(missile['hit_chance']*100)}%\n"
        f"شانس رهگیری: {int(missile['intercept_chance']*100)}%\n"
        f"زمان آماده‌سازی: {format_time(missile['prep_time'])}\n"
        f"زمان پرواز: {format_time(missile['travel_time'])}\n"
        f"هزینه خرید: {format_number(missile['buy_cost'])}\n"
        f"مصرف سوخت: {missile['fuel_consumption']}\n"
        f"سطح مورد نیاز: {missile['required_level']}\n"
        f"{'🛡️ دفاعی' if missile['is_defensive'] else '🚀 تهاجمی'}"
    )
    await callback.message.edit_text(text, reply_markup=back_kb("menu:missiles"), parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("view:page:"))
async def view_missile_page(callback: CallbackQuery):
    from keyboards.attack_kb import missiles_kb
    page = int(callback.data.split(":")[-1])
    missiles = await AttackService.get_player_missiles(callback.from_user.id, offensive_only=False)
    await callback.message.edit_reply_markup(reply_markup=missiles_kb(missiles, page=page, action="view"))
    await callback.answer()
