from aiogram import Router, F
from aiogram.types import CallbackQuery
from keyboards.mission_kb import missions_kb, mission_claim_kb
from keyboards.main_menu import back_kb
from services.mission_service import MissionService

router = Router()


@router.callback_query(F.data.startswith("mission:view:"))
async def mission_view(callback: CallbackQuery):
    mid = int(callback.data.split(":")[-1])
    missions = await MissionService.get_player_missions(callback.from_user.id)
    m = next((x for x in missions if x["mission_id"] == mid or x["id"] == mid), None)
    if not m:
        # try by mission_id
        m = next((x for x in missions if x["mission_id"] == mid), None)
    if not m:
        await callback.answer("یافت نشد!", show_alert=True)
        return
    text = (
        f"📋 <b>{m['name_fa']}</b>\n\n"
        f"{m.get('description_fa', '')}\n\n"
        f"نوع: {m['mission_type']}\n"
        f"پیشرفت: {m['progress']}/{m['requirement_value']}\n"
        f"پاداش: {m['reward_coins']}💰 | {m['reward_xp']}⭐ | {m['reward_fuel']}⛽\n"
    )
    if m["is_completed"] and not m["is_claimed"]:
        kb = mission_claim_kb(m["mission_id"])
    else:
        kb = back_kb("menu:missions")
    await callback.message.edit_text(text, reply_markup=kb, parse_mode="HTML")
    await callback.answer()


@router.callback_query(F.data.startswith("mission:claim:"))
async def mission_claim(callback: CallbackQuery):
    mid = int(callback.data.split(":")[-1])
    ok, msg = await MissionService.claim(callback.from_user.id, mid)
    await callback.answer(msg, show_alert=True)
    if ok:
        missions = await MissionService.get_player_missions(callback.from_user.id)
        await callback.message.edit_text(
            "📋 <b>مأموریت‌ها</b>",
            reply_markup=missions_kb(missions),
            parse_mode="HTML"
        )
