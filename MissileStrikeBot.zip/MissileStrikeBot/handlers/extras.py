"""
۱۰ قابلیت جدید + راهنمای کامل
دستورات متنی — با منوی قبلی تداخل مخرب ندارد
"""
from aiogram import Router, F, Bot
from aiogram.types import Message
from aiogram.filters import Command
from keyboards.main_menu import back_kb, main_menu_kb
from services.extras_service import ExtrasService
from services.player_service import PlayerService
from services.attack_service import AttackService
from services.mission_service import MissionService
from config import settings
from utils.helpers import format_time
import asyncio
import re

router = Router()


def _priv(message: Message) -> bool:
    return message.chat.type == "private"


# ==================== راهنمای کامل ====================
HELP_TEXT = """
📖 <b>راهنمای کامل — نبرد موشکی</b>

━━━━━━━━━━━━━━━━━━━━
<b>۱) شروع</b>
• در خصوصی به ربات برو و بزن: /start
• دکمه‌های پایین صفحه فقط در چت خصوصی کار می‌کنند
• در گروه منو نیست (عمدی)

━━━━━━━━━━━━━━━━━━━━
<b>۲) حمله در گروه</b>
۱. ربات را ادمین گروه کنید
۲. در BotFather بزنید: /setprivacy → Disable
۳. روی پیام طرف <b>ریپلای</b> کنید
۴. بنویسید مثلاً:
<code>حمله گراد</code>
<code>حمله اسکندر</code>
<code>حمله فتاح</code>
<code>حمله تاماهاوک</code>
هر موشکی که در انبار دارید.

━━━━━━━━━━━━━━━━━━━━
<b>۳) فروشگاه و موشک</b>
دکمه 🛒 فروشگاه → دسته را بزن → موشک بخر
یا از انبار ببین چه داری: 📦 انبار موشک

━━━━━━━━━━━━━━━━━━━━
<b>۴) ساختمان و معدن</b>
🏢 ساختمان‌ها
• 💰 جمع‌آوری منابع — معدن طلا هر ساعت سکه می‌دهد (پایه ۵۰۰)
• 🏗️ ساخت ساختمان جدید
• ⬆️ ارتقا — تولید بیشتر می‌شود

━━━━━━━━━━━━━━━━━━━━
<b>۵) اتحاد</b>
🤝 اتحاد
• ➕ ساخت اتحاد (نام بعد تگ)
• 🔍 لیست اتحادها → <code>پیوستن به TAG</code>
• 📦 کمک به اتحاد → <code>coins 100</code>
• 🚪 ترک اتحاد

━━━━━━━━━━━━━━━━━━━━
<b>۶) بازار</b>
🏪 بازار — خرید/فروش بین بازیکنان
فروش: <code>فروش سوخت 100 10</code>

━━━━━━━━━━━━━━━━━━━━
<b>۷) قابلیت‌های ویژه (جدید)</b>

🎁 <code>پاداش روزانه</code>
هر ۲۴ ساعت سکه و سوخت رایگان

🛡️ <code>سپر</code>
۴ ساعت کسی نمی‌تواند بهت حمله کند (۵۰۰ سکه)

🕵️ <code>جاسوسی</code> (با ریپلای روی طرف)
یا در خصوصی بعد از ریپلای / فوروارد

⚔️ <code>انتقام</code>
شلیک به آخرین کسی که بهت حمله کرده

💸 <code>ارسال سکه ID مقدار</code>
مثال: <code>ارسال سکه 123456 200</code>

🏅 <code>دستاوردها</code>
لیست افتخارات و لقب

🏆 <code>رتبه</code>
جدول برترین‌ها

📛 <code>لقب</code>
لقب فعلی‌ات را ببین

📊 <code>وضعیت</code>
خلاصه سریع وضعیت

❓ <code>راهنما</code> یا /help
همین متن

━━━━━━━━━━━━━━━━━━━━
<b>۸) انرژی و قوانین</b>
• هر حمله ۱ انرژی می‌خواهد
• انرژی به‌مرور شارژ می‌شود
• سوخت برای شلیک لازم است
• پدافند دشمن شانس رهگیری دارد
• وقتی بهت حمله شود، در خصوصی خبر می‌گیری (حمله واقعی، نه الکی)

━━━━━━━━━━━━━━━━━━━━
موفق باشی فرمانده 🚀
"""


@router.message(Command("help"))
@router.message(F.text.in_({"راهنما", "❓ راهنما", "ℹ️ راهنما", "help", "Help"}))
async def full_help(message: Message):
    if _priv(message):
        await message.answer(HELP_TEXT, reply_markup=back_kb(), parse_mode="HTML")
    else:
        await message.answer(
            "📖 راهنمای کامل را در چت <b>خصوصی</b> با ربات ببین:\n"
            "به ربات پیام بده و بنویس: <code>راهنما</code>",
            parse_mode="HTML"
        )


# ==================== ۳. پاداش روزانه ====================
@router.message(F.text.in_({"پاداش روزانه", "🎁 پاداش روزانه", "daily"}))
async def daily_reward(message: Message):
    if not _priv(message):
        await message.reply("این دستور را در خصوصی با ربات بزن.")
        return
    ok, msg = await ExtrasService.claim_daily(message.from_user.id)
    await message.answer(msg, reply_markup=back_kb(), parse_mode="HTML")


# ==================== ۶. سپر ====================
@router.message(F.text.in_({"سپر", "🛡️ سپر", "سپر دفاعی"}))
async def shield_cmd(message: Message):
    if not _priv(message):
        await message.reply("در خصوصی بزن: سپر")
        return
    ok, msg = await ExtrasService.activate_shield(message.from_user.id, 4)
    await message.answer(msg, reply_markup=back_kb(), parse_mode="HTML")


# ==================== ۲. انتقام ====================
@router.message(F.text.in_({"انتقام", "⚔️ انتقام"}))
async def revenge_cmd(message: Message, bot: Bot, player: dict):
    if not _priv(message):
        await message.reply("انتقام را در خصوصی بزن.")
        return
    target_id = await ExtrasService.get_revenge_target(message.from_user.id)
    if not target_id:
        await message.answer("هدف انتقامی نیست (یا بیش از ۲ ساعت گذشته).", reply_markup=back_kb())
        return
    if await ExtrasService.has_shield(target_id):
        await message.answer("هدف سپر دفاعی دارد.", reply_markup=back_kb())
        return
    missiles = await AttackService.get_player_missiles(message.from_user.id, offensive_only=True)
    if not missiles:
        await message.answer("موشک تهاجمی نداری. از فروشگاه بخر.", reply_markup=back_kb())
        return
    # قوی‌ترین موشک موجود
    missile = max(missiles, key=lambda m: m.get("power", 0))
    ok, msg, attack_data = await AttackService.launch_attack(
        message.from_user.id, target_id, missile["id"]
    )
    if not ok:
        await message.answer(f"❌ {msg}", reply_markup=back_kb())
        return
    target = await PlayerService.get(target_id)
    tname = target.get("first_name") if target else str(target_id)
    await message.answer(
        f"⚔️ <b>انتقام!</b>\nبه {tname} شلیک شد با {attack_data['missile_name']}\n"
        f"زمان: {format_time(attack_data['travel_time'])}",
        parse_mode="HTML",
        reply_markup=back_kb()
    )
    # خبر به هدف
    try:
        await bot.send_message(
            target_id,
            f"⚠️ <b>حمله انتقامی!</b>\n{message.from_user.first_name} با {attack_data['missile_name']} به تو شلیک کرد!\n"
            f"زمان تا برخورد: {format_time(attack_data['travel_time'])}",
            parse_mode="HTML"
        )
    except Exception:
        pass
    await ExtrasService.set_last_attacker(target_id, message.from_user.id)

    async def resolve():
        await asyncio.sleep(attack_data["travel_time"])
        result = await AttackService.resolve_attack(attack_data["id"])
        st = result.get("status")
        if st == "hit":
            report = f"💥 انتقام موفق! خسارت: {result.get('damage', 0)}"
            await MissionService.update_progress(message.from_user.id, "attack", 1)
        elif st == "intercepted":
            report = "🛡️ موشک انتقام رهگیری شد"
        else:
            report = "❌ موشک منحرف شد"
        try:
            await bot.send_message(message.from_user.id, report)
        except Exception:
            pass
        try:
            await bot.send_message(target_id, report)
        except Exception:
            pass

    asyncio.create_task(resolve())


# ==================== ۵. جاسوسی (ریپلای) ====================
@router.message(F.reply_to_message, F.text.in_({"جاسوسی", "🕵️ جاسوسی", "spy"}))
async def spy_reply(message: Message, bot: Bot):
    target = message.reply_to_message.from_user
    if not target or target.is_bot:
        await message.reply("روی پیام یک بازیکن ریپلای کن.")
        return
    await PlayerService.get_or_create(target.id, target.username, target.first_name or "?", target.last_name)
    result = await ExtrasService.spy(message.from_user.id, target.id)
    if len(result) == 2:
        ok, msg = result
        await message.reply(msg)
        return
    ok, msg, exposed, tid = result
    if not ok:
        await message.reply(msg)
        return
    # گزارش فقط به جاسوس (خصوصی اگر بشود، وگرنه ریپلای)
    try:
        await bot.send_message(message.from_user.id, msg, parse_mode="HTML")
        if message.chat.type != "private":
            await message.reply("🕵️ گزارش جاسوسی به خصوصی ارسال شد.")
        else:
            await message.answer(msg, parse_mode="HTML", reply_markup=back_kb())
    except Exception:
        await message.reply(msg, parse_mode="HTML")
    if exposed:
        try:
            await bot.send_message(
                tid,
                f"⚠️ کسی تلاش کرد از پایگاه تو جاسوسی کند!\n(احتمالاً {message.from_user.first_name})",
            )
        except Exception:
            pass


@router.message(F.text.regexp(r"^جاسوسی\s+(\d+)$"))
async def spy_by_id(message: Message, bot: Bot):
    if not _priv(message):
        return
    tid = int(re.match(r"^جاسوسی\s+(\d+)$", message.text.strip()).group(1))
    result = await ExtrasService.spy(message.from_user.id, tid)
    if len(result) == 2:
        await message.answer(result[1], reply_markup=back_kb())
        return
    ok, msg, exposed, target_id = result
    await message.answer(msg if ok else msg, parse_mode="HTML", reply_markup=back_kb())
    if ok and exposed:
        try:
            await bot.send_message(target_id, f"⚠️ جاسوسی از پایگاهت لو رفت!")
        except Exception:
            pass


# ==================== ۸. ارسال سکه ====================
@router.message(F.text.regexp(r"^ارسال\s+سکه\s+(\d+)\s+(\d+)$"))
async def transfer_cmd(message: Message, bot: Bot):
    if not _priv(message):
        await message.reply("ارسال سکه فقط در خصوصی.")
        return
    m = re.match(r"^ارسال\s+سکه\s+(\d+)\s+(\d+)$", message.text.strip())
    to_id, amount = int(m.group(1)), int(m.group(2))
    ok, msg = await ExtrasService.transfer_coins(message.from_user.id, to_id, amount)
    await message.answer(msg, reply_markup=back_kb())
    if ok:
        try:
            await bot.send_message(to_id, f"💰 {amount} سکه از {message.from_user.first_name} دریافت کردی!")
        except Exception:
            pass


# ==================== ۹. دستاوردها ====================
@router.message(F.text.in_({"دستاوردها", "🏅 دستاوردها", "افتخارات"}))
async def achievements_cmd(message: Message):
    if not _priv(message):
        await message.reply("در خصوصی: دستاوردها")
        return
    text = await ExtrasService.get_achievements(message.from_user.id)
    await message.answer(text, reply_markup=back_kb(), parse_mode="HTML")


# ==================== ۴. لقب ====================
@router.message(F.text.in_({"لقب", "📛 لقب", "title"}))
async def title_cmd(message: Message):
    title = await ExtrasService.calc_title(message.from_user.id)
    await message.answer(f"📛 لقب فعلی تو: <b>{title}</b>\nبا حمله، دفاع و ثروت لقب عوض می‌شود.", parse_mode="HTML",
                         reply_markup=back_kb() if _priv(message) else None)


# ==================== ۷. رتبه ====================
@router.message(F.text.in_({"رتبه", "🏆 رتبه", "رتبه‌بندی"}))
async def rank_cmd(message: Message):
    # در گروه هم کار کند
    players = await ExtrasService.top_players(10)
    lines = ["🏆 <b>رتبه‌بندی</b>\n"]
    for i, p in enumerate(players, 1):
        medal = {1: "🥇", 2: "🥈", 3: "🥉"}.get(i, f"{i}.")
        name = p.get("first_name") or str(p["user_id"])
        lines.append(f"{medal} {name} Lv.{p['level']} — {p['rank_points']}")
    kb = back_kb() if _priv(message) else None
    await message.answer("\n".join(lines), parse_mode="HTML", reply_markup=kb)


# ==================== وضعیت ====================
@router.message(F.text.in_({"وضعیت", "📊 وضعیت"}))
async def status_cmd(message: Message):
    text = await ExtrasService.quick_status(message.from_user.id)
    await message.answer(text, reply_markup=back_kb() if _priv(message) else None)


# دکمه راهنما در منو اگر بود
@router.message(F.text == "🎁 پاداش")
async def daily_btn(message: Message):
    if _priv(message):
        await daily_reward(message)
