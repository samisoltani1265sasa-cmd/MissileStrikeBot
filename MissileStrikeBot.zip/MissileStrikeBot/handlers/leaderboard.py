from aiogram import Router, F
from aiogram.types import CallbackQuery
from keyboards.leaderboard_kb import leaderboard_kb
from keyboards.main_menu import back_kb
from services.player_service import PlayerService
from services.alliance_service import AllianceService
from utils.helpers import format_number

router = Router()


@router.callback_query(F.data.startswith("lb:"))
async def show_leaderboard(callback: CallbackQuery):
    kind = callback.data.split(":")[1]
    mapping = {
        "global": ("rank_points", "🌍 رتبه‌بندی جهانی"),
        "weekly": ("rank_points", "📅 هفتگی"),
        "attacks": ("attacks_count", "⚔️ بیشترین حملات"),
        "defenses": ("successful_defenses", "🛡️ بهترین مدافعان"),
        "wealth": ("coins", "💰 ثروتمندترین‌ها"),
        "level": ("level", "📈 بالاترین سطح"),
    }

    if kind == "alliances":
        alliances = await AllianceService.list_alliances(20)
        lines = ["🤝 <b>رتبه‌بندی اتحادها</b>\n"]
        for i, a in enumerate(alliances, 1):
            medal = {1: "🥇", 2: "🥈", 3: "🥉"}.get(i, f"{i}.")
            lines.append(f"{medal} [{a['tag']}] {a['name']} — {a['territory_points']} pts")
        text = "\n".join(lines)
    elif kind in mapping:
        col, title = mapping[kind]
        players = await PlayerService.get_top(20, col)
        lines = [f"<b>{title}</b>\n"]
        for i, p in enumerate(players, 1):
            medal = {1: "🥇", 2: "🥈", 3: "🥉"}.get(i, f"{i}.")
            name = p.get("first_name") or p.get("username") or str(p["user_id"])
            val = format_number(p.get(col, 0))
            lines.append(f"{medal} {name} (Lv.{p['level']}) — {val}")
        text = "\n".join(lines)
    else:
        text = "نامعتبر"
        await callback.answer()
        return

    await callback.message.edit_text(text, reply_markup=back_kb("menu:leaderboard"), parse_mode="HTML")
    await callback.answer()
