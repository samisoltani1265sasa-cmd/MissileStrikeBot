from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def admin_menu_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="➕ افزودن منابع", callback_data="admin:add_res"),
        InlineKeyboardButton(text="➖ حذف منابع", callback_data="admin:rem_res"),
    )
    builder.row(
        InlineKeyboardButton(text="🚀 دادن موشک", callback_data="admin:give_missile"),
        InlineKeyboardButton(text="🗑️ حذف موشک", callback_data="admin:del_missile"),
    )
    builder.row(
        InlineKeyboardButton(text="🚫 بن", callback_data="admin:ban"),
        InlineKeyboardButton(text="✅ آنبن", callback_data="admin:unban"),
    )
    builder.row(
        InlineKeyboardButton(text="📢 پیام همگانی", callback_data="admin:broadcast"),
        InlineKeyboardButton(text="🎲 ایجاد رویداد", callback_data="admin:event"),
    )
    builder.row(
        InlineKeyboardButton(text="📊 آمار سیستم", callback_data="admin:stats"),
        InlineKeyboardButton(text="💾 بکاپ", callback_data="admin:backup"),
    )
    builder.row(
        InlineKeyboardButton(text="🔄 بازیابی", callback_data="admin:restore"),
    )
    builder.row(
        InlineKeyboardButton(text="🔙 منوی اصلی", callback_data="menu:main")
    )
    return builder.as_markup()
