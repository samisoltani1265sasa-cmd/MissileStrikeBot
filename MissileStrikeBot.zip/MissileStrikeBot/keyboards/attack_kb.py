from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from typing import List, Dict
from utils.helpers import get_rarity_emoji, get_class_emoji, format_number


def attack_menu_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🎯 انتخاب هدف تصادفی", callback_data="attack:random"),
    )
    builder.row(
        InlineKeyboardButton(text="🔍 جستجوی بازیکن", callback_data="attack:search"),
    )
    builder.row(
        InlineKeyboardButton(text="📜 تاریخچه حملات", callback_data="attack:history"),
    )
    builder.row(
        InlineKeyboardButton(text="🔙 منوی اصلی", callback_data="menu:main"),
    )
    return builder.as_markup()


def missiles_kb(missiles: List[Dict], page: int = 0, per_page: int = 6, action: str = "attack") -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    start = page * per_page
    end = start + per_page
    page_items = missiles[start:end]

    for m in page_items:
        rarity = get_rarity_emoji(m.get("rarity", "common"))
        cls = get_class_emoji(m.get("missile_class", "ballistic"))
        qty = m.get("quantity", 0)
        text = f"{rarity}{cls} {m['name_fa']} ({m['name_en']}) ×{qty}"
        builder.row(
            InlineKeyboardButton(
                text=text,
                callback_data=f"{action}:missile:{m['id']}"
            )
        )

    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="◀️", callback_data=f"{action}:page:{page-1}"))
    if end < len(missiles):
        nav.append(InlineKeyboardButton(text="▶️", callback_data=f"{action}:page:{page+1}"))
    if nav:
        builder.row(*nav)

    builder.row(InlineKeyboardButton(text="🔙 بازگشت", callback_data="menu:attack" if action == "attack" else "menu:missiles"))
    return builder.as_markup()


def targets_kb(players: List[Dict], page: int = 0, per_page: int = 8) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    start = page * per_page
    end = start + per_page
    page_items = players[start:end]

    for p in page_items:
        name = p.get("first_name") or p.get("username") or str(p["user_id"])
        lvl = p.get("level", 1)
        text = f"🎖️ {name} | Lv.{lvl}"
        builder.row(
            InlineKeyboardButton(text=text, callback_data=f"attack:target:{p['user_id']}")
        )

    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="◀️", callback_data=f"attack:targets_page:{page-1}"))
    if end < len(players):
        nav.append(InlineKeyboardButton(text="▶️", callback_data=f"attack:targets_page:{page+1}"))
    if nav:
        builder.row(*nav)

    builder.row(InlineKeyboardButton(text="🔙 بازگشت", callback_data="menu:attack"))
    return builder.as_markup()


def confirm_attack_kb(target_id: int, missile_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(
            text="🚀 شلیک کن!",
            callback_data=f"attack:confirm:{target_id}:{missile_id}"
        )
    )
    builder.row(
        InlineKeyboardButton(text="❌ لغو", callback_data="menu:attack")
    )
    return builder.as_markup()
