from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from typing import List, Dict
from utils.helpers import get_building_emoji, format_number


def buildings_kb(buildings: List[Dict], page: int = 0, per_page: int = 6) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    start = page * per_page
    end = start + per_page
    page_items = buildings[start:end]

    for b in page_items:
        emoji = get_building_emoji(b.get("building_type", "special"))
        level = b.get("level", 0)
        owned = level > 0
        if owned:
            text = f"{emoji} {b['name_fa']} | Lv.{level}"
        else:
            text = f"🔒 {b['name_fa']} | نیاز Lv.{b.get('required_level', 1)}"
        builder.row(
            InlineKeyboardButton(
                text=text,
                callback_data=f"building:view:{b['id']}"
            )
        )

    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="◀️", callback_data=f"building:page:{page-1}"))
    if end < len(buildings):
        nav.append(InlineKeyboardButton(text="▶️", callback_data=f"building:page:{page+1}"))
    if nav:
        builder.row(*nav)

    builder.row(
        InlineKeyboardButton(text="💰 جمع‌آوری همه", callback_data="building:collect_all"),
        InlineKeyboardButton(text="🔙 منو", callback_data="menu:main"),
    )
    return builder.as_markup()


def building_detail_kb(building_id: int, can_upgrade: bool, can_collect: bool, is_owned: bool) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if is_owned:
        if can_upgrade:
            builder.row(
                InlineKeyboardButton(text="⬆️ ارتقا", callback_data=f"building:upgrade:{building_id}")
            )
        if can_collect:
            builder.row(
                InlineKeyboardButton(text="💰 جمع‌آوری", callback_data=f"building:collect:{building_id}")
            )
        builder.row(
            InlineKeyboardButton(text="🔧 تعمیر", callback_data=f"building:repair:{building_id}")
        )
    else:
        builder.row(
            InlineKeyboardButton(text="🛒 خرید / ساخت", callback_data=f"building:buy:{building_id}")
        )
    builder.row(
        InlineKeyboardButton(text="🔙 ساختمان‌ها", callback_data="menu:buildings")
    )
    return builder.as_markup()
