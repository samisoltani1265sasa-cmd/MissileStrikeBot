from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder


def leaderboard_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🌍 جهانی", callback_data="lb:global"),
        InlineKeyboardButton(text="📅 هفتگی", callback_data="lb:weekly"),
    )
    builder.row(
        InlineKeyboardButton(text="⚔️ حملات", callback_data="lb:attacks"),
        InlineKeyboardButton(text="🛡️ دفاع", callback_data="lb:defenses"),
    )
    builder.row(
        InlineKeyboardButton(text="💰 ثروت", callback_data="lb:wealth"),
        InlineKeyboardButton(text="📈 سطح", callback_data="lb:level"),
    )
    builder.row(
        InlineKeyboardButton(text="🤝 اتحادها", callback_data="lb:alliances"),
    )
    builder.row(
        InlineKeyboardButton(text="🔙 منوی اصلی", callback_data="menu:main")
    )
    return builder.as_markup()
