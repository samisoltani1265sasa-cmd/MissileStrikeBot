"""منوی پایین صفحه — فقط در چت خصوصی با ربات"""
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import ReplyKeyboardBuilder, InlineKeyboardBuilder


def main_menu_kb(is_admin: bool = False) -> ReplyKeyboardMarkup:
    b = ReplyKeyboardBuilder()
    b.row(KeyboardButton(text="👤 پروفایل"), KeyboardButton(text="🛒 فروشگاه"))
    b.row(KeyboardButton(text="🏢 ساختمان‌ها"), KeyboardButton(text="📦 انبار موشک"))
    b.row(KeyboardButton(text="🚀 حمله"), KeyboardButton(text="🤝 اتحاد"))
    b.row(KeyboardButton(text="🏪 بازار"), KeyboardButton(text="📋 مأموریت‌ها"))
    b.row(KeyboardButton(text="🏆 رتبه‌بندی"), KeyboardButton(text="📊 آمار"))
    b.row(KeyboardButton(text="🎁 پاداش روزانه"), KeyboardButton(text="🏅 دستاوردها"))
    b.row(KeyboardButton(text="🛡️ سپر"), KeyboardButton(text="⚔️ انتقام"))
    b.row(KeyboardButton(text="ℹ️ راهنما"))
    if is_admin:
        b.row(KeyboardButton(text="⚙️ پنل ادمین"))
    return b.as_markup(resize_keyboard=True, is_persistent=True)


def back_kb() -> ReplyKeyboardMarkup:
    b = ReplyKeyboardBuilder()
    b.row(KeyboardButton(text="🔙 منوی اصلی"))
    return b.as_markup(resize_keyboard=True)


def attack_menu_kb() -> ReplyKeyboardMarkup:
    b = ReplyKeyboardBuilder()
    b.row(KeyboardButton(text="🎯 هدف تصادفی"))
    b.row(KeyboardButton(text="📜 تاریخچه حملات"))
    b.row(KeyboardButton(text="🔙 منوی اصلی"))
    return b.as_markup(resize_keyboard=True)


def shop_kb() -> ReplyKeyboardMarkup:
    b = ReplyKeyboardBuilder()
    b.row(KeyboardButton(text="🛒 موشک‌های عادی"), KeyboardButton(text="💎 موشک‌های نادر"))
    b.row(KeyboardButton(text="⚡ هایپرسونیک"), KeyboardButton(text="🛡️ پدافند"))
    b.row(KeyboardButton(text="🔙 منوی اصلی"))
    return b.as_markup(resize_keyboard=True)


def alliance_kb(has: bool) -> ReplyKeyboardMarkup:
    b = ReplyKeyboardBuilder()
    if has:
        b.row(KeyboardButton(text="👥 اعضای اتحاد"), KeyboardButton(text="📊 آمار اتحاد"))
        b.row(KeyboardButton(text="📦 کمک به اتحاد"), KeyboardButton(text="🗺️ مناطق"))
        b.row(KeyboardButton(text="🚪 ترک اتحاد"))
    else:
        b.row(KeyboardButton(text="➕ ساخت اتحاد"), KeyboardButton(text="🔍 لیست اتحادها"))
    b.row(KeyboardButton(text="🔙 منوی اصلی"))
    return b.as_markup(resize_keyboard=True)


def buildings_menu_kb() -> ReplyKeyboardMarkup:
    b = ReplyKeyboardBuilder()
    b.row(KeyboardButton(text="💰 جمع‌آوری منابع"), KeyboardButton(text="⬆️ ارتقای ساختمان"))
    b.row(KeyboardButton(text="🏗️ ساخت ساختمان جدید"))
    b.row(KeyboardButton(text="🔙 منوی اصلی"))
    return b.as_markup(resize_keyboard=True)


def market_menu_kb() -> ReplyKeyboardMarkup:
    b = ReplyKeyboardBuilder()
    b.row(KeyboardButton(text="🛒 خرید از بازار"), KeyboardButton(text="💰 فروش در بازار"))
    b.row(KeyboardButton(text="📋 آگهی‌های من"))
    b.row(KeyboardButton(text="🔙 منوی اصلی"))
    return b.as_markup(resize_keyboard=True)


def targets_inline_kb(players: list, page: int = 0, per_page: int = 8) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for p in players[page * per_page:(page + 1) * per_page]:
        name = p.get("first_name") or p.get("username") or str(p["user_id"])
        builder.row(InlineKeyboardButton(
            text=f"🎖️ {name} | Lv.{p.get('level', 1)}",
            callback_data=f"attack:target:{p['user_id']}"
        ))
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="◀️", callback_data=f"attack:targets_page:{page - 1}"))
    if (page + 1) * per_page < len(players):
        nav.append(InlineKeyboardButton(text="▶️", callback_data=f"attack:targets_page:{page + 1}"))
    if nav:
        builder.row(*nav)
    return builder.as_markup()


def missiles_inline_kb(missiles: list, page: int = 0, per_page: int = 6, action: str = "attack") -> InlineKeyboardMarkup:
    from utils.helpers import get_rarity_emoji, get_class_emoji
    builder = InlineKeyboardBuilder()
    for m in missiles[page * per_page:(page + 1) * per_page]:
        rarity = get_rarity_emoji(m.get("rarity", "common"))
        cls = get_class_emoji(m.get("missile_class", "ballistic"))
        qty = m.get("quantity", 1)
        builder.row(InlineKeyboardButton(
            text=f"{rarity}{cls} {m['name_fa']} ×{qty}",
            callback_data=f"{action}:missile:{m['id']}"
        ))
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="◀️", callback_data=f"{action}:page:{page - 1}"))
    if (page + 1) * per_page < len(missiles):
        nav.append(InlineKeyboardButton(text="▶️", callback_data=f"{action}:page:{page + 1}"))
    if nav:
        builder.row(*nav)
    return builder.as_markup()


def confirm_attack_inline(target_id: int, missile_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(InlineKeyboardButton(text="🚀 شلیک!", callback_data=f"attack:confirm:{target_id}:{missile_id}"))
    builder.row(InlineKeyboardButton(text="❌ لغو", callback_data="attack:cancel"))
    return builder.as_markup()


def shop_items_inline(missiles: list, page: int = 0) -> InlineKeyboardMarkup:
    from utils.helpers import format_number, get_rarity_emoji
    builder = InlineKeyboardBuilder()
    for m in missiles[page * 5:(page + 1) * 5]:
        rarity = get_rarity_emoji(m.get("rarity", "common"))
        builder.row(InlineKeyboardButton(
            text=f"{rarity} {m['name_fa']} — {format_number(m['buy_cost'])}💰",
            callback_data=f"shop:buy:{m['id']}"
        ))
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="◀️", callback_data=f"shop:page:{page - 1}:{missiles[0].get('_filter', 'all')}"))
    if (page + 1) * 5 < len(missiles):
        nav.append(InlineKeyboardButton(text="▶️", callback_data=f"shop:page:{page + 1}:{missiles[0].get('_filter', 'all')}"))
    if nav:
        builder.row(*nav)
    return builder.as_markup()


def build_list_inline(buildings: list, page: int = 0) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for b in buildings[page * 6:(page + 1) * 6]:
        if b.get("owned"):
            text = f"✅ {b['name_fa']} Lv.{b['level']}"
        else:
            text = f"🔒 {b['name_fa']} ({b.get('base_cost', 0)}💰)"
        builder.row(InlineKeyboardButton(text=text, callback_data=f"bld:view:{b['id']}"))
    nav = []
    if page > 0:
        nav.append(InlineKeyboardButton(text="◀️", callback_data=f"bld:page:{page - 1}"))
    if (page + 1) * 6 < len(buildings):
        nav.append(InlineKeyboardButton(text="▶️", callback_data=f"bld:page:{page + 1}"))
    if nav:
        builder.row(*nav)
    return builder.as_markup()


def bld_detail_inline(bid: int, owned: bool, can_up: bool) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if owned:
        if can_up:
            builder.row(InlineKeyboardButton(text="⬆️ ارتقا", callback_data=f"bld:up:{bid}"))
        builder.row(InlineKeyboardButton(text="🔧 تعمیر", callback_data=f"bld:repair:{bid}"))
    else:
        builder.row(InlineKeyboardButton(text="🏗️ ساخت", callback_data=f"bld:buy:{bid}"))
    builder.row(InlineKeyboardButton(text="🔙 لیست", callback_data="bld:page:0"))
    return builder.as_markup()
