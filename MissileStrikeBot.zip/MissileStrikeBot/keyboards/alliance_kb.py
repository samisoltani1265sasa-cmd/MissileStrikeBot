from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from typing import List, Dict


def alliance_menu_kb(has_alliance: bool, is_leader: bool = False) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if has_alliance:
        builder.row(
            InlineKeyboardButton(text="👥 اعضا", callback_data="alliance:members"),
            InlineKeyboardButton(text="📊 آمار اتحاد", callback_data="alliance:stats"),
        )
        builder.row(
            InlineKeyboardButton(text="💬 چت اتحاد", callback_data="alliance:chat"),
            InlineKeyboardButton(text="📦 کمک منابع", callback_data="alliance:donate"),
        )
        builder.row(
            InlineKeyboardButton(text="🗺️ مناطق", callback_data="alliance:territories"),
            InlineKeyboardButton(text="⚔️ جنگ اتحاد", callback_data="alliance:war"),
        )
        if is_leader:
            builder.row(
                InlineKeyboardButton(text="⚙️ مدیریت", callback_data="alliance:manage"),
            )
        builder.row(
            InlineKeyboardButton(text="🚪 ترک اتحاد", callback_data="alliance:leave"),
        )
    else:
        builder.row(
            InlineKeyboardButton(text="➕ ایجاد اتحاد", callback_data="alliance:create"),
            InlineKeyboardButton(text="🔍 پیوستن", callback_data="alliance:join"),
        )
        builder.row(
            InlineKeyboardButton(text="📋 لیست اتحادها", callback_data="alliance:list"),
        )
    builder.row(
        InlineKeyboardButton(text="🔙 منوی اصلی", callback_data="menu:main")
    )
    return builder.as_markup()


def alliance_members_kb(members: List[Dict], page: int = 0) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for m in members[page*8:(page+1)*8]:
        role_emoji = {"leader": "👑", "officer": "⭐", "member": "👤"}.get(m.get("role", "member"), "👤")
        name = m.get("first_name") or m.get("username") or str(m["user_id"])
        builder.row(
            InlineKeyboardButton(
                text=f"{role_emoji} {name} | امتیاز: {m.get('contribution', 0)}",
                callback_data=f"alliance:member:{m['user_id']}"
            )
        )
    builder.row(InlineKeyboardButton(text="🔙 بازگشت", callback_data="menu:alliance"))
    return builder.as_markup()


def alliance_list_kb(alliances: List[Dict], page: int = 0) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for a in alliances[page*6:(page+1)*6]:
        text = f"[{a['tag']}] {a['name']} | Lv.{a.get('level', 1)} | 👥{a.get('member_count', 0)}"
        builder.row(
            InlineKeyboardButton(text=text, callback_data=f"alliance:view:{a['id']}")
        )
    builder.row(InlineKeyboardButton(text="🔙 بازگشت", callback_data="menu:alliance"))
    return builder.as_markup()
