from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from typing import List, Dict


def missions_kb(missions: List[Dict]) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for m in missions:
        status = "✅" if m.get("is_completed") else "⏳"
        claimed = "🎁" if m.get("is_completed") and not m.get("is_claimed") else ""
        text = f"{status}{claimed} {m['name_fa']} ({m.get('progress', 0)}/{m.get('requirement_value', 0)})"
        builder.row(
            InlineKeyboardButton(
                text=text,
                callback_data=f"mission:view:{m['id']}"
            )
        )
    builder.row(
        InlineKeyboardButton(text="🔙 منوی اصلی", callback_data="menu:main")
    )
    return builder.as_markup()


def mission_claim_kb(mission_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🎁 دریافت پاداش", callback_data=f"mission:claim:{mission_id}")
    )
    builder.row(
        InlineKeyboardButton(text="🔙 مأموریت‌ها", callback_data="menu:missions")
    )
    return builder.as_markup()
