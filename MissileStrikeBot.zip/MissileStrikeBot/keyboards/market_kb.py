from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import InlineKeyboardBuilder
from typing import List, Dict
from utils.helpers import format_number


def market_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🛒 خرید", callback_data="market:buy"),
        InlineKeyboardButton(text="💰 فروش", callback_data="market:sell"),
    )
    builder.row(
        InlineKeyboardButton(text="📋 لیست من", callback_data="market:my_listings"),
    )
    builder.row(
        InlineKeyboardButton(text="🔙 منوی اصلی", callback_data="menu:main")
    )
    return builder.as_markup()


def market_items_kb(listings: List[Dict], page: int = 0) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for item in listings[page*6:(page+1)*6]:
        text = f"{item.get('item_type', '?')} ×{item['quantity']} | {format_number(item['price_per_unit'])}💰"
        builder.row(
            InlineKeyboardButton(text=text, callback_data=f"market:buy_item:{item['id']}")
        )
    builder.row(InlineKeyboardButton(text="🔙 بازار", callback_data="menu:market"))
    return builder.as_markup()


def sell_type_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.row(
        InlineKeyboardButton(text="🚀 موشک", callback_data="market:sell_type:missile"),
        InlineKeyboardButton(text="⛽ سوخت", callback_data="market:sell_type:fuel"),
    )
    builder.row(
        InlineKeyboardButton(text="☢️ اورانیوم", callback_data="market:sell_type:uranium"),
        InlineKeyboardButton(text="🔩 فولاد", callback_data="market:sell_type:steel"),
    )
    builder.row(
        InlineKeyboardButton(text="⚙️ تیتانیوم", callback_data="market:sell_type:titanium"),
        InlineKeyboardButton(text="💎 کریستال", callback_data="market:sell_type:crystal"),
    )
    builder.row(InlineKeyboardButton(text="🔙 بازگشت", callback_data="menu:market"))
    return builder.as_markup()
