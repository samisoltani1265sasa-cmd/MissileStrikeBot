"""
Missile Strike Bot - Configuration
"""
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field
from typing import List


BASE_DIR = Path(__file__).resolve().parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    BOT_TOKEN: str = Field(..., description="Telegram Bot Token")
    ADMIN_IDS: str = Field(default="", description="Comma-separated admin IDs")

    DATABASE_PATH: str = Field(default="database/missile_strike.db")
    LOG_LEVEL: str = Field(default="INFO")
    LOG_FILE: str = Field(default="logs/bot.log")

    MAX_ATTACKS_PER_HOUR: int = 10
    ATTACK_COOLDOWN_SECONDS: int = 15
    ENERGY_REGEN_MINUTES: int = 5
    MAX_ENERGY: int = 20

    BACKUP_INTERVAL_HOURS: int = 6
    BACKUP_PATH: str = "backups/"

    ENVIRONMENT: str = "production"
    WEBHOOK_HOST: str = ""
    WEBHOOK_PATH: str = "/webhook"
    WEBHOOK_PORT: int = 8080
    USE_WEBHOOK: bool = False

    @property
    def admin_ids(self) -> List[int]:
        if not self.ADMIN_IDS:
            return []
        return [int(x.strip()) for x in self.ADMIN_IDS.split(",") if x.strip().isdigit()]

    @property
    def db_path(self) -> Path:
        path = BASE_DIR / self.DATABASE_PATH
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def log_path(self) -> Path:
        path = BASE_DIR / self.LOG_FILE
        path.parent.mkdir(parents=True, exist_ok=True)
        return path

    @property
    def backup_dir(self) -> Path:
        path = BASE_DIR / self.BACKUP_PATH
        path.mkdir(parents=True, exist_ok=True)
        return path


settings = Settings()
