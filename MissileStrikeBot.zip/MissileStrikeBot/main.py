"""نبرد موشکی | Missile Strike — نسخه کامل"""
from __future__ import annotations
import asyncio
import sys
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from config import settings
from utils.logger import setup_logger
from database import get_db
from handlers import setup_routers
from middlewares.auth import AuthMiddleware
from services.attack_service import AttackService
from services.extras_service import ExtrasService

logger = setup_logger()


async def resolve_pending_attacks(bot: Bot):
    """فقط حملات معوق را یک‌بار حل می‌کند — بدون اسپم مداوم"""
    while True:
        try:
            pending = await AttackService.get_pending_attacks()
            for attack in pending:
                result = await AttackService.resolve_attack(attack["id"])
                status = result.get("status", "")
                name = attack.get("missile_name", "موشک")
                if status == "hit":
                    msg = f"💥 برخورد! {name} | خسارت: {result.get('damage', 0)}"
                elif status == "intercepted":
                    msg = f"🛡️ {name} رهگیری شد"
                else:
                    msg = f"❌ {name} منحرف شد"
                # فقط به مهاجم یک پیام — نه هر دقیقه به همه
                try:
                    await bot.send_message(attack["attacker_id"], msg)
                except Exception:
                    pass
        except Exception as e:
            logger.error(f"resolve error: {e}")
        await asyncio.sleep(20)


async def on_startup(bot: Bot):
    db = await get_db()
    await db.init_schema()
    await ExtrasService.ensure_columns()
    # اطمینان از وجود معدن طلا با تولید ۵۰۰
    try:
        await db.execute(
            "UPDATE buildings_catalog SET base_production = 500, production_type = 'coins', name_fa = 'معدن طلا', name_en = 'Gold Mine' WHERE name_en IN ('Logistics Hub', 'Gold Mine') OR name_fa = 'مرکز لجستیک'"
        )
        # اگر معدن طلا در کاتالوگ نیست اضافه کن
        row = await db.fetchone("SELECT id FROM buildings_catalog WHERE name_en = 'Gold Mine' OR name_fa = 'معدن طلا'")
        if not row:
            await db.execute(
                """INSERT INTO buildings_catalog
                   (name_fa, name_en, base_cost, cost_multiplier, base_upgrade_time, max_level,
                    production_type, base_production, production_per_level, capacity_bonus,
                    defense_bonus, hp_per_level, required_level, building_type)
                   VALUES ('معدن طلا', 'Gold Mine', 500, 1.5, 300, 20, 'coins', 500, 1.3, 0, 10, 200, 1, 'production')"""
            )
    except Exception as e:
        logger.warning(f"mine migrate: {e}")
    me = await bot.get_me()
    logger.info(f"Bot started: @{me.username}")
    asyncio.create_task(resolve_pending_attacks(bot))


async def on_shutdown(bot: Bot):
    db = await get_db()
    await db.close()
    logger.info("stopped")


async def main():
    if not settings.BOT_TOKEN or settings.BOT_TOKEN.startswith("123456"):
        logger.error("BOT_TOKEN را در .env بگذارید")
        sys.exit(1)
    bot = Bot(token=settings.BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher(storage=MemoryStorage())
    dp.message.middleware(AuthMiddleware())
    dp.callback_query.middleware(AuthMiddleware())
    dp.include_router(setup_routers())
    dp.startup.register(on_startup)
    dp.shutdown.register(on_shutdown)
    await bot.delete_webhook(drop_pending_updates=True)
    logger.info("Polling...")
    await dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types())


if __name__ == "__main__":
    try:
        if sys.platform != "win32":
            import uvloop
            uvloop.install()
    except ImportError:
        pass
    asyncio.run(main())
