-- Missile Strike Database Schema
-- SQLite + aiosqlite optimized

PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;
PRAGMA cache_size = -64000;
PRAGMA temp_store = MEMORY;

-- ==================== PLAYERS ====================
CREATE TABLE IF NOT EXISTS players (
    user_id INTEGER PRIMARY KEY,
    username TEXT,
    first_name TEXT NOT NULL,
    last_name TEXT,
    level INTEGER DEFAULT 1,
    xp INTEGER DEFAULT 0,
    coins INTEGER DEFAULT 500,
    fuel INTEGER DEFAULT 100,
    uranium INTEGER DEFAULT 0,
    steel INTEGER DEFAULT 50,
    titanium INTEGER DEFAULT 0,
    crystal INTEGER DEFAULT 0,
    military_credit INTEGER DEFAULT 0,
    energy INTEGER DEFAULT 20,
    max_energy INTEGER DEFAULT 20,
    last_energy_update TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    attacks_count INTEGER DEFAULT 0,
    successful_defenses INTEGER DEFAULT 0,
    missiles_owned INTEGER DEFAULT 0,
    buildings_count INTEGER DEFAULT 1,
    alliance_id INTEGER,
    rank_points INTEGER DEFAULT 0,
    is_banned INTEGER DEFAULT 0,
    ban_reason TEXT,
    last_attack_time TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_active TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_players_level ON players(level DESC);
CREATE INDEX IF NOT EXISTS idx_players_rank ON players(rank_points DESC);
CREATE INDEX IF NOT EXISTS idx_players_alliance ON players(alliance_id);
CREATE INDEX IF NOT EXISTS idx_players_coins ON players(coins DESC);

-- ==================== MISSILES CATALOG ====================
CREATE TABLE IF NOT EXISTS missiles_catalog (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name_fa TEXT NOT NULL,
    name_en TEXT NOT NULL,
    power INTEGER NOT NULL,
    range_km INTEGER NOT NULL,
    speed INTEGER NOT NULL,          -- km/h
    accuracy REAL NOT NULL,          -- 0.0 - 1.0
    prep_time INTEGER NOT NULL,      -- seconds
    travel_time INTEGER NOT NULL,    -- seconds
    buy_cost INTEGER NOT NULL,
    maintenance_cost INTEGER DEFAULT 0,
    fuel_consumption INTEGER NOT NULL,
    intercept_chance REAL DEFAULT 0.3,
    hit_chance REAL DEFAULT 0.75,
    required_level INTEGER DEFAULT 1,
    missile_class TEXT NOT NULL,     -- ballistic, cruise, hypersonic, air_defense, tactical
    rarity TEXT DEFAULT 'common',    -- common, uncommon, rare, epic, legendary
    description_fa TEXT,
    description_en TEXT,
    is_defensive INTEGER DEFAULT 0
);

-- ==================== PLAYER MISSILES ====================
CREATE TABLE IF NOT EXISTS player_missiles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    missile_id INTEGER NOT NULL,
    quantity INTEGER DEFAULT 1,
    is_ready INTEGER DEFAULT 1,
    last_used TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES players(user_id) ON DELETE CASCADE,
    FOREIGN KEY (missile_id) REFERENCES missiles_catalog(id),
    UNIQUE(user_id, missile_id)
);

CREATE INDEX IF NOT EXISTS idx_player_missiles_user ON player_missiles(user_id);

-- ==================== BUILDINGS CATALOG ====================
CREATE TABLE IF NOT EXISTS buildings_catalog (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name_fa TEXT NOT NULL,
    name_en TEXT NOT NULL,
    base_cost INTEGER NOT NULL,
    cost_multiplier REAL DEFAULT 1.5,
    base_upgrade_time INTEGER NOT NULL,  -- seconds
    max_level INTEGER DEFAULT 20,
    production_type TEXT,                -- coins, fuel, uranium, steel, titanium, crystal, xp, energy
    base_production INTEGER DEFAULT 0,
    production_per_level REAL DEFAULT 1.2,
    capacity_bonus INTEGER DEFAULT 0,
    defense_bonus INTEGER DEFAULT 0,
    hp_per_level INTEGER DEFAULT 100,
    required_level INTEGER DEFAULT 1,
    building_type TEXT NOT NULL,         -- production, defense, storage, research, military, special
    description_fa TEXT,
    description_en TEXT
);

-- ==================== PLAYER BUILDINGS ====================
CREATE TABLE IF NOT EXISTS player_buildings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    building_id INTEGER NOT NULL,
    level INTEGER DEFAULT 1,
    hp INTEGER DEFAULT 100,
    max_hp INTEGER DEFAULT 100,
    is_upgrading INTEGER DEFAULT 0,
    upgrade_finish_time TIMESTAMP,
    last_collected TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES players(user_id) ON DELETE CASCADE,
    FOREIGN KEY (building_id) REFERENCES buildings_catalog(id),
    UNIQUE(user_id, building_id)
);

CREATE INDEX IF NOT EXISTS idx_player_buildings_user ON player_buildings(user_id);

-- ==================== ALLIANCES ====================
CREATE TABLE IF NOT EXISTS alliances (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    tag TEXT NOT NULL UNIQUE,            -- 3-5 chars
    description TEXT,
    leader_id INTEGER NOT NULL,
    level INTEGER DEFAULT 1,
    xp INTEGER DEFAULT 0,
    coins INTEGER DEFAULT 0,
    fuel INTEGER DEFAULT 0,
    uranium INTEGER DEFAULT 0,
    steel INTEGER DEFAULT 0,
    titanium INTEGER DEFAULT 0,
    crystal INTEGER DEFAULT 0,
    max_members INTEGER DEFAULT 20,
    war_wins INTEGER DEFAULT 0,
    war_losses INTEGER DEFAULT 0,
    territory_points INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (leader_id) REFERENCES players(user_id)
);

CREATE INDEX IF NOT EXISTS idx_alliances_points ON alliances(territory_points DESC);

-- ==================== ALLIANCE MEMBERS ====================
CREATE TABLE IF NOT EXISTS alliance_members (
    alliance_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    role TEXT DEFAULT 'member',          -- leader, officer, member
    contribution INTEGER DEFAULT 0,
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (alliance_id, user_id),
    FOREIGN KEY (alliance_id) REFERENCES alliances(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES players(user_id) ON DELETE CASCADE
);

-- ==================== ATTACKS LOG ====================
CREATE TABLE IF NOT EXISTS attacks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    attacker_id INTEGER NOT NULL,
    defender_id INTEGER NOT NULL,
    missile_id INTEGER NOT NULL,
    missile_name TEXT,
    power INTEGER,
    status TEXT DEFAULT 'pending',       -- pending, in_flight, intercepted, hit, missed
    damage INTEGER DEFAULT 0,
    resources_looted TEXT,               -- JSON
    building_damaged TEXT,
    intercept_chance REAL,
    hit_chance REAL,
    travel_time INTEGER,
    launch_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    arrival_time TIMESTAMP,
    resolved_at TIMESTAMP,
    report TEXT,
    FOREIGN KEY (attacker_id) REFERENCES players(user_id),
    FOREIGN KEY (defender_id) REFERENCES players(user_id),
    FOREIGN KEY (missile_id) REFERENCES missiles_catalog(id)
);

CREATE INDEX IF NOT EXISTS idx_attacks_attacker ON attacks(attacker_id);
CREATE INDEX IF NOT EXISTS idx_attacks_defender ON attacks(defender_id);
CREATE INDEX IF NOT EXISTS idx_attacks_status ON attacks(status);
CREATE INDEX IF NOT EXISTS idx_attacks_arrival ON attacks(arrival_time);

-- ==================== MARKET ====================
CREATE TABLE IF NOT EXISTS market_listings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    seller_id INTEGER NOT NULL,
    item_type TEXT NOT NULL,             -- missile, fuel, uranium, steel, titanium, crystal, building
    item_id INTEGER,                     -- for missiles/buildings
    quantity INTEGER NOT NULL,
    price_per_unit INTEGER NOT NULL,
    currency TEXT DEFAULT 'coins',       -- coins, uranium, titanium
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP,
    is_active INTEGER DEFAULT 1,
    FOREIGN KEY (seller_id) REFERENCES players(user_id)
);

CREATE INDEX IF NOT EXISTS idx_market_active ON market_listings(is_active, item_type);

-- ==================== MISSIONS ====================
CREATE TABLE IF NOT EXISTS missions_catalog (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name_fa TEXT NOT NULL,
    name_en TEXT NOT NULL,
    description_fa TEXT,
    description_en TEXT,
    mission_type TEXT NOT NULL,          -- daily, weekly, monthly, seasonal, event
    requirement_type TEXT NOT NULL,      -- attack, defend, build, collect, alliance
    requirement_value INTEGER NOT NULL,
    reward_coins INTEGER DEFAULT 0,
    reward_xp INTEGER DEFAULT 0,
    reward_fuel INTEGER DEFAULT 0,
    reward_uranium INTEGER DEFAULT 0,
    reward_item TEXT,
    is_active INTEGER DEFAULT 1
);

CREATE TABLE IF NOT EXISTS player_missions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    mission_id INTEGER NOT NULL,
    progress INTEGER DEFAULT 0,
    is_completed INTEGER DEFAULT 0,
    is_claimed INTEGER DEFAULT 0,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES players(user_id) ON DELETE CASCADE,
    FOREIGN KEY (mission_id) REFERENCES missions_catalog(id),
    UNIQUE(user_id, mission_id)
);

-- ==================== EVENTS ====================
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name_fa TEXT NOT NULL,
    name_en TEXT NOT NULL,
    event_type TEXT NOT NULL,            -- air_raid, storm, blackout, explosion, fuel_leak, uranium_discovery, special_market, missile_festival
    description_fa TEXT,
    description_en TEXT,
    effect_json TEXT,                    -- JSON effects
    start_time TIMESTAMP,
    end_time TIMESTAMP,
    is_active INTEGER DEFAULT 0,
    target_type TEXT DEFAULT 'all',      -- all, random, alliance, player
    target_id INTEGER
);

-- ==================== ALLIANCE WARS ====================
CREATE TABLE IF NOT EXISTS alliance_wars (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    attacker_alliance_id INTEGER NOT NULL,
    defender_alliance_id INTEGER NOT NULL,
    status TEXT DEFAULT 'active',        -- active, finished
    attacker_score INTEGER DEFAULT 0,
    defender_score INTEGER DEFAULT 0,
    start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    end_time TIMESTAMP,
    winner_id INTEGER,
    FOREIGN KEY (attacker_alliance_id) REFERENCES alliances(id),
    FOREIGN KEY (defender_alliance_id) REFERENCES alliances(id)
);

-- ==================== TERRITORIES ====================
CREATE TABLE IF NOT EXISTS territories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name_fa TEXT NOT NULL,
    name_en TEXT NOT NULL,
    region TEXT,
    owner_alliance_id INTEGER,
    defense_points INTEGER DEFAULT 1000,
    resource_bonus REAL DEFAULT 1.0,
    capture_time TIMESTAMP,
    FOREIGN KEY (owner_alliance_id) REFERENCES alliances(id)
);

-- ==================== ADMIN LOGS ====================
CREATE TABLE IF NOT EXISTS admin_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    target_id INTEGER,
    details TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==================== ANTI-SPAM / FLOOD ====================
CREATE TABLE IF NOT EXISTS flood_control (
    user_id INTEGER PRIMARY KEY,
    message_count INTEGER DEFAULT 0,
    last_message_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    warnings INTEGER DEFAULT 0,
    is_muted INTEGER DEFAULT 0,
    mute_until TIMESTAMP
);

-- ==================== GLOBAL STATS ====================
CREATE TABLE IF NOT EXISTS global_stats (
    key TEXT PRIMARY KEY,
    value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==================== WEEKLY LEADERBOARD SNAPSHOT ====================
CREATE TABLE IF NOT EXISTS weekly_leaderboard (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    week_number INTEGER NOT NULL,
    year INTEGER NOT NULL,
    attacks INTEGER DEFAULT 0,
    defenses INTEGER DEFAULT 0,
    damage_dealt INTEGER DEFAULT 0,
    resources_looted INTEGER DEFAULT 0,
    points INTEGER DEFAULT 0,
    UNIQUE(user_id, week_number, year)
);
