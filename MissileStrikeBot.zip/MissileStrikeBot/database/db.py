"""
Database manager - aiosqlite async wrapper
"""
from __future__ import annotations

import aiosqlite
import json
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple
from datetime import datetime, timedelta
from contextlib import asynccontextmanager

from config import settings


class Database:
    def __init__(self, db_path: Path | str | None = None):
        self.db_path = str(db_path or settings.db_path)
        self._connection: Optional[aiosqlite.Connection] = None

    async def connect(self) -> None:
        self._connection = await aiosqlite.connect(self.db_path)
        self._connection.row_factory = aiosqlite.Row
        await self._connection.execute("PRAGMA foreign_keys = ON")
        await self._connection.execute("PRAGMA journal_mode = WAL")
        await self._connection.execute("PRAGMA synchronous = NORMAL")
        await self._connection.execute("PRAGMA cache_size = -64000")
        await self._connection.execute("PRAGMA temp_store = MEMORY")
        await self._connection.commit()

    async def close(self) -> None:
        if self._connection:
            await self._connection.close()
            self._connection = None

    @asynccontextmanager
    async def transaction(self):
        if not self._connection:
            await self.connect()
        try:
            yield self._connection
            await self._connection.commit()
        except Exception:
            await self._connection.rollback()
            raise

    async def execute(self, sql: str, params: tuple | dict = ()) -> aiosqlite.Cursor:
        if not self._connection:
            await self.connect()
        cursor = await self._connection.execute(sql, params)
        await self._connection.commit()
        return cursor

    async def executemany(self, sql: str, params_list: list) -> None:
        if not self._connection:
            await self.connect()
        await self._connection.executemany(sql, params_list)
        await self._connection.commit()

    async def fetchone(self, sql: str, params: tuple | dict = ()) -> Optional[Dict]:
        if not self._connection:
            await self.connect()
        cursor = await self._connection.execute(sql, params)
        row = await cursor.fetchone()
        return dict(row) if row else None

    async def fetchall(self, sql: str, params: tuple | dict = ()) -> List[Dict]:
        if not self._connection:
            await self.connect()
        cursor = await self._connection.execute(sql, params)
        rows = await cursor.fetchall()
        return [dict(r) for r in rows]

    async def init_schema(self) -> None:
        schema_path = Path(__file__).parent / "schema.sql"
        if not self._connection:
            await self.connect()
        with open(schema_path, "r", encoding="utf-8") as f:
            schema = f.read()
        await self._connection.executescript(schema)
        await self._connection.commit()
        await self.seed_data()

    async def seed_data(self) -> None:
        # Check if already seeded
        count = await self.fetchone("SELECT COUNT(*) as c FROM missiles_catalog")
        if count and count["c"] > 0:
            return
        await self._seed_missiles()
        await self._seed_buildings()
        await self._seed_missions()
        await self._seed_territories()

    async def _seed_missiles(self) -> None:
        missiles = [
            # (name_fa, name_en, power, range_km, speed, accuracy, prep_time, travel_time, buy_cost, maintenance, fuel, intercept, hit, level, class, rarity, is_defensive)
            ("تاماهاوک", "Tomahawk", 450, 1600, 880, 0.85, 60, 120, 2500, 50, 40, 0.25, 0.80, 5, "cruise", "uncommon", 0),
            ("اسکندر", "Iskander", 700, 500, 2100, 0.90, 45, 90, 4500, 80, 60, 0.35, 0.88, 8, "ballistic", "rare", 0),
            ("استورم شادو", "Storm Shadow", 520, 560, 1000, 0.88, 50, 100, 3200, 60, 45, 0.22, 0.82, 6, "cruise", "uncommon", 0),
            ("پاتریوت", "Patriot", 300, 160, 1700, 0.92, 20, 30, 5000, 100, 30, 0.05, 0.90, 7, "air_defense", "rare", 1),
            ("تاد", "THAAD", 400, 200, 2800, 0.95, 30, 40, 8000, 150, 50, 0.03, 0.93, 12, "air_defense", "epic", 1),
            ("اتکمز", "ATACMS", 550, 300, 1500, 0.82, 40, 70, 2800, 55, 50, 0.30, 0.78, 5, "ballistic", "uncommon", 0),
            ("کینژال", "Kinzhal", 950, 2000, 12240, 0.87, 90, 60, 12000, 200, 100, 0.40, 0.85, 15, "hypersonic", "legendary", 0),
            ("براهموس", "BrahMos", 600, 600, 3672, 0.89, 55, 80, 5500, 90, 70, 0.28, 0.86, 9, "cruise", "rare", 0),
            ("یاخونت", "Yakhont", 480, 300, 2700, 0.84, 45, 65, 3800, 70, 55, 0.32, 0.80, 7, "cruise", "uncommon", 0),
            ("هارپون", "Harpoon", 350, 280, 850, 0.80, 35, 90, 1800, 40, 35, 0.35, 0.75, 3, "cruise", "common", 0),
            ("اسکالپ", "SCALP", 500, 560, 1000, 0.87, 50, 95, 3100, 60, 45, 0.23, 0.83, 6, "cruise", "uncommon", 0),
            ("نپتون", "Neptune", 420, 300, 900, 0.81, 40, 85, 2200, 45, 40, 0.33, 0.77, 4, "cruise", "common", 0),
            ("کروز", "Cruise Missile", 380, 1000, 800, 0.78, 40, 110, 2000, 40, 38, 0.30, 0.74, 3, "cruise", "common", 0),
            ("اسکاد", "Scud", 400, 300, 1500, 0.65, 30, 80, 1500, 30, 45, 0.45, 0.65, 2, "ballistic", "common", 0),
            ("فاتح-۱۱۰", "Fateh-110", 480, 300, 1800, 0.80, 35, 75, 2100, 45, 50, 0.38, 0.78, 4, "ballistic", "common", 0),
            ("قدر", "Qadr", 650, 1950, 2000, 0.75, 70, 140, 4000, 75, 80, 0.42, 0.72, 8, "ballistic", "uncommon", 0),
            ("سجیل", "Sejjil", 720, 2000, 2100, 0.78, 80, 130, 4800, 85, 90, 0.40, 0.75, 10, "ballistic", "rare", 0),
            ("عماد", "Emad", 680, 1700, 1900, 0.82, 65, 125, 4200, 80, 75, 0.38, 0.80, 9, "ballistic", "rare", 0),
            ("خرمشهر", "Khorramshahr", 900, 2000, 2200, 0.80, 90, 120, 7000, 120, 110, 0.35, 0.78, 13, "ballistic", "epic", 0),
            ("فتاح", "Fattah", 850, 1400, 15000, 0.88, 100, 50, 15000, 250, 120, 0.45, 0.86, 18, "hypersonic", "legendary", 0),
            ("هایپرسونیک روسی", "Avangard", 1100, 6000, 27000, 0.90, 180, 90, 25000, 400, 200, 0.50, 0.88, 20, "hypersonic", "legendary", 0),
            ("ترایدنت ۲", "Trident II", 1200, 12000, 21000, 0.92, 200, 150, 30000, 500, 250, 0.20, 0.90, 22, "ballistic", "legendary", 0),
            ("مینوتمن ۳", "Minuteman III", 1000, 13000, 24000, 0.88, 150, 140, 22000, 350, 180, 0.25, 0.85, 20, "ballistic", "legendary", 0),
            ("توپول-ام", "Topol-M", 1050, 11000, 22000, 0.89, 160, 135, 24000, 380, 190, 0.22, 0.87, 21, "ballistic", "legendary", 0),
            ("کالیبر", "Kalibr", 480, 2500, 900, 0.86, 55, 160, 3500, 65, 50, 0.28, 0.82, 7, "cruise", "uncommon", 0),
            ("اسکای‌شیلد", "Sky Shield", 280, 80, 1200, 0.90, 15, 20, 3500, 70, 25, 0.08, 0.88, 5, "air_defense", "uncommon", 1),
            ("اس-۳۰۰", "S-300", 350, 150, 2000, 0.91, 25, 35, 6000, 110, 40, 0.06, 0.89, 8, "air_defense", "rare", 1),
            ("اس-۴۰۰", "S-400", 420, 400, 2500, 0.94, 30, 45, 10000, 180, 55, 0.04, 0.92, 14, "air_defense", "epic", 1),
            ("آیرون دام", "Iron Dome", 200, 70, 700, 0.93, 10, 15, 4000, 80, 20, 0.07, 0.91, 6, "air_defense", "rare", 1),
            ("دیوید اسلینگ", "David's Sling", 320, 300, 2000, 0.92, 20, 30, 5500, 100, 35, 0.05, 0.90, 9, "air_defense", "rare", 1),
            ("ایگلا", "Igla", 80, 5, 570, 0.70, 5, 8, 400, 10, 5, 0.15, 0.65, 1, "air_defense", "common", 1),
            ("استینگر", "Stinger", 90, 8, 750, 0.75, 5, 10, 500, 12, 6, 0.12, 0.70, 1, "air_defense", "common", 1),
            ("هلفایر", "Hellfire", 250, 11, 1500, 0.90, 15, 20, 1200, 25, 15, 0.20, 0.88, 2, "tactical", "common", 0),
            ("جاولین", "Javelin", 220, 4, 300, 0.92, 10, 12, 900, 20, 10, 0.18, 0.90, 2, "tactical", "common", 0),
            ("گریفین", "Griffin", 180, 20, 800, 0.85, 12, 25, 800, 18, 12, 0.25, 0.80, 2, "tactical", "common", 0),
            ("اگزوزه", "Exocet", 300, 180, 1100, 0.82, 30, 60, 1600, 35, 30, 0.30, 0.78, 3, "cruise", "common", 0),
            ("هارپون بلوک ۲", "Harpoon Block II", 380, 280, 850, 0.85, 35, 85, 2000, 42, 38, 0.28, 0.82, 4, "cruise", "common", 0),
            ("اس‌ام-۶", "SM-6", 400, 370, 3600, 0.90, 25, 40, 7000, 130, 45, 0.10, 0.88, 11, "air_defense", "epic", 1),
            ("استاندارد ۲", "Standard Missile-2", 350, 170, 3000, 0.88, 20, 35, 4500, 90, 35, 0.12, 0.85, 8, "air_defense", "rare", 1),
            ("آستر ۳۰", "Aster 30", 380, 120, 4500, 0.93, 18, 25, 6500, 120, 40, 0.08, 0.91, 10, "air_defense", "rare", 1),
            ("بازهول", "Burevestnik", 600, 20000, 1000, 0.70, 300, 600, 18000, 300, 150, 0.35, 0.65, 19, "cruise", "legendary", 0),
            ("زیرکون", "Zircon", 900, 1000, 9800, 0.88, 80, 55, 14000, 220, 110, 0.42, 0.85, 16, "hypersonic", "legendary", 0),
            ("کینژال-ام", "Kinzhal-M", 1000, 2500, 14000, 0.90, 100, 50, 16000, 260, 130, 0.38, 0.87, 17, "hypersonic", "legendary", 0),
            ("پروژه ۴۲۰۲", "Project 4202", 1150, 8000, 25000, 0.91, 200, 100, 28000, 450, 220, 0.48, 0.89, 22, "hypersonic", "legendary", 0),
            ("جسی‌ام", "JASSM", 450, 370, 1000, 0.90, 40, 80, 2700, 50, 40, 0.20, 0.88, 5, "cruise", "uncommon", 0),
            ("جسی‌ام-ای‌آر", "JASSM-ER", 480, 1000, 1000, 0.91, 45, 120, 3400, 60, 50, 0.18, 0.89, 7, "cruise", "rare", 0),
            ("ال‌آر‌ای‌اس‌ام", "LRASM", 500, 900, 900, 0.89, 50, 110, 3800, 70, 55, 0.22, 0.86, 8, "cruise", "rare", 0),
            ("پرسینگ ۲", "Pershing II", 800, 1800, 8000, 0.85, 70, 90, 6000, 110, 90, 0.35, 0.82, 12, "ballistic", "epic", 0),
            ("اچ‌اس‌ام", "HIMARS", 400, 300, 1400, 0.88, 25, 60, 2500, 50, 40, 0.25, 0.85, 5, "ballistic", "uncommon", 0),
            ("ام‌ال‌آر‌اس", "MLRS", 350, 70, 1200, 0.80, 20, 40, 1800, 40, 30, 0.30, 0.78, 3, "ballistic", "common", 0),
            ("گراد", "Grad", 200, 40, 700, 0.60, 15, 35, 800, 20, 25, 0.40, 0.60, 1, "ballistic", "common", 0),
            ("اسمیرچ", "Smerch", 450, 90, 900, 0.75, 30, 50, 2200, 45, 45, 0.35, 0.72, 4, "ballistic", "common", 0),
            ("تورنادو", "Tornado-S", 480, 120, 1000, 0.82, 30, 55, 2600, 50, 50, 0.32, 0.80, 5, "ballistic", "uncommon", 0),
            ("اسکندر-ام", "Iskander-M", 750, 500, 2100, 0.92, 40, 85, 5000, 90, 65, 0.33, 0.90, 10, "ballistic", "rare", 0),
            ("اتکمز بلاک ۱A", "ATACMS Block 1A", 580, 300, 1500, 0.85, 35, 65, 3000, 60, 55, 0.28, 0.82, 6, "ballistic", "uncommon", 0),
            ("پرایم", "PrSM", 500, 500, 1600, 0.90, 30, 70, 3500, 65, 50, 0.25, 0.88, 8, "ballistic", "rare", 0),
            ("اس‌ام‌ای‌آر‌تی", "SMART", 280, 150, 1100, 0.88, 25, 50, 1900, 40, 30, 0.22, 0.85, 4, "tactical", "common", 0),
            ("اسپایک", "Spike", 200, 25, 600, 0.92, 10, 20, 700, 15, 10, 0.15, 0.90, 2, "tactical", "common", 0),
            ("کورنت", "Kornet", 220, 10, 300, 0.90, 8, 15, 600, 12, 8, 0.18, 0.88, 1, "tactical", "common", 0),
            ("تاو", "TOW", 180, 4, 300, 0.85, 8, 12, 500, 10, 8, 0.20, 0.82, 1, "tactical", "common", 0),
            ("هل‌فایر لانگ‌بو", "Hellfire Longbow", 270, 11, 1500, 0.93, 12, 18, 1400, 28, 15, 0.18, 0.91, 3, "tactical", "uncommon", 0),
            ("بریموستون", "Brimstone", 240, 60, 1400, 0.91, 15, 30, 1500, 30, 18, 0.20, 0.89, 3, "tactical", "uncommon", 0),
            ("اسپیر", "SPEAR", 260, 140, 1000, 0.90, 20, 45, 1700, 35, 25, 0.22, 0.88, 4, "tactical", "uncommon", 0),
            ("نصر", "Nasr", 300, 60, 800, 0.75, 20, 40, 1000, 25, 30, 0.35, 0.70, 2, "ballistic", "common", 0),
            ("غدر", "Ghadir", 550, 300, 1500, 0.80, 40, 70, 2800, 55, 55, 0.35, 0.78, 6, "ballistic", "uncommon", 0),
            ("زلزال", "Zelzal", 400, 200, 1200, 0.70, 25, 55, 1600, 35, 40, 0.40, 0.68, 3, "ballistic", "common", 0),
            ("فاتح-۳۱۳", "Fateh-313", 500, 500, 1700, 0.85, 40, 80, 2500, 50, 55, 0.32, 0.82, 6, "ballistic", "uncommon", 0),
            ("دزفول", "Dezful", 600, 1000, 1800, 0.83, 50, 100, 3500, 65, 70, 0.35, 0.80, 8, "ballistic", "rare", 0),
            ("رعد", "Ra'ad", 350, 350, 900, 0.78, 35, 90, 1800, 40, 40, 0.30, 0.75, 4, "cruise", "common", 0),
            ("سومار", "Soumar", 420, 700, 850, 0.80, 45, 110, 2300, 45, 45, 0.28, 0.78, 5, "cruise", "uncommon", 0),
            ("هویزه", "Hoveyzeh", 450, 1350, 900, 0.82, 50, 130, 2800, 55, 50, 0.27, 0.80, 7, "cruise", "uncommon", 0),
            ("قدیر", "Qadir", 480, 300, 1000, 0.84, 40, 70, 2400, 50, 45, 0.30, 0.82, 5, "cruise", "uncommon", 0),
            ("نور", "Noor", 320, 120, 900, 0.80, 25, 50, 1400, 30, 30, 0.32, 0.78, 3, "cruise", "common", 0),
            ("قادر", "Qader", 380, 200, 950, 0.82, 30, 60, 1700, 35, 35, 0.30, 0.80, 4, "cruise", "common", 0),
            ("ابابیل", "Ababil", 150, 100, 200, 0.70, 20, 80, 600, 15, 15, 0.25, 0.65, 1, "tactical", "common", 0),
            ("شاهد-۱۳۶", "Shahed-136", 180, 2000, 185, 0.65, 30, 300, 800, 20, 25, 0.40, 0.60, 2, "cruise", "common", 0),
            ("شاهد-۲۳۸", "Shahed-238", 250, 2000, 800, 0.75, 40, 150, 1500, 35, 40, 0.35, 0.72, 5, "cruise", "uncommon", 0),
            ("مهاجر-۶", "Mohajer-6", 200, 200, 200, 0.78, 25, 100, 900, 20, 20, 0.28, 0.75, 3, "tactical", "common", 0),
            ("کمان-۲۲", "Kaman-22", 220, 1000, 300, 0.80, 35, 180, 1200, 25, 30, 0.30, 0.78, 4, "tactical", "uncommon", 0),
        ]

        sql = """
            INSERT INTO missiles_catalog
            (name_fa, name_en, power, range_km, speed, accuracy, prep_time, travel_time,
             buy_cost, maintenance_cost, fuel_consumption, intercept_chance, hit_chance,
             required_level, missile_class, rarity, is_defensive)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        await self.executemany(sql, missiles)

    async def _seed_buildings(self) -> None:
        buildings = [
            # (name_fa, name_en, base_cost, cost_mult, upgrade_time, max_level, prod_type, base_prod, prod_per_level, capacity, defense, hp, req_level, type)
            ("مرکز فرماندهی", "Command Center", 0, 1.8, 0, 20, "xp", 5, 1.3, 0, 50, 500, 1, "military"),
            ("انبار موشک", "Missile Silo", 800, 1.6, 300, 15, None, 0, 1.0, 10, 20, 200, 1, "storage"),
            ("پالایشگاه سوخت", "Fuel Refinery", 600, 1.5, 240, 20, "fuel", 15, 1.25, 0, 10, 150, 1, "production"),
            ("معدن اورانیوم", "Uranium Mine", 1500, 1.7, 480, 15, "uranium", 2, 1.3, 0, 15, 180, 5, "production"),
            ("کارخانه فولاد", "Steel Factory", 700, 1.5, 300, 20, "steel", 10, 1.25, 0, 15, 160, 2, "production"),
            ("کارخانه موشک", "Missile Factory", 2000, 1.8, 600, 12, None, 0, 1.0, 0, 30, 250, 4, "military"),
            ("رادار", "Radar Station", 1200, 1.6, 360, 15, None, 0, 1.0, 0, 40, 200, 3, "defense"),
            ("سامانه پدافند", "Air Defense System", 2500, 1.7, 480, 12, None, 0, 1.0, 0, 80, 300, 6, "defense"),
            ("مرکز تحقیقات", "Research Center", 1800, 1.6, 420, 15, "xp", 8, 1.3, 0, 20, 180, 4, "research"),
            ("آشیانه پهپاد", "Drone Hangar", 1000, 1.5, 300, 12, None, 0, 1.0, 5, 25, 170, 3, "military"),
            ("پناهگاه", "Bunker", 1500, 1.6, 360, 10, None, 0, 1.0, 0, 100, 400, 5, "defense"),
            ("نیروگاه", "Power Plant", 900, 1.5, 300, 15, "energy", 3, 1.2, 0, 10, 150, 2, "production"),
            ("کارخانه قطعات", "Parts Factory", 1100, 1.55, 330, 15, "steel", 8, 1.25, 0, 15, 160, 3, "production"),
            ("مرکز اطلاعات", "Intelligence Center", 1600, 1.6, 400, 12, "xp", 6, 1.25, 0, 30, 190, 5, "research"),
            ("انبار سوخت", "Fuel Depot", 500, 1.4, 180, 20, None, 0, 1.0, 200, 10, 120, 1, "storage"),
            ("انبار اورانیوم", "Uranium Storage", 1200, 1.5, 300, 15, None, 0, 1.0, 50, 20, 180, 5, "storage"),
            ("معدن تیتانیوم", "Titanium Mine", 2000, 1.7, 540, 12, "titanium", 1, 1.3, 0, 20, 200, 8, "production"),
            ("آزمایشگاه کریستال", "Crystal Lab", 3000, 1.8, 720, 10, "crystal", 1, 1.4, 0, 15, 220, 10, "production"),
            ("برج مراقبت", "Watchtower", 800, 1.5, 240, 12, None, 0, 1.0, 0, 50, 150, 2, "defense"),
            ("پدافند کوتاه‌برد", "Short-Range Defense", 1800, 1.6, 360, 12, None, 0, 1.0, 0, 60, 220, 4, "defense"),
            ("پدافند میان‌برد", "Medium-Range Defense", 3500, 1.7, 480, 10, None, 0, 1.0, 0, 90, 280, 8, "defense"),
            ("پدافند بلندبرد", "Long-Range Defense", 6000, 1.8, 600, 8, None, 0, 1.0, 0, 120, 350, 12, "defense"),
            ("سامانه اخلال", "Jamming System", 2800, 1.65, 420, 10, None, 0, 1.0, 0, 40, 200, 7, "defense"),
            ("مرکز آموزش", "Training Center", 1300, 1.55, 360, 12, "xp", 10, 1.3, 0, 20, 170, 3, "military"),
            ("بیمارستان نظامی", "Military Hospital", 1400, 1.5, 300, 10, None, 0, 1.0, 0, 30, 250, 4, "special"),
            ("معدن طلا", "Gold Mine", 500, 1.5, 300, 20, "coins", 500, 1.3, 0, 10, 200, 1, "production"),
            ("بازار سیاه", "Black Market", 2500, 1.7, 480, 8, "coins", 30, 1.3, 0, 10, 150, 9, "special"),
            ("کارخانه جنگ‌افزار", "Weapons Factory", 2200, 1.7, 500, 12, None, 0, 1.0, 0, 35, 240, 6, "military"),
            ("مرکز ارتباطات", "Comms Center", 1100, 1.5, 280, 12, None, 0, 1.0, 0, 25, 160, 3, "special"),
            ("پناهگاه عمیق", "Deep Bunker", 4000, 1.8, 720, 8, None, 0, 1.0, 0, 150, 500, 10, "defense"),
            ("آکادمی نظامی", "Military Academy", 2800, 1.65, 540, 10, "xp", 15, 1.35, 0, 25, 220, 7, "research"),
            ("مرکز فرماندهی پیشرفته", "Advanced HQ", 5000, 1.9, 900, 5, "xp", 20, 1.4, 0, 80, 600, 15, "military"),
        ]

        sql = """
            INSERT INTO buildings_catalog
            (name_fa, name_en, base_cost, cost_multiplier, base_upgrade_time, max_level,
             production_type, base_production, production_per_level, capacity_bonus,
             defense_bonus, hp_per_level, required_level, building_type)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        await self.executemany(sql, buildings)

    async def _seed_missions(self) -> None:
        missions = [
            ("حمله روزانه", "Daily Attack", "۳ بار حمله موفق انجام دهید", "Perform 3 successful attacks", "daily", "attack", 3, 300, 50, 20, 0, None),
            ("دفاع روزانه", "Daily Defense", "۲ بار دفاع موفق", "Successfully defend 2 times", "daily", "defend", 2, 250, 40, 15, 0, None),
            ("جمع‌آوری منابع", "Resource Collector", "۵۰۰ سکه جمع کنید", "Collect 500 coins", "daily", "collect", 500, 200, 30, 10, 0, None),
            ("ارتقای ساختمان", "Building Upgrader", "یک ساختمان ارتقا دهید", "Upgrade one building", "daily", "build", 1, 400, 60, 25, 0, None),
            ("جنگجو هفتگی", "Weekly Warrior", "۱۵ حمله موفق", "15 successful attacks", "weekly", "attack", 15, 2000, 300, 100, 5, None),
            ("مدافع هفته", "Weekly Defender", "۱۰ دفاع موفق", "10 successful defenses", "weekly", "defend", 10, 1800, 250, 80, 3, None),
            ("ثروتمند هفته", "Weekly Tycoon", "۵۰۰۰ سکه کسب کنید", "Earn 5000 coins", "weekly", "collect", 5000, 1500, 200, 50, 0, None),
            ("اتحاد ماهانه", "Monthly Alliance", "به یک اتحاد بپیوندید و کمک کنید", "Join alliance and contribute", "monthly", "alliance", 1, 5000, 800, 200, 10, None),
            ("فاتح فصلی", "Seasonal Conqueror", "۵۰ حمله موفق در فصل", "50 successful attacks this season", "seasonal", "attack", 50, 15000, 2000, 500, 50, None),
        ]
        sql = """
            INSERT INTO missions_catalog
            (name_fa, name_en, description_fa, description_en, mission_type,
             requirement_type, requirement_value, reward_coins, reward_xp,
             reward_fuel, reward_uranium, reward_item)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        await self.executemany(sql, missions)

    async def _seed_territories(self) -> None:
        territories = [
            ("تهران", "Tehran", "Middle East"),
            ("مسکو", "Moscow", "Europe"),
            ("واشنگتن", "Washington", "North America"),
            ("پکن", "Beijing", "Asia"),
            ("ریاض", "Riyadh", "Middle East"),
            ("آنکارا", "Ankara", "Middle East"),
            ("برلین", "Berlin", "Europe"),
            ("توکیو", "Tokyo", "Asia"),
            ("دهلی", "Delhi", "Asia"),
            ("قاهره", "Cairo", "Africa"),
            ("اسلام‌آباد", "Islamabad", "Asia"),
            ("تل‌آویو", "Tel Aviv", "Middle East"),
            ("پاریس", "Paris", "Europe"),
            ("لندن", "London", "Europe"),
            ("سئول", "Seoul", "Asia"),
        ]
        sql = "INSERT INTO territories (name_fa, name_en, region) VALUES (?, ?, ?)"
        await self.executemany(sql, territories)


# Global instance
_db: Optional[Database] = None


async def get_db() -> Database:
    global _db
    if _db is None:
        _db = Database()
        await _db.connect()
        await _db.init_schema()
    return _db
