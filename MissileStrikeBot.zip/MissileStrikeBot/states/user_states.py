from aiogram.fsm.state import State, StatesGroup


class AttackState(StatesGroup):
    choosing_target = State()
    choosing_missile = State()
    confirming = State()


class AllianceState(StatesGroup):
    creating_name = State()
    creating_tag = State()
    joining = State()
    transferring = State()
    war_declare = State()


class MarketState(StatesGroup):
    listing_type = State()
    listing_item = State()
    listing_qty = State()
    listing_price = State()
    buying = State()


class BuildingState(StatesGroup):
    upgrading = State()
    collecting = State()


class AdminState(StatesGroup):
    add_resource = State()
    remove_resource = State()
    ban_user = State()
    unban_user = State()
    broadcast = State()
    create_event = State()
    give_missile = State()
