from aiogram.filters import BaseFilter
from aiogram.types import Message, CallbackQuery
from config import settings


class IsAdmin(BaseFilter):
    async def __call__(self, event: Message | CallbackQuery) -> bool:
        user = event.from_user
        if not user:
            return False
        return user.id in settings.admin_ids
