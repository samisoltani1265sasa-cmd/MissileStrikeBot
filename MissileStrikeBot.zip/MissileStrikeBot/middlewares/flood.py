from typing import Callable, Dict, Any, Awaitable
from datetime import datetime, timedelta
from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Message, CallbackQuery
from database import get_db


class FloodMiddleware(BaseMiddleware):
    def __init__(self, rate_limit: int = 8, period: int = 10):
        self.rate_limit = rate_limit
        self.period = period

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        user = None
        if isinstance(event, (Message, CallbackQuery)) and event.from_user:
            user = event.from_user
        if not user:
            return await handler(event, data)

        db = await get_db()
        row = await db.fetchone("SELECT * FROM flood_control WHERE user_id = ?", (user.id,))
        now = datetime.utcnow()

        if row and row.get("is_muted") and row.get("mute_until"):
            mute_until = row["mute_until"]
            if isinstance(mute_until, str):
                mute_until = datetime.fromisoformat(mute_until.replace("Z", ""))
            if now < mute_until:
                if isinstance(event, CallbackQuery):
                    await event.answer("🔇 شما موقتاً محدود شده‌اید.", show_alert=True)
                return

        if not row:
            await db.execute(
                "INSERT INTO flood_control (user_id, message_count, last_message_time) VALUES (?, 1, CURRENT_TIMESTAMP)",
                (user.id,)
            )
        else:
            last = row["last_message_time"]
            if isinstance(last, str):
                last = datetime.fromisoformat(last.replace("Z", ""))
            if (now - last).total_seconds() > self.period:
                await db.execute(
                    "UPDATE flood_control SET message_count = 1, last_message_time = CURRENT_TIMESTAMP WHERE user_id = ?",
                    (user.id,)
                )
            else:
                new_count = row["message_count"] + 1
                if new_count > self.rate_limit:
                    warnings = row["warnings"] + 1
                    mute_until = (now + timedelta(minutes=min(warnings * 2, 30))).isoformat()
                    await db.execute(
                        "UPDATE flood_control SET warnings = ?, is_muted = 1, mute_until = ? WHERE user_id = ?",
                        (warnings, mute_until, user.id)
                    )
                    if isinstance(event, CallbackQuery):
                        await event.answer("⚠️ اسپم شناسایی شد. موقتاً محدود شدید.", show_alert=True)
                    elif isinstance(event, Message):
                        await event.answer("⚠️ اسپم شناسایی شد. موقتاً محدود شدید.")
                    return
                await db.execute(
                    "UPDATE flood_control SET message_count = ?, last_message_time = CURRENT_TIMESTAMP WHERE user_id = ?",
                    (new_count, user.id)
                )
        return await handler(event, data)
