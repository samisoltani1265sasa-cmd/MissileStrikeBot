from typing import Callable, Dict, Any, Awaitable
from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Message, CallbackQuery
from services.player_service import PlayerService


class AuthMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        user = None
        if isinstance(event, Message) and event.from_user:
            user = event.from_user
        elif isinstance(event, CallbackQuery) and event.from_user:
            user = event.from_user

        if user and not user.is_bot:
            player = await PlayerService.get_or_create(
                user.id,
                user.username,
                user.first_name or "Unknown",
                user.last_name,
            )
            data["player"] = player
            if player.get("is_banned"):
                if isinstance(event, Message):
                    await event.answer(f"🚫 حساب شما مسدود است.\nدلیل: {player.get('ban_reason') or 'نامشخص'}")
                elif isinstance(event, CallbackQuery):
                    await event.answer("🚫 حساب شما مسدود است.", show_alert=True)
                return
        return await handler(event, data)
