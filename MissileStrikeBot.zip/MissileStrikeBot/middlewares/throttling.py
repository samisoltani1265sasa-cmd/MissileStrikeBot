from typing import Callable, Dict, Any, Awaitable
from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, CallbackQuery
import time


class ThrottlingMiddleware(BaseMiddleware):
    """Simple in-memory throttle for callbacks"""
    def __init__(self, rate: float = 0.4):
        self.rate = rate
        self._last: Dict[int, float] = {}

    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any],
    ) -> Any:
        if isinstance(event, CallbackQuery) and event.from_user:
            uid = event.from_user.id
            now = time.monotonic()
            last = self._last.get(uid, 0)
            if now - last < self.rate:
                await event.answer("⏳ کمی صبر کنید...", show_alert=False)
                return
            self._last[uid] = now
        return await handler(event, data)
